---
title: Mesh Smoothing — Laplacian, CVT, ODT
type: algorithm
tags: [smoothing, laplacian, cvt, odt, lloyd, lbfgs, topology, swap, flip]
created: 2026-05-16
---

# 12 — Mesh Smoothing: Laplacian, CVT, ODT, and Topology Operators

A mesh produced by any generator ([[04_Delaunay_CDT_and_TetGen]], [[05_Frontal_Delaunay_and_Advancing_Front]], [[09_Robust_TetWild_for_Dirty_Geometry]]) typically has correct topology and connectivity but **suboptimal vertex positions** — slivers, near-zero scaled Jacobians, anisotropic distortion. Mesh **smoothing** is the post-processing step that moves vertices (no topology change) to improve element quality; **topology operators** (edge flip, face swap) add the remaining quality improvement at the cost of changing local connectivity.

This note covers the four smoothing families in increasing order of sophistication and effectiveness:

1. Laplacian (and weighted variants).
2. Optimisation-based (Freitag–Knupp).
3. Centroidal Voronoi Tessellation (CVT / Lloyd / L-BFGS).
4. Optimal Delaunay Triangulation (ODT) — Chen–Holst.

Topology operators are treated in §6.

Foundation: [[01_Mathematical_Foundations]] §5–6. Quality metrics: [[02_Mesh_Quality_Metrics]].

---

## 1. Laplacian Smoothing

The textbook starting point: move every interior vertex to the centroid of its 1-ring neighbours.

$$
x_i^{(k+1)} = \frac{1}{|N(i)|}\sum_{j\in N(i)} x_j^{(k)}.
$$

**Pros:** $\mathcal{O}(n)$ per iteration, trivially parallel, no quality evaluation needed.

**Cons:** Can **invert elements** — moving an interior vertex past its neighbour ring is not detected. Has **no quality objective** — may make a "uniform" mesh that is actually worse for slivers.

### 1.1 Smart Laplacian (Freitag 1997)

Same update rule, but **revert** if the move decreases the worst-element quality in the 1-ring. Eliminates inversion. Still no quality-driven objective.

### 1.2 Weighted Laplacian

$$
x_i^{(k+1)} = \sum_{j\in N(i)} w_{ij}\,x_j^{(k)},\quad \sum_j w_{ij}=1.
$$

Cotangent weights $w_{ij}\propto \cot\alpha_{ij}+\cot\beta_{ij}$ (Desbrun et al. 1999) preserve the discrete Laplace–Beltrami operator and produce **mean-curvature flow** on surfaces — useful for surface smoothing without volume loss.

### 1.3 Use cases

Laplacian remains the smoother of choice when:
- Mesh is already high-quality and only needs gentle improvement.
- Speed dominates quality (real-time simulation, GPU compute).
- Surface smoothing where cotangent weighting is natural.

---

## 2. Optimisation-Based Smoothing (Freitag–Knupp 1999)

Treat smoothing as a nonlinear optimisation: move vertex $x_i$ to minimise a quality objective over its 1-ring of incident elements.

$$
x_i^* = \arg\min_{x\in B(x_i^{(k)}, r)} \;f(\{q(T) : T\ni x\}),
$$

with $f$ a smooth aggregation (e.g. $\sum (1-q)^2$) and $q$ the Knupp mean ratio ([[02_Mesh_Quality_Metrics]] §2.5). Solved by **steepest descent** or **conjugate gradient** within the trust region.

**Pros:** Provably non-degrading (each step improves the local objective).

**Cons:** Each step is local — global mesh quality may plateau short of the optimum.

Implementations: `Mesquite` (Sandia), `Verdict`, embedded in CUBIT.

---

## 3. Centroidal Voronoi Tessellation (CVT) Smoothing

Move each vertex to the centroid of its **Voronoi cell** restricted to the domain. Equivalent to minimising the **CVT energy** ([[01_Mathematical_Foundations]] §5):

$$
\mathcal{F}(\{x_i\}) = \sum_i \int_{V_i\cap\Omega} \rho(x)\,\|x-x_i\|^2\,dx.
$$

### 3.1 Lloyd's algorithm

$$
x_i^{(k+1)} = c_i^{(k)} = \frac{\int_{V_i^{(k)}\cap\Omega} \rho(x)\,x\,dx}{\int_{V_i^{(k)}\cap\Omega} \rho(x)\,dx}.
$$

Linear convergence rate $\mathcal{O}(1/k)$. With $\rho=1$, produces *uniformly* distributed vertices; with $\rho(x)$ a target sizing function, produces *sized* meshes.

### 3.2 L-BFGS CVT (Liu et al. 2009 — *Variational CVT*)

The CVT energy is **$C^2$** in vertex positions; its gradient is closed-form:

$$
\nabla_i \mathcal{F} = 2\,m_i\,(x_i - c_i),\qquad m_i = \int_{V_i\cap\Omega}\rho\,dx.
$$

Apply **L-BFGS** with line search; convergence rate jumps to **super-linear**. ~10× faster than Lloyd to the same energy.

This is the smoother used in:
- Gmsh's tet smoother.
- Geogram / vorpaline.
- COMSOL's surface remeshing.

### 3.3 Restricted CVT on surfaces

Replace Voronoi cells by their intersection with $\mathcal{S}$ → surface CVT smoother. See [[03_Surface_Meshing_Curved_Manifolds]] §4.

### 3.4 Anisotropic CVT

Use the metric distance $\|x-x_i\|_M$ instead of Euclidean. Cells become "metric Voronoi"; tessellations are sized & oriented per the metric field. See [[08_Anisotropic_Metric_Adaptation]] integration with CVT.

---

## 4. Optimal Delaunay Triangulation (ODT) — Chen & Holst 2011

The **ODT** energy is the integrated interpolation error of $\frac{1}{2}\|x\|^2$ over the triangulation:

$$
\mathcal{E}_{\mathrm{ODT}}(\{x_i\}) = \sum_T \int_T \tfrac{1}{2}\|x\|^2 - I_T\!\left[\tfrac{1}{2}\|x\|^2\right]\,dx.
$$

Setting the gradient to zero gives the **ODT vertex update**:

$$
x_i^{(k+1)} = \frac{1}{|V_i|}\sum_{T\in\mathrm{star}(i)} \int_T (x-x_i)\,dx + x_i^{(k)},
$$

— essentially "move $x_i$ toward the integrated *centroid of its star*."

### 4.1 Why ODT > CVT for tets

Both minimise an integral quality. The difference: ODT is *defined on the existing triangulation*, so its minimiser is the **best mesh that has the current connectivity** — whereas CVT optimises *over vertex positions only*, ignoring the dual triangulation quality.

**Concretely:** ODT removes 3-D slivers; CVT does not (because slivers don't change Voronoi cell mass much).

### 4.2 The full ODT smoothing pipeline (Tournois–Wormser–Alliez–Desbrun 2009 for surfaces; Chen 2004 for volumes)

```text
repeat for k = 1..K:
   for each interior vertex v_i:
      compute g_i = ∇ E_ODT (closed-form via star integration)
      x_i ← x_i − α g_i      (α = trust-region step, ~0.5)
   re-Delaunay-flip wherever ODT update broke empty-sphere
```

Convergence: $K = 20$–$50$ iterations typical; final mesh has dihedral angles $\ge 25°$ on 99% of elements.

ODT is the default smoother for:
- MMG3D's quality-improvement passes.
- TetGen 1.6 `-O` optimisation.
- fTetWild's improvement phase.

---

## 5. Comparison of Smoothing Methods

| Method | Inversion-safe | Sliver removal | Anisotropy | Cost/iter | Best for |
|---|---|---|---|---|---|
| Laplacian | no | poor | no | very low | gentle cleanup, surfaces |
| Smart Laplacian | yes | poor | no | low | safe, fast |
| Cotangent Laplacian | yes | no | no | low | surface mean-curvature flow |
| Optimisation (Freitag) | yes | medium | no | medium | local fix-up |
| Lloyd CVT | no (needs projection) | poor (tet) | with metric | medium | isotropic point placement |
| L-BFGS CVT | no (needs projection) | poor (tet) | with metric | medium | fast CVT |
| ODT | yes | **excellent** | partial | medium-high | tet quality polish |

---

## 6. Topology Operators

Smoothing alone cannot fix topologically bad configurations (e.g. an interior vertex with valence 3 — impossible to make nice tets without removing it). Topology operators address this:

### 6.1 Edge flip (2-D / 2-tet swap in 3-D)

In 2-D: replace edge $(a,b)$ shared by triangles $abc, abd$ with edge $(c,d)$ shared by $acd, bcd$. Valid iff the new quad $acbd$ is convex.

In 3-D: **2-3 flip / 3-2 flip / 4-4 flip** (Lawson 1972; Joe 1989):
- **2-3 flip**: 2 tets sharing a face become 3 tets sharing an edge.
- **3-2 flip**: 3 tets sharing an edge become 2 tets sharing a face.
- **4-4 flip**: 4 tets sharing an edge become 4 tets sharing a different edge.

### 6.2 Edge collapse

Merge $a, b$ → single vertex; remove all simplices containing both. Reduces vertex count; used to relieve over-refinement.

### 6.3 Edge split / vertex insertion

Insert a new vertex on an edge (or at a face/element centroid); subdivides incident simplices.

### 6.4 Vertex removal (3-2 / 4-1 inverse)

Remove a low-valence interior vertex; replace its 1-ring with a re-triangulation.

### 6.5 Combined topology + smoothing pipeline (MMG-style)

```text
repeat:
  // VOLUME phase
  for each interior edge e:
    if quality(adjacent tets after flip) > quality(before): FLIP
  for each interior edge e:
    if metric_length(e) > √2: SPLIT
    if metric_length(e) < 1/√2: COLLAPSE
  // SMOOTH phase
  for each interior vertex v:
    ODT update v with one iteration
  if no operator triggered any change: STOP
```

This loop converges typically in 5–10 outer iterations, producing the high-quality, metric-conforming output that defines the state of the art.

---

## 7. Smoothing for the Tet10 Specifically

The host project ([theory.md](../theory.md)) uses Tet10. Smoothing has an extra wrinkle: the **mid-edge nodes**. Naively smoothing only corner nodes and re-placing mid-edges by linear edge midpoints **gives up the higher-order geometric capability** of Tet10.

Two strategies:

1. **Smooth corners, then project mid-edges to a recovered surface.** For boundary mid-edges, project onto a local quadratic fit of the surface; for interior mid-edges, use linear midpoint. Maintains FE conformity; minimal cost.

2. **Smooth all 10 nodes with constraint that mid-edge stays within the convex hull of its two corners.** Higher cost; risks inverted Jacobian. Not recommended in practice.

The host project's [src/Tet10Element.cpp](../src/Tet10Element.cpp) currently uses strategy (1) implicitly; explicit boundary mid-edge projection would be a worthwhile enhancement.

---

## 8. References

- L. R. Herrmann, "Laplacian-isoparametric grid generation scheme," *J. Eng. Mech. Div.* 102, 1976.
- L. A. Freitag, "On combining Laplacian and optimization-based mesh smoothing techniques," *Trends in Unstructured Mesh Generation* AMD-220, 1997.
- L. Freitag & P. Knupp, "Tetrahedral mesh improvement via optimization of the element condition number," *IJNME* 53, 2002.
- Q. Du, V. Faber, M. Gunzburger, "Centroidal Voronoi tessellations: applications and algorithms," *SIAM Review* 41, 1999.
- Y. Liu, W. Wang, B. Lévy, F. Sun, D.-M. Yan, L. Lu, C. Yang, "On centroidal Voronoi tessellation—energy smoothness and fast computation," *ACM TOG* 28, 2009.
- L. Chen & J. Xu, "Optimal Delaunay triangulations," *J. Comput. Math.* 22, 2004.
- L. Chen & M. Holst, "Efficient mesh optimization schemes based on Optimal Delaunay Triangulations," *CMAME* 200, 2011.
- J. Tournois, C. Wormser, P. Alliez, M. Desbrun, "Interleaving Delaunay refinement and optimization for practical isotropic tetrahedron mesh generation," *ACM TOG (SIGGRAPH)* 28, 2009.
- B. Joe, "Three-dimensional triangulations from local transformations," *SIAM J. Sci. Stat. Comput.* 10, 1989.
- Annotated list in [[15_References_Bibliography]].
