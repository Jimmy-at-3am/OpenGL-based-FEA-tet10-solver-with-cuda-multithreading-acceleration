# TODO_06 — ODT smoother (interior nodes)

## Goal
A `Smooth Mesh (ODT)` button runs Chen–Holst Optimal Delaunay Triangulation smoothing on interior tet nodes with exact-predicate validity guard. Visible improvement in the HUD overlay added in TODO_05.

## Files added / modified
- **Add** `include/MeshSmoother.h`, `src/MeshSmoother.cpp` — class `ODTSmoother`.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — wire `Smooth Mesh (ODT)` button.
- **Modify** `src/FEAModel.cpp` — invoke `ODTSmoother::run(model, params)` and refresh `updateScalarFieldData`.

## Algorithm summary
From [knowledge/12_Mesh_Smoothing_CVT_and_ODT.md §4](knowledge/12_Mesh_Smoothing_CVT_and_ODT.md) and plan Appendix Phase B.1:

For each interior vertex $i$ in red-black colouring rounds:
$$x_i^{(k+1)} = \frac{\sum_j |T_j|\,c_{T_j}}{\sum_j |T_j|}$$
where the sum is over incident tets, $c_{T_j}$ = centroid of $T_j$.

**Validity guard:** before committing, evaluate `orient3d` (exact predicate, `src/predicates.cxx`) on each incident tet at the candidate position. Reject if any flips sign or drift exceeds `params.curvedTet10MaxDriftRatio * h_local`.

```text
buildVertexElementMap()
buildBoundaryNodeMask()    // skip boundary nodes — TODO_10 handles those
for iter = 1..odtIterations:
    #pragma omp parallel for schedule(dynamic, 1024)
    for each interior node i:
        compute weighted-centroid x_i'
        for each incident tet T_j: evaluate exact orient3d at x_i'
        if any flip OR drift > limit: reject
        else: atomic store x_i'
```

## Multithreading
- Vertex-element adjacency built once with `#pragma omp parallel for` (output is per-vertex, no shared write).
- Per-iteration: red-black colouring of vertex-vertex graph → each colour's vertices processed fully parallel. Implemented via a single pre-computed colour array; for the initial cut, use a simpler `schedule(dynamic, 1024)` over all vertices and atomic-CAS commit — the data race is contained (each vertex writes only its own position) and the only correctness risk is read-after-write of neighbours' positions within the same iteration; this gives slightly slower convergence but identical correctness.
- Default `useMultithreading = true`.

## Numerical care points
- **MUST use exact predicates** for validity (care-point #1). Naive double comparison gives wrong signs near degenerate configurations and corrupts the mesh.
- Damping: under-relax with $\omega = 0.5$ for the first iteration if many rejections occur; relax to $1.0$ once stable.
- For Tet10: smoothing applies only to corner nodes; mid-edge nodes are recomputed afterwards (linear interpolation, or projection if TODO_08 already merged).

## Screen-visible acceptance check

**Setup** Load a complex STL (e.g. `assets/test_fixtures/bracket_dirty.stl`); mesh it (will produce some slivers). Press `Q` to see initial quality.

**Action** Click `Smooth Mesh (ODT)` (10 iterations default).

**Expected**
- Console: `[ODT] iter 1: q_min 0.08 → 0.18   iter 2: 0.18 → 0.27   ...` ending around `q_min ≥ 0.35`.
- HUD refresh: red regions visibly recede; mesh appears more uniform.
- No tet is inverted (verdict PASS in re-run quality report).

**Failure modes**
- `q_min` drops or one iteration shows `INVERSION DETECTED, rolled back N moves` → ODT validity guard works but smoother is too aggressive; reduce step size.
- `q_min` static → vertex–element map not built or boundary mask wrong (pinning all nodes).
- Viewer crashes → race in OpenMP smoother; check thread-private write to shared `originalVolumetricPositions`.

**Pass criterion** `q_min` strictly increases monotonically; HUD shows visible improvement; verdict remains PASS.

## Regression sentinel
`regression/odt_bracket.txt` — q_min before/after ODT on a fixed-seed mesh of `bracket_dirty.stl`. Future commits diff.

## Depends on
TODO_05.

## Estimated effort
2.5 days.
