# Session Lessons — TODO_04 STEP Loader + Analytic B-rep Retention

## Date
2026-05-19

---

## 1. Implementation Summary

TODO_04 adds STEP file loading with analytic B-rep retention via OpenCASCADE (OCCT). The B-rep is kept live on `FEAModel::brep` as a `unique_ptr<BRepHandle>` and used by `MeshQuality` to replace the discrete BVH forward pass with exact NURBS nearest-point queries — yielding 2–3 orders of magnitude better Hausdorff accuracy on curved geometry.

### Files created
- `include/BRepHandle.h` — OCC-free pImpl class
- `src/BRepHandle_impl.h` — internal OCC Impl struct (include from BRepHandle.cpp + StepLoader.cpp only)
- `src/BRepHandle.cpp` — nearestPointOnShape, normalAtNearest, principalCurvatures
- `include/StepLoader.h` — IGeometryLoader + loadWithBRep()
- `src/StepLoader.cpp` — full OCC pipeline
- `tools/gen_step_fixtures.cpp` — cube + sphere STEP generators
- `regression/step_cube_load.txt`, `regression/step_sphere_hausdorff.txt` — placeholder sentinels

### Files modified
- `include/FEAData.h` — `+sizingChordError = 1e-3f`
- `include/FEAModel.h` — `+brep`, `+hasBRep()`, `+loadSTEP()`, `+~FEAModel()` forward-declared
- `src/FEAModel.cpp` — loadSTEP(), loadFile() dispatch, brep.reset() in processRawGeometry, BRep fidelity dispatch
- `include/GeometryLoaderDispatch.h` — .step/.stp → StepLoader
- `src/main.cpp` — scanForModels() + STEP badge + status display
- `include/MeshQuality.h` — +usedExactBRep, BRep overload declarations
- `src/MeshQuality.cpp` — computeFidelity(ref, brep, …) OCC forward pass, emitFidelityReport BRep overloads
- `CMakeLists.txt` — USE_OCCT option, find_package(OpenCASCADE), OCCT DLL copy, gen_step_fixtures target

---

## 2. Key Algorithm Decisions

### pImpl pattern for OCC isolation
OCC headers are large (~GB of templates) and slow. The pImpl approach ensures only two TUs pay the OCC compile cost:
- `BRepHandle.cpp` — method implementations
- `StepLoader.cpp` — shape creation + mesh harvest

All other TUs (`FEAModel.cpp`, `MeshQuality.cpp`, `main.cpp`) include only `BRepHandle.h` (OCC-free). This keeps incremental build times fast.

**Rule**: When adding a large external library (OCCT, VTK, etc.), always isolate it behind a pImpl so only 1–2 TUs need to include its headers. The cost of defining a pImpl boundary is hours of saved build time across future sessions.

### find_package, NOT FetchContent for OCCT
OCCT takes ~2 hours to compile from source and has its own third-party dependency chain (FreeType, FreeImage, etc.). Use `find_package(OpenCASCADE CONFIG)` pointing at the official installer's `cmake/` directory. The user must install OCCT separately.

**Rule**: Never use FetchContent for large native libraries with complex build systems (OCCT, Boost, Qt, VTK, CGAL). Use find_package with an explicit install path.

### Tessellation parameters
```
lin_def = sizingChordError × L_diag  (default: 1e-3 → 0.1% chord error)
ang_def = 0.3 rad  (COMSOL default, ~17°)
parallel = true    (OpenMP inside OCC's mesher)
```
These are stored in `FEAParams::sizingChordError` so the user can tune them via the UI in a later TODO.

### Forward-only BRep improvement
The reverse fidelity pass (ref → vol boundary) still uses the existing `TriBVH`. Only the forward pass (vol boundary → input surface) uses OCC. This avoids duplicating the reverse pass machinery while still achieving the Hausdorff improvement on smooth surfaces (where the forward pass dominates the error).

---

## 3. Critical Care Points

### Face orientation — REVERSED faces need winding swap
OCCT's `TopAbs_REVERSED` orientation flag means the face's parametric normal is flipped relative to the solid's outward normal. When harvesting triangles from `Poly_Triangulation`, you MUST swap indices 1 and 2 for REVERSED faces:
```cpp
if (face.Orientation() == TopAbs_REVERSED) std::swap(n2, n3);
```
Failure: half the surface normals point inward → normal deviation ≈ 180° on half the mesh. This is the same class of bug as TODO_03 Bug 1 (TetGen `trifacelist` inward convention). Face orientation bugs produce unmistakable 180° normal deviation; look for that symptom first.

### FEAModel destructor (pImpl unique_ptr requirement)
`unique_ptr<BRepHandle>` in `FEAModel` requires `~BRepHandle()` to be visible at the point where `~FEAModel()` is emitted. Since `BRepHandle` is forward-declared in `FEAModel.h`:
- Declare `~FEAModel()` in `FEAModel.h` (do NOT `= default` there)
- Define `FEAModel::~FEAModel() = default;` in `FEAModel.cpp` where `BRepHandle.h` is included

Without this, the compiler emits the destructor inline in the header, seeing an incomplete type, and either the linker fails or `delete` produces UB.

**General rule**: Any class with `unique_ptr<ForwardDeclaredType>` as a member must have its destructor defined in a `.cpp` that includes the complete type header.

### loadSTEP ordering: processRawGeometry resets brep
`processRawGeometry()` calls `brep.reset()` to clear any stale B-rep from a previous load. The `loadSTEP()` function must therefore assign `brep` **after** calling `processRawGeometry()`, not before:
```cpp
if (!processRawGeometry(geo, "STEP")) return false;
brep = std::move(newBrep);  // ← AFTER, not before
```
The local variable `newBrep` survives the `processRawGeometry()` call safely.

### BRepHandle_impl.h — include only from OCC-aware TUs
`src/BRepHandle_impl.h` defines `BRepHandle::Impl` with `TopoDS_Shape` and other OCC types. It must never be included from any header or from any `.cpp` that is not OCC-aware. Doing so would pull OCC headers into general TUs and destroy the pImpl isolation.

Convention: all internal-only headers that define OCC types live in `src/` (not `include/`), since `src/` headers are not meant to be included transitively.

### BRepExtrema_DistShapeShape performance
Each OCC nearest-point query costs ~0.1–1ms depending on shape complexity. For 40k sample points this is 4–40 seconds — acceptable for a one-time quality report, not for per-frame queries. Parallelise with `#pragma omp parallel for` (BRepExtrema_DistShapeShape is thread-safe when each thread creates its own instance).

---

## 4. OCCT-Specific API Notes

### Shape healing
Always run `ShapeFix_Shape` after reading STEP. STEP files from various exporters often have open edges, slightly-inconsistent vertex tolerances, or bad face orientations. The healer fixes these before tessellation:
```cpp
ShapeFix_Shape fixer(shape);
fixer.Perform();
TopoDS_Shape healed = fixer.Shape();
```
Build face/edge/vertex maps **after** healing (face IDs may shift during healing).

### Unit detection
After `reader.TransferRoots(model)`, the cascade unit is available via:
```cpp
std::string unit = Interface_Static::Cval("xstep.cascade.unit");
// Returns "MM", "M", "INCH", etc.
```
`processRawGeometry` handles bbox normalisation regardless of units, so no manual conversion is needed. Log the unit for the user.

### Tessellation + triangle harvest pattern
```cpp
BRepMesh_IncrementalMesh mesher(shape, linDef, false, 0.3, true);
// mesher.Perform() is called by BRepMesh_IncrementalMesh ctor
// Then iterate faces and extract Poly_Triangulation:
for (TopExp_Explorer exp(shape, TopAbs_FACE); exp.More(); exp.Next()) {
    TopoDS_Face face = TopoDS::Face(exp.Current());
    TopLoc_Location loc;
    Handle(Poly_Triangulation) tri = BRep_Tool::Triangulation(face, loc);
    // tri->Node(i) gives gp_Pnt in local coords → apply loc.Transformation()
    // tri->Triangle(t).Get(n1, n2, n3) → 1-indexed node ids
    if (face.Orientation() == TopAbs_REVERSED) std::swap(n2, n3);
}
```

---

## 5. Workflow Lessons

### OCCT is not available in WSL2 build until user installs it
The implementation compiles cleanly with `USE_OCCT=OFF` (all code guarded by `#ifdef HAS_OCCT`). The user must install OCCT separately and set `-DOCCT_ROOT=<path>` before the STEP path becomes active. Document this clearly in the TODO DONE doc.

### Session continuity: verify PROGRESS.md state on resume
At the start of the second session for TODO_04, `PROGRESS.md` still showed "Steps 1-6 done, remaining" even though all 16 steps had been completed. Always update `PROGRESS.md` immediately after completing each step so resumption doesn't require re-reading the entire session.

### DONE documentation is the final deliverable
The convention (established in TODO_01, TODO_02, TODO_03) is to write:
1. `knowledge/TODOs/TODO_NN_DONE_documentation.md` — what was built, files, decisions
2. `knowledge/SESSION_LESSONS_TODO_NN.md` — lessons learned for future sessions
3. Update `knowledge/CASCADE_HANDOFF_PROMPT.md` — add new patterns to the shared briefing
4. Update `PROGRESS.md` to "DONE"

These are written at the end of the TODO session (or at context-limit handoff). They are the primary continuity mechanism between sessions.

---

---

## 6. Build & Installation Session (2026-05-19)

This section covers lessons from the separate session where OCCT was installed via vcpkg and the build was driven to a clean link.

### OCCT installation via vcpkg
```
D:\program_files_delta\vcpkg\vcpkg.exe install opencascade:x64-windows
```
Takes ~45–60 minutes on first run. Produces DLLs in `<vcpkg>/installed/x64-windows/bin/` and cmake config in `<vcpkg>/installed/x64-windows/share/opencascade/OpenCASCADEConfig.cmake`. No admin rights needed.

### find_package(OpenCASCADE) MUST come after project()

**Symptom**: "ADD_LIBRARY called with SHARED option but the target platform does not support dynamic linking. Building STATIC instead." Warning fires for every OCCT target; `OpenCASCADE_FOUND` is false.

**Root cause**: `find_package(OpenCASCADE)` was placed before `project()` in CMakeLists.txt. Before `project()`, CMake has not yet initialized platform capabilities (including shared library support). When OCCT's cmake config creates imported SHARED targets, CMake doesn't know the platform supports DLLs → silently converts them to STATIC → config then fails.

**Fix**: Move the entire `if(USE_OCCT) ... find_package(OpenCASCADE) ... endif()` block to after `project(FEAPreProcessor LANGUAGES C CXX)`.

**Rule**: Never call `find_package` for a package that creates imported library targets before `project()`. Always place such calls after `project()`.

### OpenCASCADE_DIR is more reliable than find_package PATHS

**Symptom**: `find_package(OpenCASCADE CONFIG QUIET PATHS "D:/path/to/share/opencascade")` finds the auto-detected dir (printed "OpenCASCADE_DIR auto-detected") but `OpenCASCADE_FOUND` remains false.

**Root cause**: The vcpkg toolchain wraps `find_package` via its `_find_package` mechanism. Explicit `PATHS` interact poorly with this wrapping — path-expansion heuristics may not resolve correctly.

**Fix**: Set `OpenCASCADE_DIR` cache variable directly before calling `find_package`. When `<PackageName>_DIR` is set, CMake skips the entire search and goes straight to that directory for the config file:
```cmake
if(NOT OpenCASCADE_DIR)
    foreach(_hint "D:/path/share/opencascade" ...)
        if(EXISTS "${_hint}/OpenCASCADEConfig.cmake")
            set(OpenCASCADE_DIR "${_hint}" CACHE PATH "" FORCE)
            break()
        endif()
    endforeach()
endif()
find_package(OpenCASCADE CONFIG QUIET)
```

**Rule**: When find_package with PATHS fails inexplicably (especially with a toolchain that wraps find_package), switch to setting `<PackageName>_DIR` directly. The `_DIR` variable is the most direct way to point CMake at a config file.

### Freetype transitive dependency requires explicit CMAKE_PREFIX_PATH

**Symptom**: `OpenCASCADE_DIR` is set and found, but `OpenCASCADE_FOUND` is still false (or config execution fails silently).

**Root cause**: `OpenCASCADEConfig.cmake` calls `find_dependency(Freetype MODULE)`. Even though Freetype is installed by vcpkg, `CMAKE_PREFIX_PATH` may not include the vcpkg prefix at the time this runs (toolchain setup timing, or config running before the toolchain has fully executed).

**Fix**: Explicitly prepend the vcpkg install prefix to `CMAKE_PREFIX_PATH` before `find_package(OpenCASCADE)`:
```cmake
set(_VCPKG_INSTALLED "D:/program_files_delta/vcpkg/installed/x64-windows")
if(EXISTS "${_VCPKG_INSTALLED}")
    list(PREPEND CMAKE_PREFIX_PATH "${_VCPKG_INSTALLED}")
endif()
```

**Rule**: When a library's cmake config calls `find_dependency()` for its own transitive deps, those deps must be visible via `CMAKE_PREFIX_PATH` — not just via the toolchain's delayed setup. Prepend the install prefix explicitly when reliability matters.

### OCCT 7.9 module renames

The STEP I/O toolkit was reorganised between OCCT 7.7/7.8 and 7.9:

| Old name | New name |
|---|---|
| `TKSTEP` | `TKDESTEP` |
| `TKSTEPBase` | merged into `TKDESTEP` |
| `TKSTEPAttr` | merged into `TKDESTEP` |
| `TKSTEP209` | merged into `TKDESTEP` |
| (new) | `TKDE` (data exchange framework) |

Always check `ls <vcpkg>/installed/x64-windows/lib/TK*.lib` when upgrading OCCT versions. Module names are not stable across major versions.

### Interface_Static::CVal capitalisation (OCCT 7.9 API change)

`Interface_Static::Cval()` was renamed to `Interface_Static::CVal()` in OCCT 7.9 (capital V). Error: `C2039: 'Cval': is not a member of 'Interface_Static'`. Fix: update all call sites.

**Rule**: After any OCCT version upgrade, grep for changed function names before building. Check the header directly: `grep -i "cval\|setcval" Interface_Static.hxx`.

### BRepHandle.h dual-class pattern for graceful HAS_OCCT=0

**Problem**: `MeshQuality.cpp`'s BRep overloads call `brep.numFaces()`, `brep.nearestPointOnShape()` etc. unconditionally (no `#ifdef HAS_OCCT` in the call sites — the stubs are supposed to handle the no-OCC case). This means any target linking `MeshQuality.cpp` needs `BRepHandle` method implementations at link time. `mesh_diag` doesn't link `BRepHandle.cpp`, causing three unresolved externals.

**Failed attempt**: Added `BRepHandle.cpp` to `mesh_diag` sources. This then failed with `C2027: use of undefined type 'BRepHandle::Impl'` because the `create(Impl impl)` function signature requires the complete `Impl` type, which only exists when `HAS_OCCT=1`.

**Root cause of the root cause**: The pImpl class has `struct Impl;` forward-declared, and `create(Impl impl)` takes it by value. A by-value parameter requires the complete type even just to compile the function signature. When `HAS_OCCT=0`, `Impl` is never defined → compile error.

**Correct fix**: Provide inline stubs in `BRepHandle.h` for the `HAS_OCCT=0` case. When `HAS_OCCT` is not defined, `BRepHandle` is a completely different (stub) class with all methods inline:
```cpp
#ifdef HAS_OCCT
class BRepHandle { struct Impl; unique_ptr<Impl> impl_; ... };  // needs BRepHandle.cpp
#else
class BRepHandle {                                               // fully inline, no .cpp needed
    int numFaces() const { return 0; }
    glm::dvec3 nearestPointOnShape(glm::dvec3 q) const { return q; }
    ...
};
#endif
```
`BRepHandle.cpp` is wrapped entirely in `#ifdef HAS_OCCT` since the stubs make it unnecessary for `HAS_OCCT=0` targets.

**Rule**: When a class has both a full pImpl (OCC-aware) and a stub (OCC-free) version, put BOTH inside the same header behind `#ifdef`. Don't put stubs in a `.cpp` that gets linked to lightweight targets — they'll drag in compilation problems. Inline stubs in the header are zero-cost and always available.

---

*Author: Claude Sonnet 4.6 — 2026-05-19*
