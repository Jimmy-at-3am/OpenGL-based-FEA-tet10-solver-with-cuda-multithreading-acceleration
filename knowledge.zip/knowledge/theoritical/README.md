---
title: FEA Meshing Algorithms — Knowledge Vault
type: index
tags: [moc, fea, meshing]
created: 2026-05-16
---

# FEA Meshing Algorithms — Map of Content

A technical knowledge base for **computationally efficient and accurate** finite-element mesh generation, written for an algorithm engineer working across COMSOL, ANSYS, and MATLAB. The vault prioritises the state of the art (2018–2025) and is organised so that — given any geometry class (planar, smooth curved manifold, CAD B-rep with sharp features, implicit/CSG, thin shell, dirty/non-manifold) — one can navigate directly to the algorithm best suited for it.

> [!tip] How to read this vault
> Start with [[00_Overview_and_Taxonomy]] to choose an algorithm by **input geometry class**. Foundations live in [[01_Mathematical_Foundations]] and [[02_Mesh_Quality_Metrics]]. Each subsequent note is a self-contained algorithm chapter with maths, pseudocode, complexity, and a "when to use" rubric.

---

## 0. Orientation

- [[00_Overview_and_Taxonomy]] — decision tree mapping geometry class → algorithm family; comparison of element types (Tet4/Tet10/Hex8/Hex20/poly).
- [[01_Mathematical_Foundations]] — Voronoi/Delaunay duality, simplicial complexes, smooth manifolds, Riemannian metric tensors, CVT energy, restricted Voronoi diagrams.
- [[02_Mesh_Quality_Metrics]] — radius-edge ratio, aspect ratio, skewness, scaled Jacobian, condition number, Knupp shape measures.

## 1. Volume / Solid Meshing Algorithms

- [[04_Delaunay_CDT_and_TetGen]] — Bowyer–Watson incremental Delaunay, Ruppert–Shewchuk refinement, Constrained Delaunay Tetrahedralization (CDT(3)), TetGen 1.6 / Si 2015.
- [[05_Frontal_Delaunay_and_Advancing_Front]] — Gmsh's hybrid frontal-Delaunay (Rémacle 2013), classical AFM (Löhner, Peraire), BAMG.
- [[06_Octree_BCC_and_Isosurface_Stuffing]] — isosurface stuffing (Labelle–Shewchuk 2007), BCC lattice tets, octree dual contouring, finite cell / CutFEM.
- [[07_Polyhedral_Mosaic_and_Voronoi]] — ANSYS Fluent Mosaic poly-hex core (2019R1+), COMSOL polyhedral conversion, MPolyMesher, virtual-element-method-friendly meshes.
- [[09_Robust_TetWild_for_Dirty_Geometry]] — Hu et al. 2018 *TetWild*, *fTetWild* (Hu 2020): the canonical answer for non-manifold/self-intersecting CAD.
- [[10_Hex_QuadMeshing_FrameFields]] — frame/cross-field hex meshing, polycubes, *Instant Meshes* (Jakob 2015), integer-grid maps.

## 2. Surface Meshing (Curved Manifolds)

- [[03_Surface_Meshing_Curved_Manifolds]] — discrete parametrization (Tutte, LSCM, ABF, SCP), restricted CVT on surfaces (Yan–Lévy), curvature-adapted sizing fields, NURBS B-rep conforming meshing.

## 3. Adaptation & Optimisation

- [[08_Anisotropic_Metric_Adaptation]] — Riemannian metric tensors, log-Euclidean interpolation, MMG3D (Dapogny–Dobrzynski–Frey), Loseille–Alauzet metric-based adaptation, feflo.a.
- [[11_Adaptive_Refinement_hp_and_DWR]] — Zienkiewicz–Zhu recovery, residual a posteriori, dual-weighted residual (DWR / goal-oriented), h-, p-, r-, hp-adaptive cycles in COMSOL/ANSYS/MATLAB.
- [[12_Mesh_Smoothing_CVT_and_ODT]] — Laplacian, Lloyd, Optimal Delaunay Triangulation (Chen–Holst), L-BFGS CVT (Liu 2009), topology operators (edge/face swap, vertex insertion).

## 4. Emerging Methods (2020–2025)

- [[13_ML_and_Neural_Mesh_Generation]] — MeshGraphNets (Pfaff 2020), neural mesh sizing fields, GNN-based adaptive remeshing, *DeepMesh* / *MeshingNet*.

## 5. Commercial / Open-Source Stack

- [[14_Software_Comparison_Matrix]] — COMSOL 6.3, ANSYS 2024R2 (Mosaic, Fluent Meshing), MATLAB R2024b PDE Toolbox, plus Gmsh 4.13 / TetGen 1.6 / MMG / CGAL.

## 6. References

- [[15_References_Bibliography]] — annotated bibliography with Google Scholar links, version release notes from COMSOL/ANSYS/MATLAB, and benchmark datasets (Thingi10K, ABC, PARSEC).

## 7. Project-Specific

- [[16_PolyFEA_Implementation_Guide]] — bridges the vault's theory to PolyFEA's actual code; per-file roadmap, quick wins, medium-term integration of fTetWild / ODT / adaptive cycle.

---

## Recommended reading paths

| Persona / goal | Path |
|---|---|
| **Robust tetra-meshing from any CAD** | [[09_Robust_TetWild_for_Dirty_Geometry]] → [[04_Delaunay_CDT_and_TetGen]] → [[12_Mesh_Smoothing_CVT_and_ODT]] |
| **CFD boundary-layer mesh** | [[07_Polyhedral_Mosaic_and_Voronoi]] → [[08_Anisotropic_Metric_Adaptation]] |
| **Implicit / level-set / CSG** | [[06_Octree_BCC_and_Isosurface_Stuffing]] → [[09_Robust_TetWild_for_Dirty_Geometry]] |
| **Curved-shell / NURBS surface mesh** | [[03_Surface_Meshing_Curved_Manifolds]] → [[10_Hex_QuadMeshing_FrameFields]] |
| **Goal-oriented adaptivity for FEA** | [[11_Adaptive_Refinement_hp_and_DWR]] → [[08_Anisotropic_Metric_Adaptation]] |
| **Algorithmic survey** | [[00_Overview_and_Taxonomy]] → [[01_Mathematical_Foundations]] → [[15_References_Bibliography]] |

---

## Conventions

- LaTeX maths in standard `$...$` / `$$...$$` blocks. Equations follow the notation in the project-root [theory.md](../theory.md).
- Pseudocode in fenced blocks with language tag `text`.
- Wiki-links `[[note-name]]` resolve within this folder.
- Tags follow `#topic/subtopic` style; the most useful are `#delaunay`, `#anisotropic`, `#hex-mesh`, `#robust`, `#adaptive`, `#commercial-comsol`, `#commercial-ansys`, `#commercial-matlab`.
