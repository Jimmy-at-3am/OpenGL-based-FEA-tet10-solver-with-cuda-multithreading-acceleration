---
title: Polyhedral, Mosaic, and Voronoi Meshing
type: algorithm
tags: [polyhedral, voronoi, mosaic, ansys, cfd, vem, polymesher]
created: 2026-05-16
---

# 07 — Polyhedral, Mosaic, and Voronoi Meshing

Polyhedral meshes are general $n$-faced volumes (the Voronoi cells of an underlying point set). They have entered mainstream CFD because of three compelling properties:

1. **Lower cell count** — typically 3–5× fewer cells than tetrahedral meshes of equivalent accuracy.
2. **Higher-order finite-volume reconstruction** — every interior face sees more neighbours, improving gradient estimates.
3. **Naturally locally-conservative** in finite volume — the **face-based** structure is what the FV operator wants.

For **structural FEA**, polyhedral elements were impractical until the **Virtual Element Method** (VEM, Beirão da Veiga 2013) made it possible to handle them. ANSYS Mechanical 2023R1 added preliminary VEM support; COMSOL 6.x has had polyhedral *conversion* (post-tet) since 5.6.

This note covers:

1. Voronoi-based volume meshing — §1–2
2. ANSYS Fluent's **Mosaic** poly-hex core technology (2019R1+) — §3
3. Polyhedral **boundary layers** (Voronoi BL, 2021R1+) — §4
4. Practical polyhedral construction in COMSOL & open-source — §5
5. Polygonal/polyhedral methods for FEA: VEM, MFD, PolyMesher — §6

Foundations: [[01_Mathematical_Foundations]] §2 (Voronoi/Delaunay duality); see also [[12_Mesh_Smoothing_CVT_and_ODT]] for the CVT smoothing that drives polyhedral quality.

---

## 1. Voronoi Volume Meshes — Construction

The fundamental recipe (e.g., used by Fluent's poly-convert and OpenFOAM `polyMesh`):

```text
input: tet mesh T = (V, T_e)    output: polyhedral mesh P
1. For each interior tet, compute its circumcentre c_T
2. For each surface-incident tet, compute a boundary-adjusted centre
3. For each Voronoi-cell-around-vertex v in V:
       collect circumcentres c_T of incident tets, ordered around v
       form polygonal faces between adjacent c_T and the boundary
4. Smooth polyhedral vertices with Lloyd / L-BFGS CVT on the surface
5. Repair near-boundary cells by direct construction (preserving B-rep faces)
```

This is the **tet-to-poly conversion** workflow. A purer (dual) approach builds the Voronoi diagram directly from a point set — used in ANSYS Mosaic (§3) and in MPolyMesher (§6).

### 1.1 Centroidal Voronoi quality

Polyhedral cell quality improves dramatically when the underlying point set is a **CVT** (cells become symmetric, low-curvature, more uniform). Lloyd / L-BFGS iterations as in [[12_Mesh_Smoothing_CVT_and_ODT]] §1–2 are essential: ANSYS Mosaic and Fluent poly-convert both run CVT smoothing as a post-process.

### 1.2 Conformity at the boundary

The Voronoi cells of vertices on the input boundary are **clipped** by the surface mesh. This destroys the CVT property locally but preserves the geometric fidelity. The clipped cells (boundary-incident polyhedra) may have many faces and need extra care — Fluent inserts **prismatic transition cells** if the clip is too aggressive.

---

## 2. Why Polyhedral for CFD

The key cost-quality argument (used in ANSYS marketing material but founded on real numerics):

| Comparison | Tet | Poly | Ratio |
|---|---|---|---|
| Face neighbours / cell | 4 | $\sim$ 12-15 | 3× |
| Gradient stencil radius | 1-ring | <1-ring | tighter |
| Cells for given accuracy | $N$ | $N/4 \sim N/5$ | 1/4 |
| Memory (face-based FV) | $\sim4N$ | $\sim13N/4\approx3.3N$ | 0.83 |
| Convergence iterations | baseline | 0.7-0.9× | accelerated |
| Wall-clock per solve | baseline | 0.4-0.6× | halved |

These numbers reflect Fluent benchmark suites; the Mosaic poly-hex hybrid (§3) tightens them further.

---

## 3. ANSYS Mosaic Poly-Hex Core (2019R1+)

Mosaic is ANSYS Fluent Meshing's flagship technology since release 19.1. Its differentiating idea:

**Use hex elements in the bulk (highest quality, lowest cell count) and polyhedra at the transition to prism/tet layers (eliminating skewed transition tets).**

### 3.1 Workflow

```text
1. Surface mesh of the wetted geometry (Frontal-Delaunay, tri/quad)
2. Boundary-layer prism extrusion (T-Rex / advancing front) - see [[05_Frontal_Delaunay_and_Advancing_Front]]
3. Cartesian HEX dominant fill of bulk volume
       octree-graded sized to the local sizing field
4. POLY transition zone between prism stack and hex core:
       Mosaic conformally interfaces the two with polyhedral cells
       NO ortho-skew problem (which plagued tet transitions)
5. Optimise: CVT-style smoothing of all polyhedral vertices
```

### 3.2 Performance

ANSYS reports (Fluent UG 2024R2 §"Mosaic Meshing"):

- 30–50% cell reduction vs. equivalent tet mesh.
- 20–30% solver iteration count reduction.
- 30–40% wall-time reduction.

These are routinely observed on automotive aero and gas-turbine benchmarks.

### 3.3 Variants

- **Mosaic Poly-Hex** (default since 19R1) — hex bulk, poly transition.
- **Mosaic Poly-Prism** (since 20R1) — applies inside curved BL regions.
- **Mosaic Voronoi BL** (since 21R1) — see §4.

---

## 4. Voronoi Boundary Layers (Mosaic 2021R1+)

The classical prism-BL has a structural limitation: **all stacks must have the same number of layers per spine** along the wall. Around tight corners or stagnation points, this leads to crushed prisms or unnecessary cells elsewhere.

**Voronoi BL** breaks this constraint. Each surface element gets its own stack count; transitions between stacks of different heights are handled by polyhedral cells (Voronoi dual of the prism vertex set), preserving conformity and quality.

### 4.1 Algorithm sketch

```text
1. For each surface element f, compute target n_layers based on local sizing
2. Build prism stack of n_layers above f
3. Where adjacent stacks have different counts:
       insert poly transition cells (Voronoi dual of stack-top vertices)
4. Above the BL: standard Mosaic poly-hex core
```

Useful when the surface has wildly varying curvature (e.g., a vehicle with sharp wheel arches against smooth roofs): the layer thickness can be very fine on the curved parts and coarser elsewhere, with no cell wastage.

---

## 5. Polyhedral Meshing in COMSOL & Open-Source

### 5.1 COMSOL 6.x

COMSOL builds a tet mesh first (via its frontal-Delaunay 3-D mesher) and then offers an explicit **Polyhedral conversion** sweep step (since 5.6, default in 6.3 for CFD physics):

```text
Mesh → Convert → Polyhedra
  - control: target average face count (default 12)
  - quality threshold: rejects conversions below 0.1 (default)
```

Internally COMSOL uses tet-vertex Voronoi duals clipped to the surface, with a post-CVT smoothing pass.

### 5.2 OpenFOAM `polyDualMesh`

```bash
polyDualMesh -concaveMultiCells 60
```

Builds the polyhedral dual of a tet input. Less sophisticated than Mosaic — no hex core, no anisotropic BL — but free and adequate for many cases.

### 5.3 StarCCM+

Provides native polyhedral generation since 4.x; the Mosaic-equivalent technology is **Trimmed Cell** (a different cut-cell paradigm, more akin to FCM in spirit — see [[06_Octree_BCC_and_Isosurface_Stuffing]] §5).

---

## 6. Polygonal/Polyhedral Methods for Structural FEA

Polygonal elements break the classical isoparametric framework: there is no fixed reference shape. Two modern frameworks make them tractable:

### 6.1 Virtual Element Method (VEM) — Beirão da Veiga et al. 2013

VEM defines the discrete space implicitly, without explicit basis functions on the physical element. Two ingredients per element:

1. **Polynomial projector** $\Pi^\nabla_k:V_h(P)\to\mathcal{P}_k(P)$ — projects onto polynomials of degree $\le k$.
2. **Stabilisation** $S^P(v,v)\approx h^d\|v\|^2$ — pays for the non-polynomial part.

The element stiffness:

$$
K^P = K^P_{\text{consistency}} + K^P_{\text{stabilisation}} = \int_P (\Pi^\nabla u)^T D (\Pi^\nabla v)\,dx + S^P(u-\Pi^\nabla u, v-\Pi^\nabla v).
$$

Optimal-order convergence on **arbitrary star-shaped polygons / polyhedra**. ANSYS Mechanical 2023R1+ ships VEM for tet-to-poly conversion in structural workflows; COMSOL 6.3 has experimental VEM for the *Solid Mechanics* module.

### 6.2 Wachspress / Mean-Value / Harmonic Coordinates

Generalised barycentric coordinates on polygons:

| Coordinate | Property | Cost |
|---|---|---|
| **Wachspress** (1975) | rational, $C^\infty$ inside convex polygons | closed-form |
| **Mean-value** (Floater 2003) | extends to non-convex, $C^0$ | closed-form |
| **Harmonic** (Joshi 2007) | solves Laplace inside polygon | linear solve / cell |

Used directly as shape functions in **PolyFEM** and **PolyMesher**'s elastic solver.

### 6.3 Mimetic Finite Differences (MFD) — Brezzi et al. 2005

Older cousin of VEM; integrates by parts at the **discrete** level, producing a method that satisfies a discrete Stokes theorem on arbitrary polyhedra. Workhorse in subsurface flow simulators (Schlumberger Eclipse, Open Porous Media).

### 6.4 PolyMesher / MPolyMesher (Talischi 2012; Park 2019)

MATLAB framework for generating CVT-based polygonal meshes and running VEM-style topology optimisation. Standard reference for topology optimisation on polygonal grids.

---

## 7. When to Use Polyhedral

| Scenario | Verdict |
|---|---|
| **CFD, anything turbulent** | strongly recommended — Mosaic-class for production |
| **Aero / external flow** | YES — Mosaic poly-hex |
| **Internal flow with thin BL** | YES — Mosaic Voronoi BL |
| **Structural FEA, linear elastic** | acceptable via VEM, but Tet10 still safer; use if your code supports it |
| **Structural FEA, contact / plasticity** | NO — VEM theory not as mature |
| **Topology optimisation** | YES — PolyMesher / MPolyMesher idiomatic |
| **Multi-physics coupling** | depends on solver — COMSOL has it; many third-party do not |

---

## 8. References

- L. Beirão da Veiga, F. Brezzi, A. Cangiani, G. Manzini, L. D. Marini, A. Russo, "Basic principles of virtual element methods," *Math. Models Methods Appl. Sci.* 23, 2013.
- F. Brezzi, K. Lipnikov, M. Shashkov, "Convergence of the mimetic finite difference method for diffusion problems on polyhedral meshes," *SIAM JNA* 43, 2005.
- C. Talischi, G. H. Paulino, A. Pereira, I. F. M. Menezes, "PolyMesher: a general-purpose mesh generator for polygonal elements written in Matlab," *Struct. Multidiscip. Optim.* 45, 2012.
- E. L. Wachspress, *A Rational Finite Element Basis*, Academic Press, 1975.
- M. S. Floater, "Mean value coordinates," *CAGD* 20, 2003.
- ANSYS Fluent Meshing 2024 R2 *User's Guide* §"Mosaic Mesh Generation" and §"Voronoi Boundary Layers".
- ANSYS Mechanical 2024 R2 *Theory Reference* §"Virtual Element Method".
- COMSOL 6.3 *Reference Manual* §"Polyhedral Mesh".
- SCK Garimella et al., "Polyhedral mesh generation for finite-volume CFD," *AIAA SciTech* 2024.
