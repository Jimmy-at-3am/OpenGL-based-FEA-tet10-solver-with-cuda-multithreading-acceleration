# TODO_02 — Quality Library: Full Metrics Set — Implementation Plan

## Plan Date
2026-05-17

---

## 0. Scope Summary (from `TODO_02_quality_library_and_metrics_extension.md`)

Extend the existing `MeshQuality` library (delivered in TODO_01) so that the
post-meshing console report includes:

- **New metrics**: radius ratio, max dihedral, equiangular skew, Tet10
  isoparametric Knupp, Tet10 scaled Jacobian.
- **New histogram**: equiangular skew (4 bins matching the spec).
- **Per-metric percentile table**: `p05 / p50 / p95 / p99` for Knupp,
  min dihedral, scaled Jacobian, equiangular skew.

Must work for both Tet4 (TetGen output) and Tet10 (post `generateMidEdgeNodes`).

---

## 1. Inventory: What Already Exists vs. What Is Missing

### Already implemented (from TODO_01)
| Symbol | Location |
|--------|----------|
| `knuppShape(p0..p3)` | `src/MeshQuality.cpp` ~line 59 |
| `minDihedralDeg(p0..p3)` | `src/MeshQuality.cpp` ~line 100 |
| `scaledJacobianMin(p0..p3)` (Tet4 corner-based) | `src/MeshQuality.cpp` ~line 155 |
| `KnuppHistogram` struct | `include/MeshQuality.h` ~line 69 |
| `ElemQuality` struct (knupp, dihedralMin, sJac, centroid) | `include/MeshQuality.h` ~line 58 |
| `QualityReport` struct (knupp + min-dihedral + sJac stats, worstN) | `include/MeshQuality.h` ~line 79 |
| `computeReport()` (Tet4 only) | `src/MeshQuality.cpp` ~line 280 |
| `emitReport()` | `src/MeshQuality.cpp` ~line 423 |

### To add (TODO_02)
| New symbol | Purpose |
|-----------|---------|
| `radiusRatio(p0..p3)` | ρ = 3r/R (in-radius / circum-radius) |
| `maxDihedralDeg(p0..p3)` (or refactor `minDihedralDeg` → `dihedralRange`) | for skew-related diagnostics |
| `equiangularSkew(p0..p3)` | `S = (V_equi(R) − V_T) / V_equi(R)` |
| `tet10ScaledJacobianMin(p0..p9)` | min over the 4 Hammer points |
| `tet10IsoparametricKnupp(p0..p9)` | Knupp averaged over the 4 Hammer points |
| `SkewHistogram` struct | 4 bins: [0,0.25), [0.25,0.5), [0.5,0.8), [0.8,1] |
| Percentile fields per metric in `QualityReport` | `p05/p50/p95/p99` × 4 metrics |
| Tet4-vs-Tet10 dispatch in `computeReport` | branch on element type |
| Skew + percentile section in `emitReport` | per spec |

---

## 2. Step-by-Step Implementation Plan

### Step 1 — Header Extensions (`include/MeshQuality.h`)

1. **Extend `ElemQuality`** with:
   ```cpp
   double radiusRatio       = 0.0;   // ρ = 3r/R, 0..1 (1 == regular)
   double dihedralMaxDeg    = 0.0;   // largest of the 6 dihedrals, deg
   double equiangularSkew   = 0.0;   // S in [0, 1]
   ```

2. **Add `SkewHistogram`**:
   ```cpp
   struct SkewHistogram {
       std::size_t bin_0_25   = 0;   // [0.00, 0.25)
       std::size_t bin_25_50  = 0;   // [0.25, 0.50)
       std::size_t bin_50_80  = 0;   // [0.50, 0.80)
       std::size_t bin_80_100 = 0;   // [0.80, 1.00]
   };
   ```

3. **Add `MetricPercentiles`**:
   ```cpp
   struct MetricPercentiles {
       double p05 = 0.0, p50 = 0.0, p95 = 0.0, p99 = 0.0;
   };
   ```

4. **Extend `QualityReport`** with:
   ```cpp
   SkewHistogram     skewHist;
   MetricPercentiles knuppPct;
   MetricPercentiles dihedralMinPct;
   MetricPercentiles scaledJacPct;
   MetricPercentiles skewPct;
   bool              isTet10 = false;   // echoed in header so user knows which sampler ran
   ```

5. **Document** in comments that `scaledJacobian` and `knupp` in `ElemQuality`
   carry the **isoparametric** values when the input is Tet10.

### Step 2 — New Free Functions in Anonymous Namespace (`src/MeshQuality.cpp`)

All per-element shape functions go under the existing
`namespace { ... }` near the top of the file, beside `knuppShape`,
`minDihedralDeg`, `scaledJacobianMin`.

#### 2.1 `radiusRatio(p0..p3)`
- `r = 3 V / A_total` where `V = (1/6)|det|`, `A_total = sum of 4 face areas`.
- `R = |p1−p0| ⋅ |p2−p0| ⋅ ... / (24 V)` via standard circumradius formula.
- Return `3r/R`, clamped to `[0,1]`.
- **Care-point**: if `V < 1e-30` or `A_total < 1e-30` return `0`.

#### 2.2 `dihedralRangeDeg(p0..p3)` → `(thetaMin, thetaMax)`
- Refactor `minDihedralDeg` into a new function that returns both extremes via
  `std::pair<double, double>` or out-parameters. Keep an inline wrapper that
  preserves the `minDihedralDeg` signature so existing callers compile.
- All 6 edges processed in one loop; track `minDeg` and `maxDeg`.
- **Care-point #16**: clamp `cosTh` before `acos`.

#### 2.3 `equiangularSkew(p0..p3)`
- ANSYS convention (volume-based, not angle-based):
  ```
  R_circum = circumradius
  V_equi   = (8 √3 / 27) R_circum^3      // volume of regular tet sharing R
  V_T      = |det| / 6
  S        = (V_equi − V_T) / V_equi     in [0, 1]
  ```
- **Care-point**: clamp `S` to `[0, 1]`; numerical noise can push it slightly
  above 1 for nearly-degenerate tets.
- **Care-point**: if `R_circum < 1e-30` return `1.0` (fully degenerate).

#### 2.4 `tet10ScaledJacobianMin(const std::array<glm::dvec3,10>& p)`
- Use the same 4 Hammer points as the solver:
  ```cpp
  constexpr double GP_A = 0.5854101966249685;
  constexpr double GP_B = 0.1381966011250105;
  constexpr double gp[4][3] = {
      {GP_A, GP_B, GP_B},
      {GP_B, GP_A, GP_B},
      {GP_B, GP_B, GP_A},
      {GP_B, GP_B, GP_B}
  };
  ```
- For each Gauss point: build the 3×3 isoparametric Jacobian
  `J = sum_i x_i * dN_i/dxi` (10 nodes), then compute the **scaled** form:
  ```
  J_scaled = det(J) / (||J col 0|| * ||J col 1|| * ||J col 2||)
  ```
- Return min over the 4 Gauss points. Range `[-1, 1]`.
- **Reuse** `Tet10Element::EvalShapeGradients` if accessible from MeshQuality;
  otherwise duplicate the 10-node gradient formulas locally (10×3 matrix) — a
  ~30-line static function — to avoid coupling MeshQuality to the solver.
- **Decision: duplicate locally**, because MeshQuality is already a stand-alone
  library used by `mesh_diag` (no `IMaterial` / `Eigen` dependency).

#### 2.5 `tet10IsoparametricKnupp(const std::array<glm::dvec3,10>& p)`
- Same 4 Hammer points.
- At each: form `J`, compute `q = K * 3 * det(J)^(2/3) / ||J||_F^2` with
  `K = 2^(1/3)`.
- Return **average** over the 4 points (per spec wording “averaged”).
  Clamp to `[0, 1]`.

### Step 3 — Refactor `computeReport()` (`src/MeshQuality.cpp`)

1. **Detect element type**:
   ```cpp
   const bool isTet10 = (out.numberofcorners == 10);
   ```
   `tetgenio::numberofcorners` is the right field: TetGen sets it to 4 for
   Tet4 and 10 for Tet10 (when called with `-o2`). For our pipeline we run
   TetGen Tet4 then call `FEAModel::generateMidEdgeNodes()`, so the report
   ALWAYS sees Tet4 from `tetgenio` directly. We need a SECOND entry point
   for Tet10 reports — see Step 5.

2. **Per-element loop** — extend the existing parallel-for to compute:
   ```
   knuppArr, dihedralMinArr, dihedralMaxArr, sJacArr,
   radiusRatioArr, skewArr
   ```
   Plus thread-local `KnuppHistogram` and `SkewHistogram` bins.

3. **Bin merge** — extend the serial merge to also merge `skewHist` bins.

4. **Percentile computation** — add helper:
   ```cpp
   MetricPercentiles percentiles(std::vector<double> v) {
       auto pick = [&](double pct) {
           if (v.empty()) return 0.0;
           const std::size_t k = std::min<std::size_t>(
               v.size() - 1,
               static_cast<std::size_t>(std::floor(pct * (v.size() - 1) + 0.5)));
           std::nth_element(v.begin(), v.begin() + k, v.end());
           return v[k];
       };
       MetricPercentiles mp;
       mp.p05 = pick(0.05);
       mp.p50 = pick(0.50);
       mp.p95 = pick(0.95);
       mp.p99 = pick(0.99);
       return mp;
   }
   ```
   Each call uses an O(N) `nth_element` on a copy → 4 calls × 4 metrics = 16
   linear passes total, still O(N).

5. **Edge case**: if `nTets < 100`, `p99` collapses onto `max`; document this
   in code comment per TODO_02 failure-mode note.

### Step 4 — Update `emitReport()` (`src/MeshQuality.cpp`)

Insert two new blocks between the existing `scaled Jacobian` summary and
`Worst-N` block:

```text
  equiangular skew: [0.00, 0.25): A   [0.25, 0.50): B   [0.50, 0.80): C   [0.80, 1.00]: D
  percentiles
    Knupp           p05=0.32 p50=0.78 p95=0.94 p99=0.97
    min dihedral    p05=24.1 p50=58.4 p95=68.9 p99=70.5
    scaled Jacobian p05=0.42 p50=0.91 p95=0.99 p99=1.00
    skew            p05=0.03 p50=0.13 p95=0.41 p99=0.62
```

Element-type label in header:
```text
[Mesh] Quality Report (Tet4, radius-edge ratio bound: 1.20, min-dihedral: 10.0 deg)
```
(or `Tet10` when `r.isTet10 == true`).

### Step 5 — Tet10 Entry Point (`include/MeshQuality.h`, `src/MeshQuality.cpp`)

`tetgenio` only carries Tet4 connectivity in our pipeline. Add an overload
that takes Tet10 corner+midnode data directly:

```cpp
QualityReport computeReportTet10(
    const std::vector<glm::vec3>& positions,        // == originalVolumetricPositions
    const std::vector<unsigned>&  tet10Connectivity, // == tetrahedraQuadratic, 10*nElems
    const FEAParams&              p);

void emitReportTet10(
    const std::vector<glm::vec3>& positions,
    const std::vector<unsigned>&  tet10Connectivity,
    const FEAParams&              p,
    std::ostream&                 os = std::cout);
```

Internally these factor through a private `computeReportImpl` templated on a
"per-element corner extractor" lambda so the Tet4 and Tet10 paths share the
parallel loop, percentile pipeline, and emission code.

### Step 6 — Wire `FEAModel.cpp`

1. After `generateVolumetricMesh()` calls `MeshQuality::emitReport(out, params)`
   (Tet4 path), also call `emitReportTet10(...)` if the user has already
   promoted to Tet10 (currently NOT done by the meshing button — Tet10
   promotion happens only when the solver runs). For TODO_02's acceptance
   check the Tet4 report is sufficient; the Tet10 path is exposed for future
   use by TODO_05 / TODO_08 polish loops.

2. Remove the obsolete TODO_01 stub comment block at the
   `MeshQuality::emitReport(out, params);` call site.

### Step 7 — Multithreading Pattern

Mirror the existing TODO_01 pattern:
- `#pragma omp parallel for schedule(static)` over elements when
  `p.useMultithreading == true`.
- Thread-local `KnuppHistogram`, `SkewHistogram` accumulators in
  `tlBins[omp_get_thread_num()]`.
- Serial reduction loop after the parallel block.
- Percentile computation is serial (`nth_element` does not parallelise well
  for our typical N < 1M); document this.

### Step 8 — Numerical Care Points (per TODO_02 spec)

| # | Care point | Where |
|---|-----------|-------|
| 2 | Knupp denominator guard `det < 1e-30` → 0 | `knuppShape`, Tet10 isoparametric knupp |
| 16 | `acos` clamp `[-1, 1]` | `dihedralRangeDeg` |
| — | Skew normalised to `[0, 1]`, **not** in degrees | `equiangularSkew` |
| — | Tet10 sJ uses **exactly** the 4 Hammer points, not more | `tet10ScaledJacobianMin` |
| — | Skew formula uses circumradius-based `V_equi`, not angle deviation | `equiangularSkew` |

### Step 9 — Regression Sentinel

Append to `regression/cube_default.txt`:
```
skew_p50         = ...
radiusRatio_p50  = ...
```
plus the 16 percentile values once the implementation passes manual smoke
test on the cube fixture. Future commits diff against this file.

---

## 3. Verification & Acceptance Plan

### Build
```powershell
.\build.bat build
```
Must compile clean.

### Manual smoke test
1. Launch `FEAPreProcessor.exe`.
2. Cube mode, default 1×1×1.
3. Click `GENERATE 3D MESH`.
4. Confirm console output now contains:
   - `equiangular skew:` histogram line.
   - `percentiles` block with **all four** metric rows
     (`Knupp`, `min dihedral`, `scaled Jacobian`, `skew`).
5. Confirm header shows `Tet4` element-type label.

### Failure-mode checks (per TODO_02 spec)
| Symptom | Likely cause |
|---------|--------------|
| Skew values > 1 | formula in degrees or missing normalisation |
| `p99 == max` exactly | mesh has < 100 elements (acceptable, document) |
| Tet10 sJ < 0 on nice mesh | wrong Hammer point coords or shape gradients |
| `p05 > p50` | percentile picker bug (sort direction) |

### Pass criterion (from TODO_02)
> Report contains `equiangular skew` AND a `p05/p50/p95/p99` line for every metric.

---

## 4. Risk & Open Questions

1. **Tet10 entry point not exercised by the TODO_02 acceptance check.**
   The cube fixture only generates Tet4. Tet10 metrics need a separate test
   path — defer to TODO_05 / TODO_08 once those promote the mesh.
   Action: ship `computeReportTet10` API but don't gate TODO_02 on a Tet10
   regression yet.

2. **Histogram bins for skew** — TODO_02 spec example shows 4 bins
   `[0,0.25), [0.25,0.5), [0.5,0.8), [0.8,1]`. Note the `0.5` boundary
   instead of `0.50` and the `0.8` instead of `0.80` — confirm bin layout
   matches plot in spec; if ambiguous, prefer `[0,0.25), [0.25,0.50),
   [0.50,0.80), [0.80,1.00]` (mirrors Knupp bin style for consistency).

3. **`Tet10Element::EvalShapeGradients` reuse vs. duplication** — pulling
   `Tet10Element.h` into `MeshQuality.cpp` couples the quality library to
   `Eigen` and `IMaterial`. Decision: **duplicate** the 10-node gradient
   formulas locally (~30 lines). Keep MeshQuality dependency-light so
   `mesh_diag.exe` link stays clean.

4. **Worst-N sort key** — currently sorted by ascending Knupp. After TODO_02
   we have multiple metrics; should worst-N use Knupp (current), skew
   (highest first), or a composite? Decision: **keep Knupp** to preserve
   TODO_01 regression compatibility; expose composite ranking as a future
   knob if requested.

---

## 5. Estimated Effort Breakdown

| Task | Time |
|------|-----|
| Step 1 — header extensions | 0.5 h |
| Step 2 — 5 new metric functions + Tet10 shape gradients | 3 h |
| Step 3 — refactor `computeReport` + percentile helper | 2 h |
| Step 4 — extend `emitReport` (skew histogram + percentile block) | 1 h |
| Step 5 — Tet10 entry point + shared `computeReportImpl` factor | 1.5 h |
| Step 6 — `FEAModel.cpp` wiring | 0.25 h |
| Step 7-8 — multithreading + numerical guards | 0.5 h |
| Step 9 — regression sentinel update | 0.25 h |
| Manual verification + cube smoke test | 0.5 h |
| Documentation (`TODO_02_DONE_documentation.md`) | 0.5 h |
| **Total** | **≈ 10 hours (≈ 1 day)** matches TODO_02 estimate |

---

## 6. Order of Operations (Recommended)

1. Header changes (Step 1) — compiles cleanly with stub init values.
2. `radiusRatio` + `equiangularSkew` + `dihedralRangeDeg` (Step 2.1–2.3) — Tet4-only,
   easy to verify on the cube.
3. Wire into `computeReport` + `emitReport` (Step 3 + 4) — get a working
   PASS for the TODO_02 acceptance check on Tet4.
4. Percentile helper (Step 3.4–3.5) — unit-test on a small known mesh.
5. Build + manual cube smoke test → confirm TODO_02 acceptance.
6. Tet10 paths (Step 2.4, 2.5, 5) — landed but not gated on TODO_02 PASS.
7. Regression sentinel update (Step 9).
8. Write `TODO_02_DONE_documentation.md` (mirroring TODO_01_DONE format).

---

*Plan author: Cascade — 2026-05-17*
