# TODO_03 — Geometric fidelity (Hausdorff + normal deviation)

## Goal
Report how well the tet mesh's boundary matches the input surface. Adds Hausdorff distance and normal-deviation histograms to the quality report, plus the max-drift triangle's coordinates.

## Files added / modified
- **Modify** `include/MeshQuality.h`, `src/MeshQuality.cpp` — add `computeHausdorffToSurface()`, `computeNormalDeviation()`.
- **Modify** `src/FEAModel.cpp` — snapshot the input surface (`surfaceVertices` + `surfaceIndices`) **before** any TetGen call into `refSurfaceForFidelity` so it survives smoothing/optimisation.
- **Add** test fixture `assets/test_fixtures/sphere_r1.stl` (unit sphere, ~1000 triangles).

## Algorithm summary
From [knowledge/02_Mesh_Quality_Metrics.md §6](knowledge/02_Mesh_Quality_Metrics.md):
- **Hausdorff (symmetric):** for each boundary face of the vol mesh, sample 4 quadrature points; find nearest point on the reference surface (BVH on refSurface). Reverse pass for completeness. Report max + 95th percentile.
- **Normal deviation:** per boundary face $f$, compute $\delta_n = \arccos(\langle n_f, n_{\mathcal{S}}(y_f)\rangle)$ where $y_f$ is the footpoint on refSurface. Histogram + p50/p95/p99/max.

The reference surface MUST be the input snapshot, not the current optimised boundary — otherwise the metric degenerates to zero.

## Multithreading
- One-shot serial BVH build over reference surface (`meshoptimizer` exposes a spatial-sort helper already in the dep stack).
- Parallel `#pragma omp parallel for schedule(static)` over boundary faces for both Hausdorff queries and normal deviation; thread-local extrema reduced afterward.

## Numerical care points
- **Symmetric Hausdorff** (care-point #14) — sup over both directions, not just vol→ref. Easy bug.
- Sample 4 quadrature points per boundary face (centroid + three at $\xi=0.5$ along edges) — single-centroid sampling misses post-projection drift.
- For the orientation in normal deviation, the boundary-face normal must point **outward** (use winding/orient3d to verify) — otherwise $\delta_n$ values are near $180°$ everywhere.

## Screen-visible acceptance check

**Setup** Use `assets/test_fixtures/sphere_r1.stl`.

**Action** Click `Generate 3D Mesh` with default `tetQuality=1.2`.

**Expected console addition**
```text
[Fidelity vs input surface]
  Hausdorff (symmetric) : 4.8e-4 m  (target: < 1.0e-3 m, ratio 0.48)
  normal deviation      : p50=2.1 deg   p95=8.4 deg   p99=14.2 deg   max=16.8 deg
  Max-drift triangle    : id=234 at (0.71, 0.71, 0.0) drift=4.8e-4
  Verdict: PASS
```

**Failure modes**
- Hausdorff $\sim 0.5$ m (huge) → snapshot reference surface not captured before optimisation (comparing against post-smoothing mesh)
- Normal deviation $>90°$ → orientation flipped between volMesh boundary face and reference
- Both directions show same value → only one-sided Hausdorff computed (must be symmetric)

**Pass criterion** Hausdorff $< 1\%$ of $L_{\text{diag}}$ AND normal deviation $p_{95} < 15°$ for the unit sphere.

## Regression sentinel
`regression/sphere_hausdorff.txt` — Hausdorff + normal-dev values on unit sphere. Future commits diff.

## Depends on
TODO_02.

## Estimated effort
1.5 days.
