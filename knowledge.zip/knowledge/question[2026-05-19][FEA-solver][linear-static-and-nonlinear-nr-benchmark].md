# Linear Static FEA, Nonlinear FEA (Newton-Raphson), and the Cantilever Beam Benchmark

**Date:** 2026-05-19
**Topic:** What linear static FEA and nonlinear NR FEA are; what benchmark test validates linear static FEA and how to interpret its results

## Related Theory

| Theory file | What it contributes to this Q&A |
|---|---|
| [00 Overview and Taxonomy](theoritical/00_Overview_and_Taxonomy.md) | §3 Element types cheat-sheet — the exact table showing Tet4 is O(h) and Tet10 is O(h²) in the H¹ norm, locking risks, and DOF counts that underpin the convergence-rate analysis in Q3's benchmark result section |
| [01 Mathematical Foundations](theoritical/01_Mathematical_Foundations.md) | §7 Function-approximation theoretic targets — ZZ error recovery formula (§7.1), residual-based estimator (§7.2), and DWR goal-oriented error (§7.3); the $E_\text{disc} = C(\rho,p) h^{p+1}$ interpolation error bound (from §00 cross-ref) that explains why element shape quality multiplies the convergence rate |
| [02 Mesh Quality Metrics](theoritical/02_Mesh_Quality_Metrics.md) | Dihedral angle and radius-edge ratio — how sliver elements (θ_min < 10°) inflate the condition number κ(K), directly degrading both the linear solve accuracy and NR convergence per iteration |
| [11 Adaptive Refinement hp and DWR](theoritical/11_Adaptive_Refinement_hp_and_DWR.md) | Full treatment of ZZ recovery, h- and p-refinement convergence rates, Dörfler marking, and goal-oriented DWR — all of which underlie the "convergence study" methodology described in Q3's benchmark interpretation section |
| [16 PolyFEA Implementation Guide](theoritical/16_PolyFEA_Implementation_Guide.md) | §1.1–1.2 concrete NR/assembly pipeline code references; §4.5 adaptive cycle sketch (ZZ → Dörfler → TetGen remesh → warm-start NR) as the natural extension of the benchmark's convergence analysis |

---

## Q1: What is Linear Static FEA in simple terms?

Linear static FEA is the most common and most restricted case of finite element analysis. It makes three simultaneous assumptions:

| Assumption | What it means | What breaks it |
|---|---|---|
| **Linear** | Stress is proportional to strain (Hooke's Law holds) | Plasticity, rubber, large-strain composites |
| **Static** | No inertia, no damping, no time dependence | Vibration, impact, dynamic loads |
| **Small strain** | Deformations are so small that the geometry is treated as unchanged | Large rotations, buckling, contact |

Under all three assumptions, the problem collapses to a **single linear system** that is solved exactly once:

$$
K u = F
$$

where $K$ is the global stiffness matrix (assembled once, never updated), $u$ is the nodal displacement vector (the unknown), and $F$ is the external load vector.

### How $K$ is built — the assembly chain

```
Material law (E, ν) → Constitutive matrix D (6×6)
     ↓
Element shape functions → Strain-displacement matrix B (6 × 3n)
     ↓
Per-element stiffness:  K_e = V_e · B^T D B          (Tet4, constant B)
                        K_e = Σ w_g |det J_g| B_g^T D B_g   (Tet10, Gauss quadrature)
     ↓
Scatter K_e entries into global K via DOF index map
     ↓
Enforce Dirichlet BCs (penalty: K_ii += α · max(diag K))
     ↓
Solve  K u = F  once  →  done
```

**The key insight:** because $K$ does not depend on $u$, solving the system is a one-shot operation. No iteration is needed. This is what makes linear static FEA fast and predictable.

### Why "linear" is the right word algorithmically

The relationship between load and displacement is linear:

$$
u = K^{-1} F
$$

Double the load $F$ → double the displacement $u$. Triple one load component → triple that component in $u$. This superposition principle means many load cases can be solved with the same factorized $K$ — just swap $F$ and re-do the cheap back-substitution step. This is why linear static is the default analysis mode in ANSYS, ABAQUS, and PolyFEA.

---

## Q2: What is Nonlinear FEA with Newton-Raphson in simple terms?

Nonlinear FEA drops at least one of the three assumptions above. In PolyFEA's implementation, the source of nonlinearity is a **nonlinear material model** or **large deformation** — meaning the internal force $F_\text{int}(u)$ is no longer a linear function of $u$.

### The residual picture

Instead of $K u = F$, the problem is rewritten as a **root-finding problem**:

$$
R(u) = F_\text{ext} - F_\text{int}(u) = 0
$$

$R(u)$ is called the **residual** — the out-of-balance force. At the true solution, the external loads are exactly cancelled by the internal stresses: $R = 0$. Starting from a guess $u_0$, Newton-Raphson (NR) iteratively drives $R$ toward zero.

### The NR iteration — step by step

At each iteration $k$:

1. **Compute internal forces.** For each element, gather the element displacement $u_e$, compute $f_e = K_e u_e$ (or the nonlinear equivalent), scatter into global $F_\text{int}$.

2. **Form the residual.** $R_k = F_\text{ext} - F_\text{int}(u_k)$. Zero the residual at fixed DOFs (Dirichlet).

3. **Check convergence.** If $\|R_k\|_2 < \tau_\text{tol}$, stop. (The first iteration is never declared converged — this ensures the initial residual is always printed for diagnostic purposes.)

4. **Assemble the tangent stiffness.** $K_T(u_k)$ — the "local linear approximation" of the nonlinear problem at the current deformed state. For a linear material, $K_T = K$ always; for a hyperelastic material, $K_T$ changes each iteration.

5. **Solve for the displacement increment.**
$$K_T(u_k)\, \Delta u_k = R_k$$

6. **Update the state.** $u_{k+1} = u_k + \Delta u_k$. Return to step 1.

Visualised as a graph — NR repeatedly draws a tangent line to the nonlinear curve $F_\text{int}(u)$, finds where that line hits $F_\text{ext}$, and jumps there:

```
F_int
  │         ╭── true curve
  │        /
F_ext ─ ─ /─ ─ ─ ─ ─ ─ ─ (target)
  │      /  ↗ tangent at u_k
  │     / ↗
  │    /↗
  │───────────────────────── u
       u_0  u_1  u_2  u*
```

Each iteration brings $u_k$ closer to the true root $u^*$. NR convergence is **quadratic** near the solution — once the iterate is close enough, the error roughly squares each iteration (e.g., error goes 1 → 0.1 → 0.01 → 0.0001).

### Incremental load-stepping (the outer loop)

For large nonlinearities, applying the full load in one shot can cause NR to diverge. PolyFEA wraps NR in an incremental load-stepping outer loop: the total load $F_\text{ext}$ is applied in $N$ equal fractions $\lambda_s = s/N$:

```
For s = 1 to N:
    F_ext_s = (s/N) · F_ext          ← partial load
    u_0 = u (solution from step s-1)  ← warm start
    Run NR iterations until ‖R‖ < τ  ← converge this step
    u = u_k (converged solution)
```

Each step solves a *smaller* nonlinear problem, which NR can converge on more reliably. The path of solutions $\{u_1, u_2, \ldots, u_N\}$ traces the load-displacement curve of the structure.

### Validation property: linear material reduces to one NR step

For a **linear-elastic** material with $N = 1$ load step:
- At $k=0$: $F_\text{int}(0) = 0$, so $R = F_\text{ext}$; NR solves $K \Delta u = F_\text{ext}$, giving $u_1 = K^{-1} F_\text{ext}$.
- At $k=1$: $F_\text{int}(u_1) = K u_1 = F_\text{ext}$, so $R = 0$. Convergence declared.

This means the nonlinear solver is a **strict superset** of the linear solver. One NR iteration on a linear problem is identical to solving $Ku = F$ directly. This is the most important self-consistency check in the codebase.

---

## Q3: What is the benchmark test used to validate linear static FEA?

PolyFEA uses the **Euler-Bernoulli cantilever beam** as its primary analytical validation benchmark for linear static FEA. (See `theory.md` §10.)

### What it is

The **Euler-Bernoulli beam theory** is a classical analytical solution for the bending of slender beams. Published by Leonhard Euler and Daniel Bernoulli in the 18th century, it gives an exact closed-form formula for the tip deflection of a cantilever beam under a transverse load. It is perhaps the most widely used validation case in structural FEA — appearing in the test suites of ANSYS, ABAQUS, Nastran, and effectively every commercial FEA package.

**Setup:**

```
    Fixed end                     Free end
       │                              │
       ├──────────────────────────────┤  ← beam (length L, width b, height h)
       │                              │
       [///]        →                 ↓ F  (transverse load)
```

- One end (at $X_\text{min}$) is fully fixed (all displacements and rotations = 0)
- A single transverse load $F$ is applied at the free end (at $X_\text{max}$)
- The beam undergoes pure bending

### How it works — the analytical formula

The **maximum tip deflection** (at the free end) is:

$$
\delta_\text{max} = \frac{F L^3}{3 E I}
$$

where:
- $F$ — applied transverse force (N)
- $L$ — beam length (m)
- $E$ — Young's modulus (Pa)
- $I$ — second moment of area of the cross-section about the bending axis (m⁴)

For a solid rectangular cross-section of width $b$ and height $h$ bending about the horizontal neutral axis:

$$
I = \frac{b h^3}{12}
$$

**Where this formula comes from (intuition, not a full derivation):**

The $L^3$ in the numerator captures how bending accumulates along the beam: a load at the tip causes a rotation everywhere, and that rotation integrates to a tip displacement — hence three powers of $L$. The $3EI$ in the denominator encapsulates resistance: $E$ is material stiffness, $I$ is how the cross-sectional area is distributed away from the neutral axis (a deep beam bends less than a shallow one). The factor 3 comes from the double integration of the moment diagram along the beam length.

**PolyFEA's implementation** (`theory.md` §10):

1. The solver automatically extracts $L$, $b$, $h$ from the AABB of the generated mesh.
2. Computes $I = bh^3/12$.
3. Runs the FEA solve (with `CantileverBendingZ` load type: fix $X_\text{min}$ nodes, apply $-Z$ force at the centroid of the $X_\text{max}$ face).
4. Reads the maximum nodal displacement $\|U\|_\infty$ from the FEA result.
5. Computes and prints:

$$
\text{error} = \frac{|\delta_\text{FEA} - \delta_\text{analytical}|}{\delta_\text{analytical}} \times 100\%
$$

### Credibility — why this benchmark is trusted

The Euler-Bernoulli formula is **analytically exact** under its assumptions:

| Assumption | Validity range | Effect if violated |
|---|---|---|
| **Plane sections remain plane** | Slender beams (L/h > 10) | Shear deformation adds extra deflection (use Timoshenko beam instead) |
| **Small strains** | $\delta_\text{max} / L \ll 1$ | Geometric nonlinearity, need NR solver |
| **Linear elastic material** | Below yield stress | Plasticity, need nonlinear material model |
| **No transverse shear deformation** | Implied by Euler-Bernoulli | Short beams or composites require Timoshenko or Mindlin corrections |

For a slender steel bar (L/h = 20, deflection/L = 1%), all four assumptions hold to within ~0.1%. The formula produces a result that agrees with physical experiments to within measurement error. The formula itself is not approximate — it is the **exact solution to the Euler-Bernoulli differential equation** $EI \, d^4w/dx^4 = q$, integrated twice with boundary conditions at both ends.

This gives the benchmark a credibility that most FEA test cases lack: there is no "reference simulation" that could itself be wrong. The analytical solution is a ground truth derived from first principles.

### Analysis of its results

**What the error percentage actually tells you:**

The error $|\delta_\text{FEA} - \delta_\text{analytical}| / \delta_\text{analytical}$ conflates two distinct sources of inaccuracy that are worth separating:

#### Source 1: Discretisation error (mesh is too coarse)

FEA approximates the continuous displacement field using piecewise polynomials on a finite mesh. The mesh cannot exactly represent the cubic deflection profile $w(x) = (Fx^2/6EI)(3L - x)$. Error comes from approximating this continuous curve with a finite number of elements.

| Element type | Convergence rate | Implication |
|---|---|---|
| Tet4 (linear, constant strain) | $O(h^2)$ in energy norm | Halving mesh size cuts error by ~4× |
| Tet10 (quadratic, linear strain) | $O(h^3)$ in energy norm | Halving mesh size cuts error by ~8× |

For a cantilever under a point load, the bending strain varies linearly along the beam. Tet10 can represent this exactly (its shape functions include linear strain) so Tet10 converges much faster than Tet4. In practice: a coarse Tet4 mesh might show 15–30% error; the same mesh with Tet10 might show 2–5%.

#### Source 2: Modelling error (assumptions violated)

Even with an infinitely fine mesh, the FEA result will not match $\delta = FL^3/3EI$ if the model geometry violates the beam assumptions. Examples:

- **Short, stubby geometry (L/h < 10):** the real deflection includes a shear contribution that Euler-Bernoulli ignores. Timoshenko's correction adds $\delta_\text{shear} = FL/(GA_s)$ where $G$ is the shear modulus and $A_s$ is the shear area. For L/h = 5, this can be 10–20% of the bending deflection, and the FEA will be "more right" than the formula.
- **Clamped boundary modelled incorrectly:** if fixed DOFs are applied to nodes in a thick slab at $X_\text{min}$ rather than to a thin cross-section, the beam is effectively shorter than $L$, and the FEA result will underpredict the formula.
- **Load applied to a patch rather than a point:** area-averaged loads spread the traction across a finite region; the formula assumes a point load.

#### Interpreting specific error ranges

| Observed error | Most likely cause | Diagnostic action |
|---|---|---|
| > 30% | Mesh far too coarse OR element order too low | Refine mesh, switch to Tet10 |
| 10–30% | Tet4 on a moderately curved/stubby geometry | Switch to Tet10, or refine 2–3× |
| 2–10% | Tet10 on a coarse mesh, or mild assumption violation | Refine once and check convergence direction |
| 0.5–2% | Expected Tet10 result at moderate resolution | Acceptable for engineering |
| < 0.5% | Excellent agreement | Either very fine mesh or geometry is perfectly beam-like |
| Exactly 0% (suspiciously) | Bug in benchmark extraction logic, not real convergence | Verify $L$, $b$, $h$ extraction from AABB |

#### Convergence as the definitive test

A single error number is less informative than a **convergence study** — run the benchmark at several mesh densities and plot error vs. element count:

```
Error (%)
  30│  ×                        ← Tet4 coarse
    │     ×
  10│        ×
    │           ×               ← Tet4 fine
   3│              ×
    │           ◆               ← Tet10 coarse (already better than fine Tet4)
   1│              ◆
    │                 ◆         ← Tet10 fine
  0.3│                    ◆
    └──────────────────────────  Element count (log scale)
       100   1k   10k  100k
```

If error decreases as mesh refines at the expected rate (×4 reduction per mesh doubling for Tet4, ×8 for Tet10), the solver is working correctly. If error stalls or increases, the problem is a modelling/boundary-condition error, not a mesh resolution issue.

#### Why NR converges in one iteration for this benchmark

As derived in the validation property in §6 of theory.md, the nonlinear NR solver reduces to exactly one iteration for a linear material. The console output of PolyFEA shows this explicitly:

```
[NR] Step 1/1 | iter 0 | ‖R‖ = 1.000e+03   ← initial residual = ‖F_ext‖
[NR] Step 1/1 | iter 1 | ‖R‖ = 2.3e-09     ← machine zero after one solve
[NR] Converged in 1 iteration.
```

If the solver reports more than one NR iteration for this benchmark with a linear material, it indicates a bug in either the tangent stiffness assembly or the internal force computation.

---

## Summary

| | Linear Static FEA | Nonlinear FEA (NR) |
|---|---|---|
| **Core equation** | $Ku = F$ | $R(u) = F_\text{ext} - F_\text{int}(u) = 0$ |
| **Iteration** | None — one solve | Multiple NR iterations per load step |
| **$K$ updated?** | No — assembled once | Yes — $K_T$ reassembled each NR iteration |
| **Superposition** | Yes | No |
| **Use case** | Small deformation, linear material | Large deformation, plasticity, hyperelasticity |
| **Cost** | One factorization + one back-substitution | $N_\text{steps} \times N_\text{NR}$ linear solves |
| **Reduces to other?** | — | Reduces to linear in one iteration for linear material |

**Benchmark:** The Euler-Bernoulli cantilever beam provides an analytically exact reference with no modelling uncertainty (given a slender, linearly elastic beam). The primary use of its error percentage is not to pass/fail at a threshold, but to confirm convergence behaviour as mesh density increases — falling error at the expected rate is the real sign that the FEA implementation is correct.

---

## Implementation — Code Location and Data Flow

### Classes and methods involved

| Class / method | File | Role |
|---|---|---|
| `FEASolver` | [include/FEASolver.h:21](../include/FEASolver.h) | Top-level solver class; holds all solver config as public fields |
| `NRParams` | [include/FEASolver.h:9](../include/FEASolver.h) | Pod struct: `numLoadSteps`, `maxIterations`, `tolerance` for the NR loop |
| `FEASolver::solveLinearStatic(model, visualScale, U_out)` | [include/FEASolver.h:134](../include/FEASolver.h) | One-shot `Ku = F`: assemble → apply BCs → solve → write displacements → print benchmark |
| `FEASolver::solveNonlinearStatic(model, visualScale, params)` | [include/FEASolver.h:149](../include/FEASolver.h) | Incremental NR: outer load-step loop wrapping inner residual-convergence loop |
| `FEASolver::LoadType::CantileverBendingZ` | [include/FEASolver.h:73](../include/FEASolver.h) | Enum value that triggers cantilever BC setup + Euler-Bernoulli benchmark print |
| `FEAModel::generateMidEdgeNodes()` | [src/FEAModel.cpp:748](../src/FEAModel.cpp) | Called inside both solve methods when `solver.useQuadraticElements == true` |
| `FEAModel::tetrahedra` / `tetrahedraQuadratic` | [include/FEAModel.h:61–62](../include/FEAModel.h) | Tet4 (4/tet) or Tet10 (10/tet) connectivity read by the solver to build elements |
| `FEAModel::nodalDisplacementMagnitudes` | [include/FEAModel.h:49](../include/FEAModel.h) | `std::vector<float>` written by solver; read by `buildBuffers` for displacement colormap |
| `FEAModel::deformedPositions` | [include/FEAModel.h:77](../include/FEAModel.h) | `std::vector<glm::vec3>` written by solver; drives visible deformation on screen |

### Stupid-clerk data flow — Linear Static FEA

**Step 1 — UI trigger** [src/main.cpp:523]

User clicks "LINEAR STATIC FEA". The code creates `FEASolver solver` and sets its fields from the UI state:
- `solver.loadType = FEASolver::LoadType::CantileverBendingZ` (or whichever is selected)
- `solver.youngsModulus = currentMaterial.E`
- `solver.poissonRatio = currentMaterial.nu`
- `solver.useQuadraticElements`, `solver.useMultithreading`, `solver.useGPU` from checkboxes

Then calls `solver.solveLinearStatic(model, visualScale)` where `model` is the global `FEAModel`.

---

**Step 2 — Inside `FEASolver::solveLinearStatic`**

The solver reads `model.tetrahedra` (if `useQuadraticElements == false`) or calls `model.generateMidEdgeNodes()` first and reads `model.tetrahedraQuadratic`. One element object is created per tetrahedron.

**Assembly — build global `K`:**
- For each element, compute `K_e` (12×12 for Tet4, 30×30 for Tet10) using `IElement::ComputeStiffnessMatrix()`
- Emit `(global_row_i, global_col_j, K_e_ij)` triplets into a pre-reserved flat array
- `Eigen::SparseMatrix<double> K` assembled by `K.setFromTriplets(...)` — duplicate entries are summed automatically
- `K` size: `nDOF × nDOF` where `nDOF = 3 × nNodes`

**Apply Dirichlet BCs (penalty method):**
- Fixed nodes identified by `loadType` (for `CantileverBendingZ`: all nodes with `position.x ≈ X_min`)
- `K(dof, dof) += alpha` where `alpha = 1e7 × max(diag(K))`

**Assemble `F`:**
- `Eigen::VectorXd F(nDOF)` initialized to zero
- For `CantileverBendingZ`: finds the single node nearest to the centroid of the `X_max` face; sets `F[node*3 + 2] = -appliedForce` (Z direction)
- For surface load types: tributary-area accumulation across the loaded boundary patch

**Solve `K u = F`:**
The solver tries three backends in order:
1. `cuSOLVER` sparse Cholesky (GPU) — if `solver.useGPU == true` and CUDA is available
2. `Eigen::ConjugateGradient` with Jacobi preconditioner — if `solver.useMultithreading == true`
3. `Eigen::SimplicialLDLT` (CPU direct) — always available as fallback

Result is `Eigen::VectorXd u` of size `nDOF`.

**Write results to `FEAModel`:**
- `model.deformedPositions[i] = model.originalVolumetricPositions[i] + glm::vec3(u[i*3], u[i*3+1], u[i*3+2]) * visualScale`
- `model.nodalDisplacementMagnitudes[i] = glm::length(glm::vec3(u[i*3], u[i*3+1], u[i*3+2]))`
- `model.hasDeformation = true`
- `model.buildBuffers()` — GPU buffers refreshed; displacement colormap activates

**Benchmark print (if `loadType == CantileverBendingZ`):**
- Extracts `L`, `b`, `h` from `model.currentMinBounds` / `model.currentMaxBounds`
- Computes `I = b * h³ / 12`
- `delta_analytical = F * L³ / (3 * E * I)`
- `delta_FEA = max(model.nodalDisplacementMagnitudes)`
- Prints `error = |delta_FEA - delta_analytical| / delta_analytical × 100%` to `std::cout`

---

### Stupid-clerk data flow — Nonlinear FEA (Newton-Raphson)

**Step 1 — UI trigger** [src/main.cpp:537]

User clicks "NONLINEAR FEA (NR)". The code creates `FEASolver solver` (same field setup as above) and `NRParams nrp`:
- `nrp.numLoadSteps = 1` (default — one load step = behaves like linear for linear material)
- `nrp.maxIterations = 25`
- `nrp.tolerance = 1e-6`

Calls `solver.solveNonlinearStatic(model, 10.0f, nrp)`.

---

**Step 2 — Inside `FEASolver::solveNonlinearStatic`**

Same element setup and assembly infrastructure as linear. Then the double loop runs:

**Outer loop — load steps** (`s = 1 … nrp.numLoadSteps`):
- `lambda_s = s / nrp.numLoadSteps`
- `F_ext_s = lambda_s * F_ext_total` — partial load fraction as `Eigen::VectorXd`
- `u` carries over from previous step as warm start (starts at zero for step 1)

**Inner loop — NR iterations** (`k = 0, 1, 2, …`):

1. **Internal force**: for each element, gather `u_e` (12 or 30 doubles from `u`), call `IElement::ComputeInternalForce(u_e)` → `f_e` (12 or 30 doubles), scatter into `Eigen::VectorXd F_int` via `#pragma omp atomic`

2. **Residual**: `R = F_ext_s − F_int`; zero `R` at all fixed DOFs

3. **Convergence check**: if `R.norm() < nrp.tolerance && k >= 1` → break inner loop and advance to next load step

4. **Tangent stiffness**: assemble `K_T` from `IElement::ComputeTangentStiffness(u_e)` — for linear material this is identical to `K` in the linear path

5. **Linear solve**: `K_T * delta_u = R` → `Eigen::VectorXd delta_u` (same solver cascade: GPU → PCG → LDL^T)

6. **State update**: `u += delta_u`; print `[NR] Step s | iter k | ‖R‖ = ...` to `std::cout`

**After all load steps converge:**
- Same write-to-`FEAModel` as linear path: `deformedPositions`, `nodalDisplacementMagnitudes`, `hasDeformation = true`, `buildBuffers()`

**Validation property visible in console output:**
For a linear material with `nrp.numLoadSteps = 1`:
- `k=0`: `F_int = 0` → `R = F_ext` → `‖R‖ = ‖F_ext‖` (large number)
- `k=1`: `F_int = K·u = F_ext` → `R ≈ 0` → converged in **1 iteration**

If the console shows more than 1 NR iteration for a linear material, there is a bug in `ComputeInternalForce` or `ComputeTangentStiffness`.

---

*Author: Claude Sonnet 4.6 — 2026-05-19*
