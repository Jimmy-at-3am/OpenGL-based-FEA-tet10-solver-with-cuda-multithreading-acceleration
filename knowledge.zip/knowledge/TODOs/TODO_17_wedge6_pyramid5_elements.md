# TODO_17 — Wedge6 + Pyramid5 element classes

## Goal
Add `Wedge6Element` (6-node triangular prism, trilinear, 6-point Gauss) and `Pyramid5Element` (5-node pyramid, Bedrosian 1992 quadrature) as new `IElement` subclasses. Required for TODO_18 (boundary layer extrusion) but tested standalone first.

## Files added / modified
- **Add** `include/Wedge6Element.h`, `src/Wedge6Element.cpp`.
- **Add** `include/Pyramid5Element.h`, `src/Pyramid5Element.cpp`.
- **Modify** `include/FEAModel.h` — add `std::vector<unsigned int> wedges` (6 per element), `pyramids` (5 per element); element-type flag per element.
- **Modify** `src/FEASolver.cpp` — element-factory loop must instantiate the right type based on flag.
- **Modify** `src/main.cpp` UI — file load detects mixed-element meshes (e.g. from `.vtu`).
- **Add** `assets/test_fixtures/wedge_pyramid_block.vtu` — hand-crafted mixed mesh: 4 wedges + 2 pyramids + 8 tets, all sharing a common interior face. Built once via a one-off Python/Numpy script.

## Algorithm summary
From plan Appendix Phase I.4 and [knowledge/00_Overview_and_Taxonomy.md §3](knowledge/00_Overview_and_Taxonomy.md):

**Wedge6** — reference shape is triangular prism on $[0,1]^2 \times [-1,1]$:
- Nodes 0-2 bottom triangle, 3-5 top triangle.
- Shape functions: $N_i = L_i(\xi,\eta) \cdot \tfrac{1}{2}(1 - \zeta)$ for $i\in 0..2$; $N_i = L_{i-3} \cdot \tfrac{1}{2}(1 + \zeta)$ for $i\in 3..5$. ($L_0 = 1-\xi-\eta$, $L_1 = \xi$, $L_2 = \eta$ — barycentric.)
- 6-point Gauss: 3 Gauss points on the triangle (Dunavant degree 2) × 2 along $\zeta$ ($\pm 1/\sqrt{3}$).

**Pyramid5** — reference shape is square pyramid on $[-1,1]^2 \times [0,1]$:
- Node 0-3 = base square; node 4 = apex.
- Shape functions (Wedge–Hand 2002, the most numerically clean form):
  $$N_i = \tfrac{1}{4}(1 + \xi_i\xi/(1-\zeta))(1 + \eta_i\eta/(1-\zeta))(1-\zeta), \quad N_4 = \zeta$$
- **Bedrosian 1992 5-point quadrature** — designed to handle the singular Jacobian at the apex without producing bogus stiffness.

Both elements: $K_e = \sum_g w_g |\det J_g| B_g^T D B_g$, identical machinery to Tet4 / Tet10.

## Multithreading
Already inherited from `FEASolver` element loops — both new elements plug into the existing `#pragma omp parallel for` over elements at FEASolver.cpp:526. No new threading code.

## Numerical care points
- **Pyramid quadrature** (care-point #13) — **MUST use Bedrosian 1992**, NOT Gauss-Legendre. The latter gives bogus stiffness near the apex due to the singular Jacobian.
- Wedge shape-function indexing: easy to swap top/bottom by mistake; verify via a single-element compression test (uniaxial tension along $\zeta$ should give the analytical $u = FL/(AE)$).
- Pyramid Jacobian: singular at the apex; the Bedrosian rule's points avoid the singularity. Do NOT evaluate $J$ at the apex.

## Screen-visible acceptance check

**Setup** Place `assets/test_fixtures/wedge_pyramid_block.vtu` (hand-crafted mixed mesh: 4 wedges + 2 pyramids + 8 tets, all sharing a common interior face).

**Action** Load file; click `Solve Linear Static` with simple tension BC.

**Expected**
- Viewer: wedges drawn with blue tint, pyramids with green, tets default.
- Console: `[Elements] Tet: 8   Wedge6: 4   Pyramid5: 2   total DOFs: 60`.
- Solve completes; displacement field rendered; no warnings about inverted elements.
- Total reaction force at fixed boundary matches applied load to $10^{-6}$ relative.

**Failure modes**
- Inversion error at pyramid apex → using Gauss-Legendre instead of Bedrosian quadrature.
- Wedge stiffness wrong (analytic test fails) → shape-function indexing transposed.
- Mixed-element assembly skips wedges → `IElement` factory not registered.

**Pass criterion** Visual rendering shows tinted element types AND solve converges AND reactions match applied load.

## Regression sentinel
`regression/mixed_elements_block.txt` — DOFs + final displacement at a fixed node.

## Depends on
None — independent (can run in parallel by a second developer with TODO_06..15).

## Estimated effort
2.5 days.
