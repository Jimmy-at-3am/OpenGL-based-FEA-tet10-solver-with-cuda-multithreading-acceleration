---
title: Anisotropic Metric-Based Mesh Adaptation
type: algorithm
tags: [anisotropic, metric, riemannian, mmg, feflo, loseille, adaptation]
created: 2026-05-16
---

# 08 — Anisotropic Metric-Based Mesh Adaptation

The single most important advance in numerical meshing of the last 25 years. The idea: rather than refining isotropically, equip the domain $\Omega$ with a **Riemannian metric tensor field** $M(x)$ that encodes both the **size** and **direction** of desired elements at each point, then generate (or remesh) so that every element is a **unit simplex** in $M$.

This unifies *h*-adaptation (size) and *r*-adaptation (orientation) into one framework and gives the **provably optimal** mesh for a given target node count in the $L^p$ interpolation-error sense (Loseille–Alauzet 2010 — the continuous mesh framework).

The canonical implementations:

- **MMG3D** (Dapogny–Dobrzynski–Frey, INRIA — open source, mature 2014+).
- **feflo.a** (Loseille, INRIA — proprietary, used by Inria SU2 and NASA's FUN3D adaptive workflow).
- **Pragmatic** (Imperial College, MPI-parallel for HPC).
- **MMG2/3 + BAMG** front-end for FreeFEM / Gmsh.
- Commercial: **ANSYS Fluent adaptive** (2024R2 metric refinement option), **COMSOL adaptive mesh** (anisotropic mode since 6.0), **MATLAB `adaptmesh`** (isotropic by default; anisotropic since R2023b).

Foundations: [[01_Mathematical_Foundations]] §4 (metric tensors), §7 (error estimators). For the optimisation / smoothing complement see [[12_Mesh_Smoothing_CVT_and_ODT]]; for goal-oriented driving see [[11_Adaptive_Refinement_hp_and_DWR]].

---

## 1. The Continuous Mesh Framework (Loseille–Alauzet 2010)

Treat a mesh as a *continuous* metric field rather than a discrete object. The number of nodes is the **metric complexity**

$$
\mathcal{N}(M) = \int_\Omega \sqrt{\det M(x)}\,dx,
$$

and an "ideal" mesh has exactly $\mathcal{N}(M)$ vertices, each element being unit-volume and equilateral under $M$.

The interpolation error of $u$ in this continuous mesh:

$$
\|u-I_M u\|_{L^p(\Omega)} = \left(\int_\Omega \mathrm{tr}\bigl(M^{-1/2}\,|H_u|\,M^{-1/2}\bigr)^{p\,d/2}\,dx\right)^{1/p} + \mathcal{O}(h^3).
$$

Minimising this with the constraint $\mathcal{N}(M)=N$ yields the **optimal metric**:

$$
M_{\text{opt}}^{L^p}(x) = D_N(p)\, \bigl(\det|H_u(x)|\bigr)^{-1/(2p+d)} \cdot |H_u(x)|,
$$

with $D_N(p)$ a normalisation. For $p=1$ (standard "minimise $L^1$ error") this simplifies to

$$
M_{\text{opt}}^{L^1}(x) \propto \bigl(\det|H_u|\bigr)^{-1/(2+d)} \cdot |H_u|.
$$

So the recipe is: **recover the Hessian, take its absolute value (pointwise eigendecomposition with $|\lambda_i|$), apply the determinant normalisation, build the mesh from this metric**.

---

## 2. Metric Construction in Practice

### 2.1 Hessian recovery from a $P_1$ solution

The discrete solution $u_h$ is only $C^0$, so $H_u$ does not exist in the classical sense. Two recovery operators are standard:

**ZZ-type double-projection (Zhang–Naga 2005):** patch-wise polynomial fit of $u_h$ to a quadratic, then differentiate twice.

**$L^2$-projection on a $P_1$ space:**
$$
\int_\Omega H_h\,\varphi\,dx = -\int_\Omega \nabla u_h \otimes \nabla\varphi\,dx \;+ \text{boundary terms},
$$
solved for $H_h\in P_1^{3\times3}$. Cheaper and more robust on anisotropic input meshes.

### 2.2 Absolute value of a symmetric matrix

If $H = R\Lambda R^T$ (spectral decomposition), then

$$
|H| := R\,|\Lambda|\,R^T = R\,\mathrm{diag}(|\lambda_1|,\dots,|\lambda_d|)\,R^T.
$$

Cost: a $3\times3$ symmetric eigendecomposition per point — closed form available (Smith's algorithm).

### 2.3 Min/max size and aspect-ratio clamps

User-supplied bounds:

$$
h_{\min} \le h_i := \lambda_i^{-1/2} \le h_{\max}, \qquad
\max_i h_i \,/\, \min_i h_i \le \alpha_{\max}\text{ (aspect ratio cap)}.
$$

Clip eigenvalues before reassembling $M$.

### 2.4 Gradation control (metric intersection)

Adjacent mesh nodes should have comparable metrics, else element quality degrades at the transition. Enforce

$$
M(y) \preceq \mathrm{Sym}\!\bigl((1+\beta\,\|x-y\|_M)^2\,M(x)\bigr)
$$

where $\beta\in[0.1, 0.4]$ is the **gradation parameter** ($h$ may grow by factor $1+\beta$ per unit metric length). Implemented as a pairwise **metric intersection** sweep (Frey-Alauzet 2005):

```text
repeat until no change:
   for each edge (x, y):
       compute the simultaneously-reduced form of M(x) and M(y)
       reduce both to intersection of clamped versions
```

### 2.5 Log-Euclidean averaging

To interpolate $M$ between mesh nodes (or to combine multiple Hessians, e.g. one per solution component), use the log-Euclidean mean (Arsigny 2006):

$$
\overline{M} = \exp\!\left(\sum_i w_i \log M_i\right),
$$

with the matrix log/exp via spectral decomposition. The result is always SPD (unlike the arithmetic mean of inverses). Used inside MMG3D, feflo.a, and ANSYS Fluent adaptive.

---

## 3. Anisotropic Volume Mesh Generation

Two strategies in current use:

### 3.1 Anisotropic Delaunay refinement (Borouchaki 1997; MMG)

Compute distances and circumballs in the $M$-metric. The **anisotropic empty-ball property**:

$$
\text{ball}_M(\sigma) = \{x : \|x-c_M\|_{M(x)} < r_M\},
$$

with $c_M$ the Steiner-Cayley centre and $r_M$ the $M$-radius. A Delaunay refinement (Ruppert-style) is run with the $M$-metric as the metric of all geometric tests; refinement target is $\ell_M(e) \in [\tfrac{1}{\sqrt2}, \sqrt2]$ for all edges.

### 3.2 Local re-meshing operators (Dapogny 2014, MMG3D)

For an existing mesh that needs to be brought into agreement with a *new* metric, do **local mesh modifications** rather than full remeshing:

```text
4-step iterative loop (MMG3D):
1. Edge splits     where ell_M(e) > 4/3
2. Edge collapses  where ell_M(e) < 4/5
3. Edge swaps      to improve q_M (2-3, 3-2, 4-4 in 3-D)
4. Vertex relocations (Laplacian smoothing in M-metric)
repeat until quality and length thresholds met (typ. 5-20 cycles)
```

Each operator is $\mathcal{O}(1)$; the entire pass is $\mathcal{O}(N \log N)$ with $N$ the element count. This is the algorithm of choice for **adaptive cycles** where the mesh is repeatedly tightened toward an evolving metric (e.g. transient CFD or shape optimisation).

### 3.3 Cavity-based remeshing (feflo.a, Loseille 2017)

A more aggressive variant: remove a metric-bad cavity entirely and rebuild via anisotropic Delaunay refinement inside it. Faster convergence to the metric than local operators alone; the algorithmic foundation of feflo.a's reputation as "the fastest anisotropic mesher in production."

---

## 4. Convergence and Quality of Anisotropic Meshes

The metric-aware shape measure (see [[02_Mesh_Quality_Metrics]] §4):

$$
q_M(T) = \alpha_d \cdot \frac{|T|_M^{2/d}}{\sum_{e\subset T} \ell_M(e)^2/|E_T|}.
$$

A "good" anisotropic mesh has $q_M\ge0.7$ for $\ge90\%$ of elements and edge lengths $\ell_M\in[0.7, 1.4]$. MMG3D typically achieves this within 5–10 cycles starting from any reasonable isotropic mesh.

### 4.1 Implication for FEA error

Loseille–Alauzet (2010 — Part II, Theorem 4.1) show that the $L^p$ interpolation error on a unit anisotropic mesh is **a factor $\sim d^{d/2}$ smaller** than on an isotropic mesh of equivalent node count for solutions with anisotropic features (boundary layers, shock fronts, crack tips). In 3-D this is $\sim5.2\times$ — turning a 24-hour simulation into a 5-hour one.

### 4.2 Practical pitfalls

- **Spurious anisotropy** from noisy $H_u$: smooth $H_u$ before assembly, or use a recovery method less sensitive to mesh quality (Zhang–Naga 2005).
- **Anisotropy aligned with mesh artefacts** when the prior mesh was poor — restart from an isotropic mesh if convergence stalls.
- **Memory blow-up** in metric storage (6 doubles/node in 3-D): use single-precision metrics if RAM-bound.

---

## 5. Adaptive Cycle (the Full Picture)

```text
input: PDE, target N_target, tolerance tau, metric strategy (L^p), max cycles K
1. Generate initial isotropic mesh (e.g., TetGen)
2. for k = 1..K:
       solve PDE on current mesh -> u_h^(k)
       reconstruct Hessian H_u^(k)
       build optimal metric M^(k) per equation in §1
       enforce h_min, h_max, aspect cap, gradation (§2)
       remesh by MMG3D / feflo.a local operators (§3)
       check error indicator decrease; if < tau, exit
3. output final adapted mesh and solution
```

The **AMR fixed-point property:** typically the metric stabilises after 5–8 cycles; further cycles change <1% of vertices and don't improve error.

---

## 6. Anisotropic Meshing in Commercial Tools

| Tool | Anisotropic? | Mechanism |
|---|---|---|
| **ANSYS Fluent (2024R2)** | YES | Metric-based refinement option; sources both gradient and Hessian; uses internal Voronoi engine |
| **ANSYS Mechanical** | partial | "Adaptive convergence" still mostly isotropic (h-adapt by ZZ) |
| **COMSOL 6.x** | YES | "Adaptive mesh refinement" with `anisotropicMode = 'on'` since 6.0; uses internal MMG-style operators |
| **MATLAB R2024b PDE Toolbox** | YES | `adaptmesh(..., 'MeshGrowthRate', ..., 'AnisotropicAdapt', true)` (added R2023b); built on `mmg` library binding |
| **STAR-CCM+** | YES | Anisotropic adaptive mesh refinement for compressible flows |
| **OpenFOAM `dynamicMeshDict`** | partial | Hex-only, isotropic by default; aniso via external `mmgfoam` |
| **NUMECA OMNIS** | YES | Metric-based mesh adaptation for turbomachinery |

---

## 7. When to Use Anisotropic Adaptation

| Scenario | Verdict |
|---|---|
| Boundary-layer / shock / crack-tip solutions | strongly YES |
| Quasi-uniform smooth solutions | NO — adds cost without gain |
| Adaptive shape optimisation | YES — metric stabilises across topology changes |
| Steady-state turbulent CFD | YES — Hessian of $y^+$ or Mach drives BL refinement |
| Transient with moving features | YES — re-build $M$ each time step / few |
| Structural FEA, near stress concentrations | YES — Hessian of von-Mises drives refinement |
| Eigenvalue / modal problems | YES — Hessian per mode, intersect via §2.5 |

---

## 8. References

- F. Alauzet, A. Loseille, "Continuous mesh framework Part II: validations and applications," *SIAM J. Numer. Anal.* 49, 2011.
- F. Loseille, F. Alauzet, "Continuous mesh framework Part I: well-posed continuous interpolation error," *SIAM J. Numer. Anal.* 49, 2011.
- C. Dapogny, C. Dobrzynski, P. Frey, "Three-dimensional adaptive domain remeshing, implicit domain meshing, and applications to free and moving boundary problems," *J. Comput. Phys.* 262, 2014. (MMG3D)
- H. Borouchaki, P. L. George, F. Hecht, P. Laug, E. Saltel, "Delaunay mesh generation governed by metric specifications. Part I: algorithms," *Finite Elements in Analysis and Design* 25, 1997.
- P. J. Frey, F. Alauzet, "Anisotropic mesh adaptation for CFD computations," *CMAME* 194, 2005.
- V. Arsigny, P. Fillard, X. Pennec, N. Ayache, "Log-Euclidean metrics for fast and simple calculus on diffusion tensors," *Magnetic Resonance in Medicine* 56, 2006.
- A. Loseille, "Métric-orthogonal anisotropic mesh generation," *Procedia Engineering* 82, 2014. (feflo.a)
- ANSYS Fluent 2024 R2 *User's Guide* §"Adaptive Mesh Refinement, Metric-Based".
- COMSOL 6.3 *Reference Manual* §"Adaptive Mesh Refinement (Anisotropic)".
- MATLAB R2024b *PDE Toolbox User's Guide* §"adaptmesh".
- O. C. Zienkiewicz, J. Z. Zhu, "The superconvergent patch recovery and a posteriori error estimates," *IJNME* 33, 1992.
