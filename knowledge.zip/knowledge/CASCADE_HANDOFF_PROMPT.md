# Cascade Handoff Prompt — FEA Preprocessor + Solver Project

> Paste this block at the start of a Claude Code session that will work on
> this OpenGL/CUDA-accelerated Tet4/Tet10 FEA preprocessor + solver. It does
> NOT describe any one geometry, simulation, or TODO. It encodes the
> codebase conventions and pitfalls you will hit on **any** simulation task.

---

## 0. Project at a Glance

- **Stack**: C++17, MSVC, CMake + Ninja (`build.bat` is the entry point),
  OpenGL for rendering, CUDA + multithreading for the solver, TetGen for
  meshing, Eigen for linear algebra, GLM for geometry, GLFW for windowing.
- **Two executable targets**:
  - `FEAPreProcessor.exe` — interactive app (geometry input, meshing,
    solver dispatch, OpenGL visualisation).
  - `mesh_diag.exe` — standalone CLI mesh-quality diagnostic. Same source
    tree, different `main`, lighter dependency set.
- **Element types**: Tet4 (from TetGen directly) and Tet10 (built post-hoc
  by `FEAModel::generateMidEdgeNodes()` adding one node per unique edge).

---

## 1. Repository Conventions You Must Respect

### 1.1 Scope: stay inside `src/` and `include/`
- Per `AGENTS.md`, primary work area is `src/` (especially `src/build/` when
  it exists). Touch root-level files (`CMakeLists.txt`, `build.bat`,
  `*.vcxproj`) **only** when the task explicitly requires it.
- Do NOT clutter the workspace with throwaway helper scripts; if you need a
  diagnostic, write a single `.cpp` and delete it when done.

### 1.2 The `knowledge/` vault is gitignored
- It contains `theoritical/` (algorithm reference) and `TODOs/` (active
  roadmap). Treat it as authoritative project documentation.
- Default `grep_search` / `code_search` tools **cannot read it** because
  they honour `.gitignore`. Use raw shell reads instead:
  ```powershell
  Get-Content .\knowledge\TODOs\<file>.md
  Get-ChildItem .\knowledge -Recurse
  Select-String -Path .\knowledge\**\*.md -Pattern "<regex>"
  ```
- Every TODO file has a `## Depends on` line — follow it before starting.
- Every TODO has a `## Pass criterion` block — **validate the criterion
  itself** against the algorithm reference before treating it as gospel.
  Some TODOs were written by an LLM and contain too-strict or too-loose
  conditions.

### 1.3 Build system
- **Always** use `build.bat` rather than hand-driving CMake; it does the
  Visual Studio detection and `vcvars64.bat` sourcing for you.
- For standalone diagnostic compiles outside `build.bat`, you must source
  MSVC yourself:
  ```powershell
  $vs = & "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe" `
        -latest -property installationPath
  cmd /c "`"$vs\VC\Auxiliary\Build\vcvars64.bat`" && set" |
      ForEach-Object { if ($_ -match '^([^=]+)=(.*)$') {
          Set-Item "Env:$($Matches[1])" $Matches[2] } }
  ```
  Note the `${env:ProgramFiles(x86)}` form — parentheses require it.

---

## 2. Architecture Cheatsheet

```
main.cpp (UI loop, mode switch)
  │
  ├── MODE_CUBE  ─┐
  │                ├─→  FEAModel::generateCube()       ─┐
  ├── MODE_IMPORT ─┤    FEAModel::processRawGeometry() ─┤
  │                                                      ▼
  │                                          FEAModel::generateVolumetricMesh()
  │                                              │  (snapshots RefSurface,
  │                                              │   builds tetgenio, calls
  │                                              │   tetrahedralize, then
  │                                              │   MeshQuality::emitReport +
  │                                              │   MeshQuality::emitFidelityReport)
  │                                              ▼
  │                                          FEAModel::generateMidEdgeNodes()
  │                                              │  (optional Tet4 → Tet10)
  │                                              ▼
  └── "RUN SOLVER" button → FEASolver::solve...()
                              │  (assembly + linear/nonlinear solve,
                              │   uses Tet10 if hasQuadraticMesh)
                              ▼
                          OpenGL visualisation
```

Key state on `FEAModel`:
- `surfaceVertices` / `surfaceIndices` — input to TetGen.
- `tetrahedra` — Tet4 connectivity (4 indices per tet).
- `tetrahedraQuadratic` — Tet10 connectivity (10 indices per tet),
  populated only after `generateMidEdgeNodes()`.
- `hasQuadraticMesh` — boolean gate; solver reads it.
- `bboxVolume` — used as the denominator when converting
  `params.maxVolPercent` to the absolute volume cap passed to TetGen.

---

## 3. Common Bug Patterns — Watch For These

### 3.1 Per-corner Jacobian formulas need consistent cyclic ordering
A signed-volume-aware metric (scaled Jacobian, Knupp, etc.) computed at the
four corners of a tet must use orderings such that every corner's triple
product carries the **same sign** as the signed volume. A single wrong
permutation silently flips one corner and produces "inverted" verdicts on
geometrically valid meshes. Always derive the orderings algebraically from
the signed-volume determinant and verify on a canonical regular tet.

### 3.2 Stale class-member defaults
Members initialised in the header (`= some_default;`) are NOT automatically
recomputed when the geometry changes. Every geometry-producing function
(`generateCube`, `processRawGeometry`, custom importers) must explicitly
recompute derived quantities. Common offender: `bboxVolume`.

### 3.3 UI branch coverage
`main.cpp` has multiple top-level mode branches (cube, import, future:
boolean ops, primitives, ...). A new `FEAParams` knob added to one branch
is invisible in the others. When adding a slider, check **every** mode
branch — search `main.cpp` for the existing slider it should sit next to,
in each mode block.

### 3.4 Numerical guards
Every shape formula MUST contain:
- `if (det < 1e-30) return 0;`  (Knupp, sJ denominators).
- `cosTh = std::clamp(cosTh, -1.0, 1.0);` before any `acos`.
- Range clamp on the output `[0, 1]` for "shape" measures whose theoretical
  domain is bounded — float noise can land them just outside.

### 3.5 TetGen switch semantics
The TetGen switch string is built at runtime from `FEAParams`:
`pq%g/%ga%gAO%dT%g` where `q` and `/` separate radius-edge ratio from
min-dihedral, `a` is the absolute volume cap, `O` is the optimisation
level, `T` is the robustness tolerance. The min-dihedral target is a
**hint** to TetGen's smoother — it is not a hard mathematical lower bound.
Residual slivers below this target are expected and are addressed by
later TODOs (ODT smoothing, stellar flips, polish loops). For TODO_02,
MeshQuality uses percentage-based verdict semantics: `FAIL` only for
inverted elements; `WARN` for sliver tails above the accepted percentage;
`PASS` for zero inversions with both severe-sliver and below-target tails
`<= 1.0%`. Do not bake a "zero slivers" requirement into a TODO that only
invokes TetGen.

### 3.6 Tet4 vs Tet10 dispatch
`tetgenio` only carries Tet4 in this pipeline (TetGen is invoked without
`-o2`). Tet10 comes later. Any quality-evaluation or solver code that
must work for both element types needs **two entry points** — one consuming
`tetgenio`, one consuming `FEAModel::tetrahedraQuadratic` directly. The
solver already follows this pattern; new quality library functions should
too.

### 3.7 Multiple parallel diagnostic code paths
There are at least three places that compute "tet quality":
- `MeshQuality::*` — the canonical library (Knupp, dihedral, sJ).
- `mesh_diag.cpp` — older standalone tool using aspect ratio.
- `FEASolver.cpp` D4 diagnostic block — independent sliver counter.
Do not assume changes to one propagate to the others. If a TODO says
"the quality report", that means `MeshQuality::*`; the other two are
legacy or solver-internal.

### 3.8 TetGen trifacelist normal convention (inward-facing)
TetGen's `trifacelist` surface normals point **inward** when the mesh is
built with `-p` (PLC input). This is the opposite of the outward convention
used on the input PLCs and on OpenGL front faces. Any code comparing a
vol-boundary face normal against a reference surface normal **must** use
`std::acos(std::abs(cosT))` instead of `std::acos(cosT)`. If you see
`p95 ≈ 180°` in normal-deviation output, this is the cause — not a geometry
bug.

### 3.9 Vertex normals are wrong at sharp features — use face normals
Interpolated vertex normals (area-weighted average across adjacent faces) are
only correct for smooth (C1) surfaces. At sharp edges and corners of CAD
geometry (boxes, brackets, machined parts), vertex normals point diagonally
between adjacent orthogonal faces — e.g., at a cube corner the averaged
normal is ≈ 54.7° from any of the three face normals. Using vertex-normal
interpolation in fidelity or deviation checks on STL/PLC geometry causes
systematic false failures.
**Rule**: for piecewise-linear surfaces, use the face normal of the
nearest BVH-triangle directly (`refTriNrm[r.triIdx]`). Never interpolate
vertex normals on CAD geometry.

### 3.10 OCCT pImpl isolation — OCC headers in exactly two TUs
OpenCASCADE headers are large (~GB of templates). When adding OCC-based
features, use the pImpl pattern to confine OCC includes to exactly two
translation units: the BRepHandle implementation and the STEP loader.
- `include/BRepHandle.h` — OCC-free; forward-declares `struct Impl`; safe everywhere
- `src/BRepHandle_impl.h` — internal only; defines `BRepHandle::Impl` with `TopoDS_Shape`; included ONLY from `BRepHandle.cpp` and `StepLoader.cpp`
Any `.cpp` that is not explicitly OCC-aware must NOT include `BRepHandle_impl.h`.
Violation: OCC headers pulled into general TUs → hours-longer incremental builds.

### 3.11 TopAbs_REVERSED face winding — same class as TetGen inward normals
OCCT B-rep faces have `Orientation() == TopAbs_REVERSED` for roughly half
of the faces in a typical solid. When harvesting triangles from
`Poly_Triangulation`, you MUST swap indices n2 and n3 for REVERSED faces.
Failure: half the surface normals point inward → `normal deviation p95 ≈ 180°`
on those faces. Symptom is identical to TODO_03 Bug 1 (TetGen inward convention).
If you see ~180° normal deviation in fidelity output, check face orientation first.

### 3.12 unique_ptr<ForwardDeclaredType> requires destructor in .cpp
Any class that holds `std::unique_ptr<T>` where `T` is forward-declared in
the header MUST declare its destructor in the header (not `= default` there)
and define it `= default` in the `.cpp` where the complete type is available.
Example: `FEAModel` holds `unique_ptr<BRepHandle>` (forward-declared).
`FEAModel.h` declares `~FEAModel();`. `FEAModel.cpp` defines
`FEAModel::~FEAModel() = default;` after `#include "BRepHandle.h"`.
Without this the compiler silently emits the destructor with an incomplete type.

### 3.13 loadSTEP ordering — processRawGeometry resets brep
`processRawGeometry()` calls `brep.reset()` to clear stale B-rep state.
`loadSTEP()` must therefore assign the new B-rep AFTER calling
`processRawGeometry()`, not before — or the new B-rep would be wiped.
Pattern: hold the new B-rep in a local variable, call processRawGeometry,
then move the local into `model.brep`.

### 3.14 STL files have two formats — always support both
The STL spec allows ASCII and binary variants. Binary starts with an 80-byte
header, then `uint32 N`, then `N × 50` byte records. ASCII starts with
`"solid"` keyword. Many production exporters (OnShape, some Fusion 360
configs) emit **ASCII STL only**. Detection: if first 5 bytes == `"solid"`
AND `fileSize != 84 + N×50` → treat as ASCII; otherwise binary.
The ASCII parser tokenises by whitespace (`stream >> token`), collects every
`"vertex"` line, and groups consecutive triples into triangles.
**MSVC note**: MSVC rejects lambdas that capture by reference inside a
local struct's method body. Use a named struct (`Welder`) for shared
vertex-welding logic instead of a capturing lambda.

### 3.15 BVH vector must be reserved before recursive build
When building a tree recursively where each `buildNode()` call may push new
nodes to a `std::vector<Node>`, you **must** call `nodes.reserve(2 * nTris)`
before the first `buildNode()` call. Without it, the vector may reallocate
mid-recursion and invalidate any `Node&` references or pointers held on the
call stack, causing UB. After recursive calls, re-access parent nodes by
**index** (`nodes[parentIdx]`), never by reference.

---

## 4. Recommended Workflow per Task

1. **Read the TODO file completely** (`knowledge/TODOs/TODO_NN_*.md`).
2. **Resolve `Depends on:`** — read those upstream TODOs' DONE docs and
   any code they touched, so you know the existing API.
3. **Validate the pass criterion** against the algorithm reference under
   `knowledge/theoritical/`. Tighten or relax with explicit justification.
4. **Trace the full data path** for any quantity you touch:
   `UI slider → FEAParams field → consumer code → output`.
5. **Write a plan file** (`TODO_NN_plan.md`) listing concrete steps,
   numerical care points, multithreading pattern, and risks **before**
   editing source.
6. **Make the smallest possible edit** that satisfies the pass criterion.
   Prefer adding a function over modifying an existing one if the existing
   one is used by other call sites.
7. **Build & smoke-test** with `build.bat build` then run the executable
   on the simplest test fixture available; check console output literally
   matches the expected block in the TODO.
8. **If output is wrong, write a standalone diagnostic probe** before
   editing the library. A 100-line `.cpp` that links `tetgen.lib` and
   reproduces the math under suspicion is the fastest way to isolate
   plumbing bugs from math bugs.
9. **Document on completion** (`TODO_NN_DONE_documentation.md`) — big
   picture, files modified, bugs found, lessons learned. This format is
   used across the project.
10. **Update the regression sentinel** under `regression/` (snapshot text
    file) with new metric values, or document why the snapshot is changing.

---

## 5. Hard Forbiddens

- **Do not** weaken a TODO's pass criterion to make a failing test pass;
  rewrite the criterion with justification *first*, then ship.
- **Do not** silently mix Tet4 and Tet10 metrics in one summary block —
  the report must declare which one it ran.
- **Do not** add a numerical formula without denominator and `acos` guards.
- **Do not** create new top-level UI modes or new `FEAParams` fields
  without wiring them into every existing UI branch they apply to.
- **Do not** treat residual slivers as a TODO_01-class bug; they are
  handled by ODT / topology-flip TODOs further down the chain.
- **Do not** modify `mesh_diag.cpp` or `FEASolver.cpp` D4 diagnostics to
  "fix" a `MeshQuality` discrepancy — they are independent paths.

---

## 6. Quick-Reference Glossary

| Term | Meaning in this project |
|------|------------------------|
| `FEAParams` | `include/FEAData.h` struct; carries all meshing+solver knobs. |
| `tetgenio` | TetGen's I/O struct; holds points, facets, tetrahedra. |
| `bboxVolume` | Domain bounding-box volume; denominator for `maxVolPercent`. |
| `tetRadiusEdge` | TetGen `-q` ratio (lower = stricter; ~1.2 is tight). |
| `tetMinDihedralDeg` | TetGen `-q .../X` target and the reported MeshQuality sliver threshold; not a zero-tolerance PASS gate. |
| `tetOptimizeLevel` | TetGen `-O` (7 = full flips + Laplace). |
| `tetRobustnessTol` | TetGen `-T` (typical 1e-10). |
| `maxVolPercent` | UI slider in %, converted via `bboxVolume` to absolute `-a` value. |
| `worstNCount` | `MeshQuality` worst-N table length, default 10. |
| Scaled Jacobian | Per-corner shape measure; `<= 0` ⇒ inverted. |
| Knupp shape | $q = K \cdot 3 \det(J)^{2/3} / \|J\|_F^2$, $K = 2^{1/3}$. |
| Min-dihedral sliver | Tet with smallest dihedral angle below threshold. |
| `RefSurface` | `MeshQuality` struct: snapshot of input surface (positions + indices) taken **before** TetGen. Used by `computeFidelity()`. |
| `FidelityReport` | Hausdorff (max, p95) + normal deviation (p50/p95/p99/max) vs. input surface. Pass: Hausdorff < 1% bbox diag AND normal p95 < 15°. |
| `TriBVH` | Median-split BVH in `MeshQuality.cpp` anon namespace. Read-only after build → OpenMP-safe. |
| `refSurfaceForFidelity` | `FEAModel` member; populated in `generateVolumetricMesh()` before TetGen; cleared in `processRawGeometry()`. |
| `BRepHandle` | pImpl wrapper around `TopoDS_Shape`; provides `nearestPointOnShape()`, `normalAtNearest()`, `principalCurvatures()`. OCC-free public API. |
| `BRepHandle::Impl` | Internal OCC-aware struct (in `src/BRepHandle_impl.h`); holds `TopoDS_Shape`, `faceMap`, etc. Include only from `BRepHandle.cpp` + `StepLoader.cpp`. |
| `hasBRep()` | `FEAModel` predicate; true after a successful STEP load with OCC enabled. Gates fidelity path switch in `generateVolumetricMesh()`. |
| `loadSTEP()` | `FEAModel` method; calls `StepLoader::loadWithBRep()` then `processRawGeometry()`, then assigns `brep`. |
| `sizingChordError` | `FEAParams` field (default `1e-3`); multiplied by bbox diagonal to get `lin_def` for `BRepMesh_IncrementalMesh`. |
| `usedExactBRep` | `FidelityReport` bool; true when the forward fidelity pass used OCC exact nearest-point rather than the discrete BVH. |

---

## 7. First Five Things to Do in a New Session

1. `Get-ChildItem .\knowledge\TODOs` — list active TODOs.
2. Read the TODO assigned to you AND its `Depends on:` chain.
3. Read the matching `*_DONE_documentation.md` files for completed upstream
   TODOs to learn what API and conventions already exist.
4. Run `.\build.bat build` once to confirm the tree compiles before you
   change anything; if it doesn't, fix that first.
5. Write a plan file before editing any source.

---

*Hand this prompt to the next agent verbatim. It encodes hard-won
lessons from TODO_01 through TODO_03 so the next person does not
repeat them.*

*Last updated: 2026-05-19 (TODO_04 — STEP loader + analytic B-rep retention, OCCT pImpl, face-orientation winding, pImpl destructor rule)*


