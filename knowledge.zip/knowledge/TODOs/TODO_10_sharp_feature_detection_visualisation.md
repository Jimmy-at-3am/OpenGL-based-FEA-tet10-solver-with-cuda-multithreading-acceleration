# TODO_10 — Sharp feature detection + visualisation

## Goal
Detect ridges (high-dihedral surface edges) and corners on input STL/3MF; visualise them as yellow tubes + red spheres. Foundation for TODO_12 (sizing field clamping at features) and TODO_14 (fTetWild `--preserve-features`).

## Files added / modified
- **Add** `include/FeatureGraph.h`, `src/FeatureGraph.cpp` — two construction paths: `FeatureGraph::detect(surfaceVertices, surfaceIndices, ridgeAngleDeg)` (heuristic, STL/3MF source) and `FeatureGraph::fromBRep(brepHandle)` (exact, STEP source from TODO_04).
- **Modify** `src/FEAModel.cpp` — after surface load, dispatch on `model.hasBRep()`: BRep path → `FeatureGraph::fromBRep(*model.brep)`; else → `FeatureGraph::detect(...)`. Log the source.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — `F` key toggle for feature visualisation.
- **Modify** `src/ShaderSources.h` — add line + sphere primitives (or instanced quad billboards for both).

## Algorithm summary
From [knowledge/03_Surface_Meshing_Curved_Manifolds.md §6](knowledge/03_Surface_Meshing_Curved_Manifolds.md) and plan Appendix Phase C.0:

```text
FeatureGraph detectFeatures(surfaceVertices, surfaceIndices, ridgeAngleDeg = 30):
    For each shared edge e between adjacent triangles f_a, f_b (parallel):
        theta = acos(dot(normal(f_a), normal(f_b)))
        if theta > ridgeAngleDeg: tag e as RIDGE
    For each vertex v (parallel):
        ridgeCount = count of incident ridge edges
        if ridgeCount >= 3: tag v as CORNER
        else if ridgeCount == 2: tag v as RIDGE_VERTEX
        else if ridgeCount == 1: tag v as DANGLING (warn — usually input artefact)
    Build ridge graph: connected chains of ridge edges between corners (union-find)
    Return FeatureGraph { ridges, corners, vertexTags }
```

Visualisation:
- Ridges: 3D tube primitive (cylinder) per ridge edge, radius = $0.005 \cdot L_{\text{diag}}$, colour yellow.
- Corners: sphere primitive, radius = $0.01 \cdot L_{\text{diag}}$, colour red.

**STEP source — exact feature graph** (when `model.hasBRep()`, from TODO_04):
```text
FeatureGraph fromBRep(const BRepHandle& brep):
    For each TopoDS_Edge e in brep.edgeMap:
        if BRep_Tool::Curve(e) is not Geom_Line OR
           the two adjacent face normals differ by > ridgeAngleDeg:
            add e to ridges, snapping endpoints to surfaceVertex indices via uvMap
    For each TopoDS_Vertex v in brep.vertexMap:
        ridgeCount = count of incident ridge edges (BRep adjacency)
        if ridgeCount >= 3: add v to corners
    Skip the dihedral heuristic and union-find entirely; BRep topology is exact.
    Log: "[Features] source: STEP B-rep (exact); ridges:N corners:M"
```
No false positives from polygonal-cylinder discretisation (the 22.5° issue from the STL path doesn't exist — BRep edges are explicitly tagged).

## Multithreading
Per-edge / per-vertex parallel-for; ridge-chain union-find is serial but $O(N \alpha(N))$ — trivial.

## Numerical care points
- **`ridgeAngleDeg = 30°` default** (care-point #15). Polygonal CAD imports (e.g. 8-sided cylinders) have legitimate-but-spurious 22.5° dihedrals; do NOT lower the default. Expose `params.ridgeAngleDeg` for override.
- `acos` clamp (care-point #16).
- Normal direction: use consistent winding (outward-pointing). If the input is mis-oriented, the dihedral check gives wrong sign — invoke a quick winding-number sanity check at startup.

## Screen-visible acceptance check

**Setup** Load `assets/test_fixtures/unit_cube.stl`, then separately `assets/test_fixtures/unit_cube.step` (from TODO_04).

**Action** Press `F` (or click `Show Features`) for each file.

**Expected visible** (both files)
- 12 yellow thick lines along the cube edges (one per ridge), drawn as 3D tube primitives.
- 8 red spheres at the cube corners.
- Console for STL: `[Features] source: dihedral heuristic (ridgeAngle=30°); ridges: 12   corners: 8   ridge-vertices: 0`.
- Console for STEP: `[Features] source: STEP B-rep (exact); ridges: 12   corners: 8   ridge-vertices: 0`.
- Pressing `F` again hides them.

**Failure modes**
- More than 12 ridges → `ridgeAngleDeg` too low (catches discretisation artefacts).
- 0 ridges on cube → dihedral computed in radians compared to degrees threshold (or vice versa).
- Corners detected at wrong positions → ridge-graph connected-components bug.

**Pass criterion** Exactly 12 ridges + 8 corners visible for the unit cube.

## Regression sentinel
`regression/features_cube.txt` — ridge count + corner count for unit cube.

## Depends on
TODO_05 (HUD infrastructure to share the overlay rendering path).

## Estimated effort
2 days.
