# TODO_13 — AsyncTask + progress UI + cancellation

## Goal
Run long-running operations (TetGen on big meshes, fTetWild, MMG3D, ODT iterations, AMR cycles) on a background thread with an in-viewer progress bar, stage label, and `Cancel` button. UI must remain responsive (mouse-drag-rotate works during the operation).

## Files added / modified
- **Add** `include/AsyncTask.h`, `src/AsyncTask.cpp` — `class AsyncTask` with atomic progress, stage, cancellation; one global instance per concurrent task.
- **Modify** `src/SimpleUI.cpp` — add progress-bar widget + `Cancel` button + ESC handler.
- **Modify** `src/main.cpp:418` (Generate 3D Mesh) and every other long-running button — wrap the call.
- **Modify** `src/FEAModel.cpp::generateVolumetricMesh()` — accept optional `AsyncTask*` arg and publish progress at stage boundaries.

## Algorithm summary
From plan Appendix Phase H:

```cpp
class AsyncTask {
public:
    std::thread worker;
    std::atomic<float>  progress{0.0f};
    std::atomic<int>    stage{0};
    std::atomic<bool>   cancelled{false};
    std::atomic<bool>   finished{false};
    std::string         label;

    template<typename F>
    void launch(std::string lbl, F&& fn) {
        label = std::move(lbl);
        worker = std::thread([this, fn = std::forward<F>(fn)]{
            try { fn(*this); }
            catch (const std::exception& e) {
                std::cerr << "[AsyncTask " << label << "] " << e.what() << '\n';
            }
            finished = true;
        });
    }
    void join() { if (worker.joinable()) worker.join(); }
};
```

UI side:
```cpp
if (!g_meshTask.finished) {
    ui.drawProgressBar(g_meshTask.label,
                       g_meshTask.progress.load(),
                       g_meshTask.stage.load());
    if (ui.button("Cancel", ...) || io.keysDown[KEY_ESC])
        g_meshTask.cancelled.store(true);
}
if (g_meshTask.finished) g_meshTask.join();
```

## Multithreading
**The point of this TODO.** Worker thread runs the heavy op (which internally uses OMP — nested threading is fine; total cores stays bounded by `OMP_NUM_THREADS`). Main thread keeps rendering at 60+ fps because the work moved off it.

Cancellation is cooperative: each heavy op (ODT, Stellar, fTetWild adapter, MMG adapter, AMR cycle) checks `task.cancelled.load()` at iteration boundaries and returns early. Do NOT abort mid-Eigen-call.

## Numerical care points
- Render path must read mesh state only from `model.deformedVolumetricPositions` (or whatever it reads today). Mesh-driver writes are committed via **atomic-swap** of an entire vector (or via a generation counter checked by the renderer) — no half-written state visible. Care-point in plan §7 risk register.
- Cancel during fTetWild / MMG3D: those libraries are not cancellation-aware. Check `cancelled` before *launching* the call; once inside, can't interrupt. Communicate via UI label: "Cancelling — finishing current pass".

## Screen-visible acceptance check

**Setup** Load a moderately large STL (e.g. `assets/test_fixtures/bracket_100k.stl`).

**Action** Click `Generate 3D Mesh`. Immediately try to rotate the view with mouse drag.

**Expected**
- Bottom-of-viewer status bar appears within 200 ms: `[Mesh generation] stage: 2/4 (TetGen refine) — 47%   [Cancel]`.
- Mouse drag still rotates the model smoothly during the entire operation.
- Bar progresses to 100%; status bar fades out after completion.
- Pressing `Esc` (or clicking `Cancel`) during the op aborts cleanly; status shows `Cancelled`; previous mesh restored.

**Failure modes**
- UI freezes → mesh op still on main thread; AsyncTask launched but `.join()` called synchronously.
- Bar appears but never updates → progress counter not written from worker thread / not read by UI.
- Cancel crashes → mid-Eigen-call abort; cancel must check between iterations only.

**Pass criterion** Rotation responsive during mesh op AND progress visibly advances AND cancel works without crash.

## Regression sentinel
None automated — manual check required (UI responsiveness can't be regression-tested in console).

## Depends on
None — independent infrastructure piece. (But everything from TODO_14 onward depends on this.)

## Estimated effort
2 days.
