---
title: Adaptive Refinement — h, p, hp, and DWR
type: algorithm
tags: [adaptive, hp-fem, dwr, goal-oriented, zienkiewicz-zhu, residual, error-estimator]
created: 2026-05-16
---

# 11 — Adaptive Refinement: h-, p-, hp-, and Goal-Oriented DWR

A non-adaptive (uniform) FE solution converges at rate $h^p$ in $H^1$, but the constant depends on the global $H^{p+1}$ semi-norm of the exact solution. When the solution has singularities (re-entrant corners, contact edges, cracks, shocks), uniform refinement is asymptotically wasteful — the **best mesh** concentrates DOFs around singularities. Adaptive refinement automates this concentration via a posteriori error estimators.

This note covers the three estimator families (recovery-based, residual, dual-weighted-residual) and the four refinement strategies (h, p, r, hp), with attention to the specific implementations in COMSOL, ANSYS, and MATLAB.

---

## 1. The Adaptive Loop

```text
SOLVE  →  ESTIMATE  →  MARK  →  REFINE  →  (repeat)
```

- **SOLVE**: standard FE solve on current mesh.
- **ESTIMATE**: compute $\eta_T$ for every element $T$.
- **MARK**: select elements to refine. Dörfler marking (1996): smallest $\mathcal{M}\subset\mathcal{T}$ with $\sum_{T\in\mathcal{M}}\eta_T^2 \ge \theta\sum_T\eta_T^2$ for $\theta\in[0.3,0.7]$.
- **REFINE**: subdivide marked elements; rebalance hanging nodes if needed.

Convergence theory:
- **Plain convergence**: most estimators give $\|u-u_h\|_{H^1}\to 0$.
- **Optimal complexity**: AFEM with Dörfler marking + bisection refinement achieves $\|u-u_h\| \le C\,N^{-p/d}$ — the best possible for piecewise-polynomials of order $p$ in $d$ dimensions (Cascón, Kreuzer, Nochetto, Siebert 2008).

---

## 2. Recovery-Based Estimators (Zienkiewicz–Zhu)

**Idea**: the discrete stress $\sigma_h$ is discontinuous across elements. A *smoother* recovery $\sigma^*$ is closer to the exact $\sigma$ than $\sigma_h$. The discrepancy $\sigma^*-\sigma_h$ is then an estimator for $\sigma_h - \sigma$.

### 2.1 The estimator

For elasticity with constitutive matrix $D$:

$$
\eta_T^{\mathrm{ZZ}} = \left(\int_T (\sigma^*-\sigma_h)^T D^{-1}(\sigma^*-\sigma_h)\,dx\right)^{1/2}.
$$

Globally $\eta_h = \sqrt{\sum_T\eta_T^2}$ approximates $\|u-u_h\|_{\text{energy}}$. Empirically $\eta_h/\|u-u_h\|_{\text{energy}}\in[0.7,1.3]$ on smooth solutions — **effective** (efficiency index near 1).

### 2.2 Recovery procedure — Superconvergent Patch Recovery (SPR), Zienkiewicz–Zhu 1992

```text
for each vertex v:
   patch ω_v = ∪{T : v ∈ T}
   sample σ_h at the superconvergent points inside each T ∈ ω_v
   fit a polynomial σ̂_v(x) of degree p (least-squares) at v
σ*(x) = ∑_v N_v(x) σ̂_v(v_pos)
```

The "superconvergent points" for Tet10 are the 4 Hammer points used in the host project ([theory.md](../theory.md) §2.2). At these points $\sigma_h$ is $\mathcal{O}(h^{p+1})$ accurate — one order better than the global rate, hence "superconvergent."

### 2.3 Variants

- **Polynomial-Preserving Recovery (PPR)** (Zhang–Naga 2005): always recovers polynomials of degree $p$ exactly; superconvergent even on unstructured tets.
- **SPR-C** (Wiberg–Abdulwahab 1997): includes equilibrium constraint for stress recovery; sharper estimator near boundaries.

### 2.4 In commercial codes

- **ANSYS Mechanical** — `STDF Stress Difference` error estimate is SPR-style for solid elements.
- **MATLAB PDE Toolbox** — `pdejmps` (the residual-based jump estimator) and `pdeprtni` (recovery) both available; `adaptmesh` uses by default a hybrid.
- **COMSOL** — "Residual" stop condition can be SPR-recovered.

---

## 3. Residual-Based Estimators

Direct from the strong-form residual. For the elastic Cauchy equation $\nabla\cdot\sigma+b=0$:

$$
\eta_T^{\mathrm{res}} = \left(h_T^2\,\|\,\nabla\cdot\sigma_h+b\,\|_{0,T}^2 \;+\; \sum_{F\subset\partial T}h_F\,\|[\![\sigma_h\cdot n_F]\!]\|_{0,F}^2\right)^{1/2}.
$$

Two terms: **element residual** (PDE not satisfied inside $T$) and **edge/face jump** (stress not continuous across element boundaries). Globally **reliable**: $\|u-u_h\|_{H^1}\le C\eta$ holds with a *computable* $C$. But **not asymptotically efficient** — the constant $C$ may inflate the estimator by an order of magnitude.

**Use case:** mathematically rigorous a-posteriori bounds (e.g. for verification in safety-critical analyses, FDA-regulated medical-device FEA). Implemented in `deal.II`, `FEniCS`, and verified-FEM tools.

---

## 4. Goal-Oriented / DWR Estimators (Becker–Rannacher 2001)

For problems where the engineering output is a **specific quantity of interest** $J(u)$ — e.g. peak von Mises stress at a notch, drag coefficient, stress intensity factor — the *energy norm* is the wrong objective. We want a mesh that resolves $J(u_h)\to J(u)$ as fast as possible.

### 4.1 The dual problem

Define the dual / adjoint solution $z$ by

$$
a(v, z) = J(v) \quad \forall v\in V.
$$

For linear elasticity with $J(u) = \int_{\Omega_{\text{QoI}}} \sigma_{xx}(u)\,dx$, the dual problem is **another elasticity problem** with a synthetic body force $b_z = \nabla\cdot(\text{indicator}\cdot e_x e_x^T)$. Same matrix, different RHS — cheap to solve.

### 4.2 The DWR error representation

For symmetric bilinear forms:

$$
J(u) - J(u_h) = a(u-u_h, z) = \sum_T \rho_T(u_h)\,(z - z_h)|_T,
$$

where $\rho_T$ is the local primal residual. The factor $(z-z_h)|_T$ — small in regions where the dual is well-resolved by $z_h$ — **localises** the error contribution to elements whose refinement actually moves $J(u_h)$.

### 4.3 Practical DWR

In practice $z$ is unknown; we approximate:

$$
z - z_h \approx z_h^{p+1} - z_h^p,
$$

i.e. solve the dual on the *same mesh* with one higher polynomial degree (and project down). Computed cost: ~2× the primal solve. The estimator is then **goal-oriented and locally efficient**.

### 4.4 Industrial wins from DWR

- **Crack-tip stress intensity** — DWR concentrates DOFs around the crack tip, reducing required nodes by 10–100× vs energy-norm refinement (Rannacher & Suttmeier 1998).
- **Aerodynamic drag prediction** — Venditti–Darmofal 2003; converged $C_D$ on a wing in 1/10 the cells.
- **Failure-load prediction** — DWR for the dual of the contact-energy or limit-load functional (Rüter 2005).

### 4.5 In commercial codes

DWR is not yet mainstream in commercial FEA:
- **ANSYS** — research-only `goalbased` refinement in 2024R2.
- **COMSOL 6.3** — has a "Functional" adaptive option (goal-oriented) since 5.5; uses recovery-based dual estimator.
- **MATLAB** — manual implementation only.
- **deal.II / FEniCS / DUNE** — first-class DWR support.

This is the largest gap between research best practice and commercial adoption in 2025 — anyone whose analysis output is a single number should learn DWR.

---

## 5. The Refinement Strategies — h, p, r, hp

### 5.1 h-refinement

**Bisection** (longest-edge or newest-vertex bisection): each marked tet is split into 2; provably terminating and produces non-degenerate meshes (Maubach 1995). Hanging nodes are avoided by **edge-marking propagation**.

Alternative: **red-green refinement** (Bey 1995): regular (red) split of marked elements; green closure of neighbours to maintain conformity. Tet variant: 8-tet split (one octant per child).

### 5.2 p-refinement

Increase polynomial order of marked elements; hanging node handling on $p$-interfaces requires constraint equations or DG patches. Effective for **smooth solutions** — exponential convergence $\|u-u_h\| = \mathcal{O}(e^{-c\sqrt{N}})$ on analytic data (Babuška–Suri 1990).

### 5.3 r-refinement (mesh motion)

Move vertices without changing topology to equidistribute the error indicator. Equivalent to MMG3D smoothing with the local error as the metric ([[08_Anisotropic_Metric_Adaptation]]). Continuous, gradient-friendly for optimisation, but caps at modest accuracy gains because element count is fixed.

### 5.4 hp-refinement

The mathematically optimal strategy. Decision rule (Melenk–Wohlmuth 2001):

- if the local solution is **smooth** (indicator: $\eta_T$ drops as $h$ shrinks faster than $p^{-1}$): **increase $p$**.
- if the local solution is **singular** (gradient blows up): **decrease $h$** and **keep $p$ low**.

Achieves **exponential convergence on singular solutions**: $\|u-u_h\| = \mathcal{O}(e^{-c\sqrt[3]{N}})$ in 3-D for piecewise-analytic data. Implemented in `deal.II` `hp::FECollection`, `Nektar++`, MFEM. Commercial support: limited.

---

## 6. Algorithm Recipe — Goal-Oriented Adaptive Solve

```text
input  : QoI functional J, tolerance tol_J
output : mesh and solution with |J(u) - J(u_h)| ≤ tol_J

1. Generate initial mesh T_0 (e.g. uniform).
2. for k = 0, 1, 2, …:
     a. Solve primal: a(u_h, v) = (f, v) ∀v on T_k.
     b. Solve dual:   a(v, z_h) = J(v) ∀v on T_k.
        (Optionally with one higher p for the dual.)
     c. Compute η_T = |ρ_T(u_h)| · |z - z_h|_T.
     d. If Σ η_T < tol_J: STOP.
     e. Mark elements via Dörfler with θ = 0.5.
     f. Refine marked elements (bisection or anisotropic via MMG).
3. Return final u_h.
```

For best industrial performance combine with [[08_Anisotropic_Metric_Adaptation]]: build the metric from a goal-oriented Hessian ($z$-weighted) rather than the plain primal Hessian (Power–Hannan 2006).

---

## 7. Comparison of Estimator Families

| Family | Reliable | Efficient | Cost vs solve | Use case |
|---|---|---|---|---|
| Recovery (ZZ, SPR, PPR) | empirically | yes | 5% | default in commercial codes |
| Residual (explicit) | provably (with comput. $C$) | no (over-estimates) | 5% | verification, math.-rigour |
| DWR (goal-oriented) | yes | locally super-efficient | +100% (extra solve) | engineering QoI |
| Hierarchical (Bank–Smith) | yes | yes | +30% | hp-FEM internals |

---

## 8. References

- O. C. Zienkiewicz & J. Z. Zhu, "The superconvergent patch recovery and a posteriori error estimates," *IJNME* 33, 1992.
- R. Verfürth, *A Posteriori Error Estimation Techniques for Finite Element Methods*, Oxford Univ. Press, 2013.
- R. Becker & R. Rannacher, "An optimal control approach to a posteriori error estimation in finite element methods," *Acta Numerica* 10, 2001.
- W. Dörfler, "A convergent adaptive algorithm for Poisson's equation," *SINUM* 33, 1996.
- J. M. Cascón, C. Kreuzer, R. H. Nochetto, K. G. Siebert, "Quasi-optimal convergence rate for an adaptive finite element method," *SINUM* 46, 2008.
- C. Schwab, *p- and hp-Finite Element Methods*, Oxford 1998.
- D. A. Venditti & D. L. Darmofal, "Anisotropic grid adaptation for functional outputs," *J. Comput. Phys.* 187, 2003.
- T. Grätsch & K.-J. Bathe, "A posteriori error estimation techniques in practical finite element analysis," *Computers & Structures* 83, 2005.
- ANSYS, "Adaptive Solution," *Mechanical APDL Theory Reference* 2024R2 §19.
- COMSOL, "Adaptive Mesh Refinement," *Reference Manual* 6.3.
- Annotated list in [[15_References_Bibliography]].
