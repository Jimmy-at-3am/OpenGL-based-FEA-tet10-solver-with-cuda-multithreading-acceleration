---
title: Mathematical Foundations of Meshing
type: foundation
tags: [delaunay, voronoi, manifold, cvt, metric, riemannian]
created: 2026-05-16
---

# 01 — Mathematical Foundations

This note collects the mathematical machinery that every meshing algorithm in the vault either uses directly or relies on for proofs of correctness. It is the **single source of truth** for the notation used throughout. Cross-references to algorithm notes are interspersed.

---

## 1. Simplicial Complexes

A $k$-simplex $\sigma^k$ is the convex hull of $k+1$ affinely independent points $\{p_0,\dots,p_k\}\subset\mathbb{R}^d$. A finite collection $\mathcal{K}$ of simplices is a **simplicial complex** iff:

1. Every face of a simplex in $\mathcal{K}$ is in $\mathcal{K}$.
2. The intersection of any two simplices is either empty or a common face.

For meshing we usually require $\mathcal{K}$ to be a **piecewise-linear manifold** (with or without boundary), i.e. the star of every vertex is a topological disk (in 2-D) or ball (in 3-D).

The **underlying space** $|\mathcal{K}|=\bigcup_{\sigma\in\mathcal{K}} \sigma$ is the geometric mesh.

> [!note] Why this matters for FEA
> The Galerkin space $V_h\subset H^1(\Omega)$ is defined on $|\mathcal{K}|$. If $\mathcal{K}$ violates condition (2) — e.g. a "hanging node" — then $V_h\not\subset H^1$ and the discretisation loses conformity. This rules out unmatched-octree meshes for standard FEM (they require **mortar** or **DG** patches), and motivates the BCC stuffing and CDT(3) algorithms covered in [[06_Octree_BCC_and_Isosurface_Stuffing]] and [[04_Delaunay_CDT_and_TetGen]].

---

## 2. Voronoi Diagrams and Delaunay Triangulations

Given a point set $P=\{x_1,\dots,x_n\}\subset\mathbb{R}^d$ in general position, the **Voronoi cell** of $x_i$ is

$$
V_i = \{x\in\mathbb{R}^d \;|\; \|x-x_i\|_2 \le \|x-x_j\|_2,\; \forall j\ne i\}.
$$

The collection $\{V_i\}$ partitions $\mathbb{R}^d$ into convex polyhedra meeting only on shared faces. The **Delaunay complex** $\mathrm{Del}(P)$ is the nerve of this partition: simplices are tuples whose Voronoi cells share a common point.

### Empty-sphere property

A $d$-simplex $\sigma$ formed by $d+1$ points in $P$ is in $\mathrm{Del}(P)$ iff its **circumball** contains no other point of $P$ in its open interior.

This is the operational criterion used by every Delaunay-based algorithm — see [[04_Delaunay_CDT_and_TetGen]].

### Optimality (2-D)

In $\mathbb{R}^2$ the Delaunay triangulation **maximises the minimum angle** over all triangulations of $P$ (Sibson 1978). In $\mathbb{R}^3$ this lex-max property fails — there exist point sets ("slivers", see [[02_Mesh_Quality_Metrics]] §5) where the Delaunay tetrahedralization contains arbitrarily flat tetrahedra. Hence **3-D Delaunay alone is insufficient** and we must add smoothing or sliver-removal post-processing.

### Duality

The Voronoi diagram and Delaunay complex are dual cell complexes:

$$
\dim(\sigma^k_{\text{Del}}) + \dim(\sigma^{d-k}_{\text{Vor}}) = d.
$$

This duality powers the polyhedral meshers in [[07_Polyhedral_Mosaic_and_Voronoi]] and the CVT/ODT smoothers in [[12_Mesh_Smoothing_CVT_and_ODT]].

### Generalisations relevant to meshing

| Variant | Idea | Used by |
|---|---|---|
| **Weighted Delaunay (regular triangulation)** | Power distance $\|x-x_i\|^2 - w_i$ | sliver perturbation (Edelsbrunner–Shah 1996) |
| **Constrained Delaunay (CDT)** | Empty-sphere only required *modulo* protected constraint edges/faces | TetGen, Triangle |
| **Restricted Voronoi diagram (RVD)** | $V_i \cap \mathcal{S}$ for a surface $\mathcal{S}$ | surface CVT — [[03_Surface_Meshing_Curved_Manifolds]] |
| **$k$th-order Voronoi** | nearest-$k$ relation | mesh refinement priority queues |
| **Anisotropic Voronoi** | $\|x-x_i\|_{M(x_i)}$ in a metric field $M$ | anisotropic adaptation — [[08_Anisotropic_Metric_Adaptation]] |

---

## 3. Smooth and Piecewise-Smooth Manifolds

A **$C^k$ 2-manifold** $\mathcal{S}\subset\mathbb{R}^3$ is locally diffeomorphic to $\mathbb{R}^2$. For meshing we need three numerical descriptors:

### 3.1 First fundamental form (metric)

For a chart $\varphi:U\subset\mathbb{R}^2\to\mathcal{S}$, the **first fundamental form** is

$$
\mathbf{I} = \begin{bmatrix} E & F \\ F & G \end{bmatrix}, \quad
E = \varphi_u\cdot\varphi_u,\; F=\varphi_u\cdot\varphi_v,\; G=\varphi_v\cdot\varphi_v.
$$

Areas and angles in $\mathcal{S}$ are computed via $\mathbf{I}$; mesh elements in parameter space are *isotropic on $\mathcal{S}$* only when $\mathbf{I}$ is used as the inner product, not the Euclidean one. This is the foundation of **anisotropic parametric meshing** ([[03_Surface_Meshing_Curved_Manifolds]] §3).

### 3.2 Second fundamental form (curvature)

The shape operator $S = \mathbf{I}^{-1}\mathbf{II}$ has eigenvalues $\kappa_1,\kappa_2$ — the **principal curvatures**. Two derived quantities drive mesh sizing:

$$
H = \tfrac{1}{2}(\kappa_1+\kappa_2)\quad\text{(mean curvature)}, \qquad
K = \kappa_1\kappa_2\quad\text{(Gaussian curvature)}.
$$

### 3.3 Reach

The **reach** $\tau(\mathcal{S})$ is the largest $r$ such that every point within distance $r$ of $\mathcal{S}$ has a unique nearest point on $\mathcal{S}$ (Federer 1959). For sampling-based mesh reconstruction, an **$\varepsilon$-sample** with $\varepsilon < 0.1\,\tau(\mathcal{S})$ guarantees Amenta–Bern crust-style reconstruction. Modern surface meshers ([[03_Surface_Meshing_Curved_Manifolds]]) instead use the **local feature size** $\mathrm{lfs}(x)=\mathrm{dist}(x, \mathrm{medial axis})$ as a position-dependent reach.

### 3.4 Piecewise-smooth domains

CAD B-reps are *piecewise* $C^k$ with explicit feature graph $\mathcal{G}=(V_{\text{corner}}, E_{\text{ridge}}, F_{\text{face}})$. Meshing must respect this graph; the **CDT-with-feature-protection** strategy (Si & Shewchuk 2014) is described in [[04_Delaunay_CDT_and_TetGen]] §4.

---

## 4. Riemannian Metric Fields for Anisotropic Meshing

Anisotropic mesh adaptation generalises step (3.1) to the whole computational domain: equip $\Omega$ with a continuous field of symmetric positive-definite $d\times d$ matrices $M:\Omega\to\mathrm{Sym}^+_d(\mathbb{R})$. An ideal mesh in metric $M$ is **unit**: every edge $pq$ satisfies

$$
\ell_M(pq) = \int_0^1 \sqrt{(q-p)^T M(p+t(q-p))\,(q-p)}\;dt = 1.
$$

The eigenvectors of $M(x)$ define the local anisotropy axes; the eigenvalues $\lambda_i$ set $h_i = \lambda_i^{-1/2}$ as the prescribed edge lengths along those axes.

### Metric construction from a recovered Hessian

For a scalar field $u$, the Loseille–Alauzet (2010) **continuous mesh framework** uses

$$
M(x) = \frac{1}{\varepsilon} \, \left|H_u(x)\right|^{*}, \qquad
|H|^* = R \,|\Lambda|\, R^T,\; H = R\Lambda R^T,
$$

i.e. the absolute-value Hessian, scaled so the total complexity $\int_\Omega \det(M)^{1/2}\,dx \approx N$ (the desired node count). This minimises the $L^p$-norm of the interpolation error.

### Log-Euclidean interpolation (Arsigny 2006)

Metrics cannot be linearly interpolated (the SPD cone is not closed under naive addition with negative weights). The **log-Euclidean mean** of $M_1,\dots,M_n$ with weights $w_i$ is

$$
\overline{M} = \exp\!\left(\sum_i w_i \log M_i\right),
$$

which always lies in $\mathrm{Sym}^+_d$. MMG3D and feflo.a both use this; see [[08_Anisotropic_Metric_Adaptation]] §2.

---

## 5. Centroidal Voronoi Tessellations (CVT)

A Voronoi diagram is **centroidal** when every site coincides with the centroid of its Voronoi cell:

$$
x_i = c_i := \frac{\int_{V_i} \rho(x)\,x\,dx}{\int_{V_i} \rho(x)\,dx},
$$

with $\rho$ an optional density. CVTs minimise the **quantization energy**

$$
\mathcal{F}(\{x_i\}) = \sum_{i=1}^n \int_{V_i} \rho(x)\,\|x-x_i\|^2 \,dx.
$$

### Lloyd iteration

$$
x_i^{(k+1)} = c_i^{(k)}, \qquad k=0,1,2,\dots
$$

Convergence is linear and slow ($\mathcal{O}(1/k)$ rate). Liu et al. (2009) showed $\mathcal{F}$ is $C^2$ in $\{x_i\}$ and applied **L-BFGS** to obtain super-linear convergence — used in modern meshers and discussed in [[12_Mesh_Smoothing_CVT_and_ODT]].

### Restricted CVT (RCVT)

When the integration domain is a 2-manifold $\mathcal{S}\subset\mathbb{R}^3$, replace $V_i$ by $V_i\cap\mathcal{S}$. The resulting Delaunay dual is the **restricted Delaunay triangulation** of $\mathcal{S}$ — the workhorse of surface meshing on curved manifolds ([[03_Surface_Meshing_Curved_Manifolds]] §4).

---

## 6. Optimal Delaunay Triangulation (ODT)

Chen & Holst (2011) propose to instead minimise the **interpolation $L^2$ error** of $\tfrac{1}{2}\|x\|^2$ over the Delaunay triangulation $T$:

$$
\mathcal{E}_{\mathrm{ODT}}(\{x_i\}) = \int_\Omega \|x-I_T(\tfrac{1}{2}\|x\|^2)(x)\|\,dx
= \sum_{T_j} \int_{T_j} \tfrac{1}{2}\|x\|^2 - \tfrac{1}{2}\langle I_{T_j} \|x\|^2\rangle\,dx,
$$

whose gradient is closed-form and depends only on the local 1-ring. ODT produces meshes with better worst-case dihedral angles than CVT and is the smoother of choice for tetrahedral meshes — see [[12_Mesh_Smoothing_CVT_and_ODT]] §3.

---

## 7. Function-Approximation Theoretic Targets

Modern adaptive meshing is framed around equidistributing the **a posteriori** error indicator $\eta_T$ over elements $T$. Three estimator families dominate practice:

### 7.1 Zienkiewicz–Zhu (ZZ) recovery (1987, 1992)

For elastic FEM, recover a smoother stress field $\sigma^*$ by patch-wise least-squares projection and compute

$$
\eta_T^{\mathrm{ZZ}} = \left(\int_T (\sigma^*-\sigma_h)^T D^{-1}(\sigma^*-\sigma_h)\,dx\right)^{1/2}.
$$

This is the default driver in ANSYS Mechanical, MATLAB PDE Toolbox `adaptmesh`, and COMSOL's "residual-based" criterion. See [[11_Adaptive_Refinement_hp_and_DWR]] §2.

### 7.2 Residual-based explicit estimator

$$
\eta_T^{\mathrm{res}} = \left(h_T^2 \|r_T\|_{0,T}^2 + \sum_{F\subset\partial T} h_F \|j_F\|_{0,F}^2\right)^{1/2}
$$

with element residual $r_T = f - L u_h|_T$ and inter-element jump $j_F = [\![\sigma_h\cdot n_F]\!]$. Reliable but not asymptotically efficient.

### 7.3 Dual-weighted residual (DWR / goal-oriented)

For a quantity of interest $J(u)$, solve the dual problem $L^* z = J$ (often approximately via $p$-enriched dual) and weight the primal residual:

$$
J(u)-J(u_h) \approx \sum_T \rho_T(u_h)\,(z-z_h)|_T.
$$

The locality of $z-z_h$ concentrates refinement only where it actually pays for the QoI. Becker–Rannacher 2001 — see [[11_Adaptive_Refinement_hp_and_DWR]] §4.

---

## 8. Notation Used Throughout the Vault

| Symbol | Meaning |
|---|---|
| $\Omega\subset\mathbb{R}^d$ | computational domain |
| $\mathcal{S}$ | surface (2-manifold in $\mathbb{R}^3$) |
| $\mathcal{K}$, $\mathcal{T}_h$ | simplicial complex / mesh with characteristic size $h$ |
| $P$, $x_i$ | point set / vertex positions |
| $V_i$ | Voronoi cell of $x_i$ |
| $M(x)$ | Riemannian metric tensor at $x$ |
| $\ell_M(pq)$ | metric length of edge $pq$ |
| $\rho_T$ | element shape regularity (inverse aspect ratio) |
| $\eta_T$ | local error indicator on element $T$ |
| $\sigma_h$, $u_h$ | FE stress / displacement fields |
| $\mathrm{lfs}(x)$ | local feature size |
| $\tau$ | reach of a surface |
| $\kappa_1,\kappa_2$ | principal curvatures |

---

## 9. Further Reading

- M. de Berg, *Computational Geometry: Algorithms and Applications*, 3rd ed., chapters on Voronoi/Delaunay.
- J. R. Shewchuk, "What is a Good Linear Finite Element? Interpolation, Conditioning, Anisotropy, and Quality Measures." (unpublished, 2002) — the canonical reference for §7.
- F. Loseille & F. Alauzet, "Continuous mesh framework parts I & II," *SIAM J. Numer. Anal.* 49(1), 2011 — anisotropic theory.
- Q. Du, V. Faber, M. Gunzburger, "Centroidal Voronoi tessellations: Applications and Algorithms," *SIAM Review* 41(4), 1999 — CVT canonical reference.
- L. Chen & M. Holst, "Efficient mesh optimization schemes based on Optimal Delaunay Triangulations," *CMAME* 200, 2011.
- Full annotated list in [[15_References_Bibliography]].
