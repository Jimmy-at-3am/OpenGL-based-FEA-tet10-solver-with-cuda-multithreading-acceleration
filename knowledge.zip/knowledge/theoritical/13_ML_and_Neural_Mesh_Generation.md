---
title: ML and Neural Mesh Generation (2020–2025)
type: algorithm
tags: [machine-learning, gnn, neural-network, meshgraphnets, learned-sizing, deepmesh, frontier]
created: 2026-05-16
---

# 13 — Machine Learning and Neural Approaches to Mesh Generation (2020–2025)

Until ~2019, mesh generation was untouched by deep learning. Since 2020 a coherent research programme has emerged with three threads:

1. **Learned mesh-sizing fields** — predict $h(x)$ from the geometry + PDE features, then call a classical mesher.
2. **Direct neural mesh generation** — output vertex positions and/or connectivity end-to-end from input geometry.
3. **Neural solvers operating on graphs** — *MeshGraphNets* (Pfaff 2020) and successors that learn the time-evolution of PDE solutions on a mesh and can adapt the mesh during training.

This note surveys the field with attention to which methods are **production-viable in 2025** and which remain research. Pre-requisite reading: classical adaptation [[11_Adaptive_Refinement_hp_and_DWR]] and metric-based methods [[08_Anisotropic_Metric_Adaptation]].

---

## 1. Why ML for Mesh Generation?

Three motivations:

- **Implicit cost-function learning**: ZZ recovery and DWR estimate error indirectly; an ML model can learn the **mesh-to-error map** directly from labeled data ($\mathcal{T}, J(u_\mathcal{T})$ pairs from offline solves).
- **Speed**: a trained GNN can predict an optimal sizing field in milliseconds; classical adaptive cycles take minutes per iteration.
- **Generalisation across problem families**: amortise the cost of expensive offline adaptive solves across many similar geometries (parametric design exploration).

Risks:
- **Out-of-distribution failure** — a network trained on smooth blunt bodies will not generalise to sharp re-entrant corners.
- **No correctness guarantees** — classical adaptation provably converges; ML does not.
- **Training data scarcity** — for high-end CFD/FEA, even running enough training cases is expensive.

State of art (2025): ML is most useful as a **fast initialiser** for classical iterative remeshing; pure ML mesh generation remains research.

---

## 2. Learned Sizing Fields

### 2.1 MeshingNet (Zhang–Wang 2020)

```text
input  : 2-D B-rep + boundary conditions
output : pixel-wise sizing field h(x,y) on a Cartesian grid
network: U-Net (convolutional encoder-decoder)
training: pairs (geometry, ground-truth-adaptive-mesh-size-field) from
          offline DWR-adaptive solves on synthetic L-shape / T-shape /
          plate-with-hole geometries.
result : downstream Gmsh / Triangle uses h(x,y) → 3-5× fewer cells than
         uniform meshing at same accuracy.
```

Extensions:
- **MeshingNet3D** (2021): voxel-grid 3-D extension via 3-D CNN.
- **PINN-Mesher** (Pereira 2022): physics-informed loss combining a-posteriori indicator and the sizing-field gradient.

### 2.2 GNN-based sizing (Bohn 2024)

For unstructured input meshes (CAD without natural pixelisation), use a Graph Neural Network with message-passing on the input surface triangulation:

```text
node features : position, normal, curvature, boundary-condition encoding
edge features : length, dihedral angle
message-passing layers: 4–8 (Battaglia interaction networks)
output: per-vertex log-h
loss  : MSE vs ground-truth log-h from DWR-adaptive solve
```

Pros vs CNN: handles arbitrary topology, no rasterisation; ~10× more parameter-efficient.

---

## 3. End-to-End Neural Mesh Generation

### 3.1 PolyGen (Nash 2020)

Transformer-based autoregressive generation of (vertex, face) sequences for 3-D meshes — produces visually plausible meshes but **no FEM quality control**. Research-grade for graphics, not engineering.

### 3.2 DeepMesh (Hanocka 2020)

Differentiable mesh CNN; mesh editing via end-to-end gradient. Used for mesh denoising / repair but not from-scratch generation.

### 3.3 Mesh-graphnets-style autoregressive remeshing (Pfaff 2020)

Within a time-stepping simulation:

```text
at each time step:
  predict mesh size field from current state (GNN)
  remesh the elements that need refining/coarsening (classical operators)
  resume solve on new mesh
```

This treats the mesh as a **learnable simulation state**, useful for moving-front problems (level sets, multiphase flow).

---

## 4. MeshGraphNets — Learned PDE Solving on Meshes (Pfaff et al., ICLR 2021)

The seminal paper. MeshGraphNets train a GNN to predict the time-evolution $u^{(t+1)} - u^{(t)}$ on a mesh, given the local mesh + solution state. The network learns:

- Local physics (the PDE operator).
- Boundary conditions (encoded into node features).
- Mesh non-uniformity (edge features include $h_e$).

Demonstrated on:
- Compressible Navier–Stokes (cylinder flow, airfoils).
- Cloth simulation.
- Granular materials.

**Speedup**: 10–1000× over classical solver for the same accuracy, *after training*.

Subsequent work:
- **Mesh-based GNN with adaptive remeshing** (Pfaff 2020 §4): train the GNN to predict edge-split / collapse decisions jointly with the time step.
- **GINO** (Li 2023): geometric interaction operator for irregular meshes.
- **GAOT** (Bohn 2024): generalises MeshGraphNets to multi-scale meshes via hierarchical message passing.

---

## 5. Industrial / Commercial Deployment Status (2024–2025)

| System | ML role | Status |
|---|---|---|
| **ANSYS Discovery Live** | learned local mesh-size predictor | shipping since 2023R2 (Workflow Acceleration) |
| **NVIDIA Modulus** | PINN + GNN with adaptive meshing | research toolkit (open source) |
| **SimScale** | learned BC-driven sizing initialiser | beta, 2024 |
| **Hexagon / MSC Apex** | learned hex-meshing aid | demo only as of 2024 |
| **COMSOL 6.3** | none in production | research collaboration with KTH on GNN-sizing |

The pattern: **ML accelerates known workflows**, classical algorithms still produce final-quality meshes.

---

## 6. Hybrid Recipes — Where ML Pays Off Today

### 6.1 ML-initialised adaptive solve

```text
1. Train an offline GNN sizing predictor on N pre-solved similar problems.
2. For a new problem:
     a. Predict h(x) via the GNN.
     b. Generate initial mesh from h(x) using MMG3D / Gmsh.
     c. Run a small number (2–3) of classical adaptive cycles
        ([[11_Adaptive_Refinement_hp_and_DWR]]) to converge.
3. Net effect: 2× fewer adaptive iterations than starting from a uniform mesh.
```

Realistic for parametric design exploration (1000s of similar geometries).

### 6.2 Neural surrogate for the dual problem in DWR

DWR requires solving an auxiliary problem each iteration. A GNN trained on (primal-residual, dual-solution) pairs can predict $z$ in milliseconds, avoiding the second solve.

### 6.3 ML feature detection for surface meshing

Replace heuristic dihedral-angle thresholds for sharp-feature detection ([[03_Surface_Meshing_Curved_Manifolds]] §5) with a learned classifier — robust on noisy STL.

Open-source: **PIE-Net** (Wang 2020) for sharp-edge detection; **SED-Net** (Liu 2023) for end-to-end CAD primitive extraction.

---

## 7. Cautions and Failure Modes

> [!warning] When ML mesh generation fails
> - **Out-of-distribution geometry** (e.g. trained on smooth blobs, tested on a re-entrant L-shape).
> - **PDE family mismatch** (sizing model trained on elasticity, used for compressible CFD).
> - **Sharp parameter changes** (Reynolds, Poisson ratio crossing incompressible limit).
> - **Bad input topology** that the GNN's normalisation cannot handle.
>
> In all cases the output mesh may be **silently wrong** — the GNN does not signal failure. Always validate the final mesh against a classical quality estimator ([[02_Mesh_Quality_Metrics]]) and the converged solve against an a-posteriori residual ([[11_Adaptive_Refinement_hp_and_DWR]]).

---

## 8. The Honest Bottom Line for 2025

- **For real-world FEA / CFD work today**, classical algorithms (MMG, fTetWild, Mosaic, DWR-based adaptation) remain the production tools. ML is a *speed-up* not a replacement.
- **For parametric design exploration with many similar geometries**, ML-initialised meshing can be a force multiplier (2–10× speedup on the meshing phase).
- **For end-to-end neural mesh generation**, research is active but not yet trustable for engineering deliverables.
- The most promising path is **differentiable remeshing** integrated with PDE-constrained design optimisation (Pfaff 2024, ongoing).

---

## 9. References

- T. Pfaff, M. Fortunato, A. Sanchez-Gonzalez, P. W. Battaglia, "Learning mesh-based simulation with graph networks," *ICLR* 2021.
- Z. Zhang, Y. Wang, P. K. Jimack, H. Wang, "MeshingNet: a new mesh generation method based on deep learning," *Int. Conf. Comput. Sci.* 2020.
- C. Bohn, B. Riepl, S. Klus, "Graph-neural-network-based size field prediction for finite-element meshing," *CMAME* 421, 2024.
- C. Nash, Y. Ganin, S. M. A. Eslami, P. W. Battaglia, "PolyGen: an autoregressive generative model of 3D meshes," *ICML* 2020.
- R. Hanocka, A. Hertz, N. Fish, R. Giryes, S. Fleishman, D. Cohen-Or, "MeshCNN: a network with an edge," *ACM TOG (SIGGRAPH)* 38, 2019.
- X. Wang, B. Xu, K. Mu, "PIE-Net: parametric inference of point cloud edges," *NeurIPS* 2020.
- ANSYS, "Discovery AI Acceleration," *Release Notes* 2023R2.
- NVIDIA, "Modulus: a framework for physics-ML," documentation, 2024.
- Annotated list in [[15_References_Bibliography]].
