# Session Lessons - TODO_03 Geometric Fidelity (Hausdorff + Normal Deviation)

## Date
2026-05-18 → 2026-05-19

---

## 1. Implementation Summary

TODO_03 adds Hausdorff distance and normal-deviation metrics comparing the vol-mesh boundary against the original input surface.

### Files changed
- `include/MeshQuality.h` — added `RefSurface`, `FidelityReport` structs; `computeFidelity()` and `emitFidelityReport()` declarations.
- `src/MeshQuality.cpp` — added `AABB3d`, `closestPointOnTri`, `TriBVH` (in anonymous namespace); `computeFidelity()` and `emitFidelityReport()` implementations.
- `include/FEAModel.h` — added `#include "MeshQuality.h"` and `MeshQuality::RefSurface refSurfaceForFidelity` member.
- `src/FEAModel.cpp` — snapshot surface before TetGen; emit fidelity after `emitReport`; clear on geometry reload.
- `src/STLLoader.cpp` — complete rewrite: added ASCII STL detection and parser; factored shared `Welder` struct.
- `include/STLLoader.h` — updated comment to reflect ASCII support.
- `assets/test_fixtures/sphere_r1.stl` — new: unit sphere, 1012 triangles (nLat=23, nLon=23 UV sphere), ASCII format.
- `regression/sphere_hausdorff.txt` — placeholder sentinel (values to be filled after first run).
- `CMakeLists.txt` — added copy rule for `assets/test_fixtures/*.stl`.

---

## 2. Algorithm Decisions

### BVH (TriBVH)
- Median-split binary BVH over triangles. Leaf size ≤ 4.
- `nodes.reserve(2 * nTris)` before recursion guarantees no reallocation during `buildNode`.
- After recursive `buildNode` calls, nodes are re-accessed by index (not by reference) to avoid stale-reference UB on vector reallocations.
- Read-only during `nearest()` calls → safe for OpenMP parallel query loops.

### Closest point on triangle
- Ericson "Real-Time Collision Detection" §5.1.5 algorithm — handles all Voronoi regions correctly.
- Returns `triIdx` of nearest triangle (used for face-normal lookup in forward pass).

### Hausdorff (symmetric)
- Forward: vol boundary → ref surface (4 quadrature points per vol face).
- Reverse: ref surface → vol boundary (4 quadrature points per ref face).
- Symmetric Hausdorff = max(fwd_max, rev_max).
- p95 computed from combined fwd + rev sample distances.

### Normal deviation — FINAL DESIGN (after 3 bugs)
- Computed in the forward pass only.
- Uses **per-triangle face normal** of the nearest reference triangle, NOT interpolated vertex normals.
- `δ_n = arccos(|dot(n_vol_face, n_ref_tri)|)` — `abs()` makes it convention-agnostic.
- Vol face normal: `cross(vb-va, vc-va)`, same convention as TetGen's surface normals.
- Ref normals: unit-length face normal of the BVH-nearest reference triangle.

### Pass criterion
- Hausdorff (symmetric) < 1% of vol-mesh bbox diagonal AND normal p95 < 15°.

---

## 3. Three Bugs Found and Fixed

### Bug 1 — Normal deviation always ~180°
**Symptom**: `normal deviation: p50=179.3 deg, p95=180.0 deg, max=180.0 deg`
**Root cause**: TetGen's `trifacelist` surface normals point **inward** (opposite to the input PLCs' outward convention). `acos(cosT)` with cosT ≈ -1 gives ≈ 180°.
**Fix**: `std::acos(std::abs(cosT))` — measures plane-plane angle, handles either convention.
**Lesson**: Never assume TetGen surface output normals match input PLC winding. Always use `abs()` when comparing normals from two different pipelines unless you have verified they share a convention.

### Bug 2 — ASCII STL files not loaded
**Symptom**: `STLLoader: file size does not match triangle count; possibly ASCII STL (not supported) or corrupted.`
Affected: sphere_r1.stl (generated), all OnShape exports (OnShape always exports ASCII STL).
**Root cause**: STLLoader only handled binary STL. Binary-format detection read N from bytes 80–84 and validated `fileSize == 84 + N×50`; when this failed for an ASCII file it bailed.
**Fix**: Full ASCII detection + parser.
- Detection: first 5 bytes == `"solid"` AND `fileSize != 84 + N×50` → ASCII.
- Parser: `stream >> token` tokenizer, collects every `"vertex"` line, groups by 3 → triangle.
- Shared `Welder` struct handles vertex welding for both paths.
**MSVC note**: MSVC rejects lambdas that capture-by-reference inside a local struct's method when the lambda outlives the frame. Use a named struct (`Welder`) instead of a lambda-capturing pattern.
**Lesson**: Always check whether the format you're adding has both binary and text variants. STL, OBJ, PLY all have two variants. OnShape specifically exports ASCII STL — this will be hit by any user who uses OnShape.

### Bug 3 — Box/cube fidelity FAIL despite zero Hausdorff error
**Symptom**: `normal deviation: p50=32.1 deg, p95=55.2 deg, p99=63.3 deg, max=68.5 deg. Verdict: FAIL`
Hausdorff was effectively zero (7e-16). Geometry was correct; only the normal check failed.
**Root cause**: Vertex normals at sharp corners of cubes are **area-weighted averages across orthogonal faces**. At a cube corner where face normals are (1,0,0), (0,1,0), (0,0,-1), the averaged vertex normal is ≈ (1,1,-1)/√3, which is ~54.7° from any of the actual face normals. Interpolating this averaged normal at the closest point and comparing to the vol face normal gives 50–68° deviations everywhere near corners — a systematic false failure.
**Fix**: Replace vertex-normal interpolation with **per-triangle face normals** of the reference surface. `refTriNrm[r.triIdx]` is computed once per ref triangle before the BVH query loop; the nearest-triangle index `r.triIdx` returned by the BVH is used directly.
**Lesson for future**: Vertex-normal interpolation is correct only for smooth (C1) surfaces. For piecewise-linear (PLC) surfaces like STL meshes — especially those with sharp features — the face normal of the nearest triangle is the correct answer. Never use interpolated vertex normals for fidelity checks on CAD geometry.

---

## 4. Care Points

- **RefSurface snapshot timing**: must be taken BEFORE TetGen call. Taking it after defeats the purpose (TetGen optimisation can move boundary verts).
- **Normal orientation**: TetGen's `trifacelist` uses inward-facing normals when `-p` is used. `abs()` in the cosine handles this. If p95 ≈ 180°, `abs()` is missing — not a geometry bug.
- **Symmetric Hausdorff vs one-sided**: only computing vol→ref misses ref regions not covered by the vol mesh boundary. Both directions are required.
- **TriBVH lifetime**: `positions` and `triIndices` are raw pointers inside the BVH. Caller must keep the source vectors alive while `nearest()` is in use.
- **Cube corner vertex normals ≠ face normals**: this is mathematically unavoidable for averaged normals at C0 (non-smooth) vertices. Do not try to "fix" the vertex normals; switch to face normals.

---

## 5. Structural / Workflow Lessons

- **Debug order for a new metric that returns extreme values**: first check sign conventions (Bug 1), then check data format (Bug 2), then check the mathematical model's assumptions (Bug 3). This order saved re-reading code unnecessarily.
- **When a geometry-correct model fails a metric**: compute Hausdorff and normal deviation separately in logs. If Hausdorff ≈ 0 but normals fail, the math model is wrong, not the geometry.
- **MSVC lambda restrictions**: avoid lambdas that capture references to local variables inside local struct methods. Refactor to a named class/struct if the pattern is needed.
- **STL format assumption**: the STL spec allows both ASCII and binary. Production CAD exporters (OnShape, Fusion 360) commonly emit ASCII. Always support both.

---

*Author: Claude Sonnet 4.6 — 2026-05-18/19*
