---
title: Frontal-Delaunay and Advancing Front
type: algorithm
tags: [advancing-front, frontal-delaunay, gmsh, bamg, boundary-layer]
created: 2026-05-16
---

# 05 — Frontal-Delaunay and Advancing Front

The **advancing front method** (AFM) and its modern hybrid the **frontal-Delaunay** are the second pillar of automated meshing alongside the pure Delaunay family ([[04_Delaunay_CDT_and_TetGen]]). They excel at:

- **Boundary-layer / extrusion meshing** for CFD walls.
- **High element quality at the boundary** (the first layer is "perfect" by construction).
- **Anisotropic CFD meshes** where elements must align with prescribed directions.

Gmsh's default 2-D mesher is the *frontal-Delaunay* (Rémacle 2013); ANSYS Fluent Meshing's `prism` workflow is pure AFM; Pointwise, ICEM CFD, and NASA's *Tetra Star* all use AFM-derived algorithms for boundary layers.

Cross-refs: anisotropic metric foundations in [[01_Mathematical_Foundations]] §4 and [[08_Anisotropic_Metric_Adaptation]]; pure Delaunay in [[04_Delaunay_CDT_and_TetGen]].

---

## 1. Pure Advancing Front (Löhner 1988, Peraire 1987)

The geometric idea: grow the mesh **outward from the boundary**, one element at a time, keeping a list of "active faces" (the front).

```text
input: closed surface mesh (boundary front F0), sizing field h(x), metric M(x)
1. front := F0          // queue of active boundary faces
2. while front not empty:
       pick face f from front (heuristic: shortest first, or PQ on quality)
       compute ideal new point p* at distance h(centroid(f)) along inward normal,
         in the M-metric
       check existence of nearby existing vertex within tolerance lambda*h
           if found, reuse it (front-to-front merge)
       check that the candidate new tet (f, p*) does not intersect existing tets
           if conflict, try alternative p* or skip
       insert (f, p*) as new tet; update front:
           - remove f
           - add new exterior faces of the new tet
3. terminate when front is empty
4. global smoothing pass (Laplacian + topology improvement)
```

### 1.1 Strengths

- **Boundary fidelity** — the first layer of elements is bound to the input surface exactly.
- **Predictable quality** near boundaries — no Steiner points on the surface.
- **Natural anisotropy** — extend the front in a metric-prescribed direction for boundary layers.

### 1.2 Weaknesses

- **Closure failure** — interior front collisions can leave non-mesh-able cavities (no algorithmic guarantee that the front closes).
- **Quality is local** — global mesh quality often worse than Delaunay.
- **Order-dependence** — different front-traversal heuristics yield different meshes.

Modern AFM implementations mitigate (1) by **falling back to Delaunay** when closure fails — see §3.

---

## 2. Boundary-Layer (BL) Extrusion — the Industrial Sweet Spot

AFM's killer application. For CFD walls with $y^+\approx1$ requirements, the first cell height is $\sim 10^{-5}\,L$ while interior cell sizes are $\sim10^{-2}\,L$ — an aspect ratio of $10^3$ that **only structured extrusion can deliver economically**.

### 2.1 Algorithm

```text
input: boundary surface mesh, first-layer height h_1, growth ratio r, n_layers
1. For each surface node x_i, compute inward normal n_i (area-weighted average)
2. For layer k = 1..n_layers:
       layer height h_k = h_1 * r^(k-1)
       For each node x_i: x_i^(k) = x_i^(k-1) + h_k * n_i^(k)
       Smooth n_i^(k) along the layer to remove discontinuities
       Detect collisions (front-front, front-boundary):
           if found: smooth, shrink, or terminate that node's stack early
3. Generate prismatic cells stacking x_i^(k) -> x_i^(k+1)
4. Above the BL, hand off the remaining void to a tet mesher (Delaunay)
```

### 2.2 Collision handling — modern best practice

- **Local node smoothing** — Verma & Suresh 2017 (mesh-distortion-aware advance).
- **Topology change (collapse and merge)** — Pointwise's `T-Rex` algorithm: layer nodes can be **decoupled** from neighbours and merged adaptively.
- **Anisotropic Voronoi BL** — ANSYS Mosaic 2021R1: the boundary layer is *Voronoi prismatic* allowing automatic node-count change between layers (see [[07_Polyhedral_Mosaic_and_Voronoi]] §3).

### 2.3 ICEM / Fluent / NUMECA convention

| Parameter | Meaning |
|---|---|
| `First Aspect Ratio` | $h_1 / \ell_{\text{surf}}$ for first cell |
| `Growth Rate` | $r = h_{k+1}/h_k$, typical 1.1 – 1.3 |
| `Number of Layers` | $n$, typical 10–30 |
| `Last Aspect Ratio` | controls termination criterion |

---

## 3. Frontal-Delaunay (FD) — Rémacle, Geuzaine et al. 2013

The breakthrough that brought AFM's local quality together with Delaunay's global correctness:

```text
input: PSLG or PLC
1. Build initial Delaunay (point-set or constrained) D
2. Initialise front F = boundary edges/faces, priority-queue ordered
3. while F not empty:
       pop face f
       compute ideal Steiner pt p* on the inward normal at distance h(f) in M-metric
       INSERT p* into D using Bowyer-Watson incremental Delaunay
       update F: remove faces no longer on the front, add new front faces of D
4. terminate; smooth (CVT/ODT)
```

The key insight: **the Delaunay structure is maintained throughout**, eliminating the AFM closure-failure problem. The result has Delaunay's global empty-circumball property AND AFM's neat boundary layers.

### 3.1 Default in Gmsh

Activated via `Mesh.Algorithm = 6` (2-D) and `Mesh.Algorithm3D = 10` (3-D HXT, which is FD-based, 2020). On a typical mechanical part, Gmsh's FD produces meshes with $\theta_{\min}\ge20°$ where the pure Delaunay version produces $\theta_{\min}\approx5°$.

### 3.2 HXT — Hybrid eXact Tetrahedralization (Marot 2019)

Modern Gmsh 4.x uses **HXT**: an open-source, parallel, frontal-Delaunay 3-D mesher reaching $>15\,M$ tets/s on 16 cores while preserving Delaunay quality. Notable features:

- **Lock-free parallel Bowyer-Watson** with conflict graph colouring.
- **Quality-driven Steiner placement** (off-centres à la Üngör).
- **Built-in metric support** for anisotropic CFD.

HXT is the highest-throughput open-source 3-D mesher as of 2024.

---

## 4. Anisotropic 2-D AFM — BAMG (Hecht 2006)

The reference anisotropic 2-D Frontal-Delaunay mesher, maintained as the metric front-end to MMG2D and used inside FreeFEM++. Algorithm:

```text
input: PSLG, metric field M(u) (continuous 2x2 SPD tensors)
1. Sample M at all PSLG vertices
2. Initialise CDT
3. Mesh in M-space using Frontal-Delaunay with M-length = 1 as target edge length
       - Steiner placement and quality measure both use M
       - off-centre insertion à la Üngör
4. Loop: re-compute M from solution (if adaptive cycle), remesh
```

### 4.1 Metric-aware quality

The 2-D anisotropic shape measure used inside BAMG:

$$
q_M(T) = \frac{|T|_M}{\bigl(\sum_{e\in\partial T} \ell_M(e)^2 / 3\bigr)},
$$

with the equilateral $M$-triangle scoring 1. Refinement stops when $q_M\ge0.7$ for $\ge95\%$ of elements.

---

## 5. Frontal-Delaunay Variants by Vendor

| Tool | Algorithm | Notes |
|---|---|---|
| **Gmsh 4.x** | Frontal-Delaunay + HXT 3-D | open-source, fastest |
| **NetGen 6.x** | Pure AFM with Delaunay fallback | quality-focused, slower |
| **ANSYS Fluent Meshing** | Tri/quad AFM + tet/poly conversion | industrial scale |
| **Pointwise T-Rex** | Anisotropic AFM with adaptive layer collapse | aerospace standard |
| **ICEM CFD** | AFM + octree hybrid | legacy but still used |
| **NUMECA Hexpress** | Hex AFM with cut-cell | external aero |
| **MMG2/3 + BAMG** | Anisotropic FD remesher | adaptive FEA |
| **OpenFOAM `snappyHexMesh`** | Hex-dominant with castellated AFM | open-source CFD |

---

## 6. When to Use AFM / Frontal-Delaunay

| Scenario | Verdict |
|---|---|
| Boundary-layer dominated CFD | **YES** — AFM is essentially required |
| Clean B-rep, structural FEA | **YES** — frontal-Delaunay (Gmsh) gives best quality |
| Anisotropic remeshing | **YES** — BAMG / MMG-driven FD |
| Implicit geometry | NO — use [[06_Octree_BCC_and_Isosurface_Stuffing]] |
| Dirty / non-manifold input | NO — use [[09_Robust_TetWild_for_Dirty_Geometry]] |
| Surface-only mesh on curved manifold | use parametric FD or RCVT — see [[03_Surface_Meshing_Curved_Manifolds]] |

---

## 7. Pseudocode — End-to-End BL + FD Hybrid

```text
input: closed surface S, BL params (h_1, r, n), interior sizing h(x)
1. Surface mesh S0 of S (curvature-driven, frontal-Delaunay 2-D)
2. Boundary-layer extrusion:
       prismatic stack of n layers above S0
       resolve self-intersections via T-Rex collapse / Mosaic BL
3. BL outer surface S_bl becomes the new boundary front
4. Frontal-Delaunay 3-D (HXT-style) fills the void above S_bl with tets
5. Local mesh transition: tet-to-prism connections via wedge or pyramid elements
   (or convert to all-tet via diagonal split)
6. Global optimisation: ODT smoothing + sliver elimination
7. Diagnostic pass: report y+, layer growth, mesh quality histograms
```

---

## 8. References

- R. Löhner, "Generation of three-dimensional unstructured grids by the advancing-front method," *AIAA-88-0515*, 1988.
- J. Peraire, M. Vahdati, K. Morgan, O. C. Zienkiewicz, "Adaptive remeshing for compressible flow computations," *J. Comput. Phys.* 72, 1987.
- J. F. Rémacle, J. Lambrechts, C. Geuzaine, "A frontal Delaunay quad mesh generator using the L∞ norm," *IMR* 2013.
- F. Hecht, "BAMG: bidimensional anisotropic mesh generator," INRIA technical report, 1998 (rev. 2006).
- C. Marot, J. Pellerin, J.-F. Rémacle, "One machine, one minute, three billion tetrahedra," *IJNME* 117, 2019.
- C. Geuzaine, J.-F. Rémacle, "Gmsh: A 3-D finite element mesh generator with built-in pre- and post-processing facilities," *IJNME* 79(11), 2009.
- ANSYS Fluent Meshing 2024 R2 User's Guide §"Prism Mesh Generation".
- Pointwise *T-Rex Anisotropic Tetrahedral Extrusion* documentation, v18.6, 2024.
