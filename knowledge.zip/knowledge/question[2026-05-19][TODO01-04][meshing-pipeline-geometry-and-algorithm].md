# How the Meshing Pipeline Works — Geometry and Algorithm

**Date:** 2026-05-19
**Tasks:** TODO_01 through TODO_04
**Topic:** Complete meshing pipeline — what happens geometrically and algorithmically at every step, from file load to tet mesh

## Related Theory

| Theory file | What it contributes to this Q&A |
|---|---|
| [01 Mathematical Foundations](theoritical/01_Mathematical_Foundations.md) | §1 Simplicial complexes — defines what a "piecewise linear complex (PLC)" is and why hanging nodes break conformity; §2 Voronoi/Delaunay duality and the empty-sphere property — the mathematical guarantee behind every Delaunay step TetGen takes; §5 CVT energy — the energy that meshopt_simplify's edge-collapse minimises implicitly |
| [04 Delaunay CDT and TetGen](theoritical/04_Delaunay_CDT_and_TetGen.md) | Stage 3 in full — Bowyer–Watson incremental construction, Ruppert–Shewchuk refinement, Steiner point insertion, CDT(3), the meaning of the `-pq`/`-a`/`-O` switches, and why STEP input causes more refinement iterations than STL |
| [02 Mesh Quality Metrics](theoritical/02_Mesh_Quality_Metrics.md) | Radius-edge ratio, dihedral angle, and normalized volume — the three quality measures used in TetGen's quality constraints and in PolyFEA's sliver flagging (§8 of theory.md) |
| [12 Mesh Smoothing CVT and ODT](theoritical/12_Mesh_Smoothing_CVT_and_ODT.md) | Edge-collapse topology operators underlying `meshopt_simplify` decimation (Stage 2.1); Laplacian and ODT smoothing that TetGen's `-O` flag runs at the end of Stage 3 |
| [09 Robust TetWild for Dirty Geometry](theoritical/09_Robust_TetWild_for_Dirty_Geometry.md) | Why dirty STL (self-intersections, gaps) causes TetGen to fail — the "Common Misconceptions" section implicitly refers to cases where fTetWild would be used instead |
| [11 Adaptive Refinement hp and DWR](theoritical/11_Adaptive_Refinement_hp_and_DWR.md) | Stage 3.6 Tet4→Tet10 promotion is §5 "linear p-refinement"; §2 ZZ error estimator is the theoretical basis for Stage 4's Hausdorff fidelity check as a precursor to full adaptive cycles |
| [16 PolyFEA Implementation Guide](theoritical/16_PolyFEA_Implementation_Guide.md) | Direct code references for every stage — `processRawGeometry`, `generateVolumetricMesh`, `generateMidEdgeNodes`, `computeFidelity` — and the quick-win roadmap that extends this pipeline |

---

## The Big Picture

The pipeline has four major stages. Each stage has a clear job and clear inputs/outputs.

```
  FILE ON DISK
       │
       ▼
  [Stage 1]  LOAD — read file, extract triangles
       │
       ▼
  [Stage 2]  PROCESS — clean, normalise, compute normals → surface mesh
       │
       ▼
  [Stage 3]  VOLUME MESH — fill the interior with tetrahedra (TetGen)
       │
       ▼
  [Stage 4]  QUALITY CHECK — measure how accurately the tet mesh
                              represents the original geometry
```

Each stage is described below with both the geometry (what shape is being worked on) and the algorithm (what the code actually does).

---

## Stage 1 — Load: Extract a Triangle Mesh from the File

### What we need at the end of this stage

A list of **vertices** (points in 3D space) and a list of **triangles** (each triangle is three indices pointing into the vertex list). Together these describe the outer surface of the object.

### Why a triangle surface? Why not just the solid?

Computers represent solids as hollow shells. The shell is a closed triangle mesh — every triangle is a face of the outer skin. If the shell has no holes, the inside is implied. This is called a "watertight" or "manifold" mesh.

### What each format provides

**STL** stores the triangles directly as a flat list. Each triangle has three corner positions and a face normal. Vertices are not shared — the same corner appears once in every triangle that uses it. The loader welds coincident vertices (vertices at the same position) into shared vertices so the mesh is connected.

**3MF** is a ZIP archive containing XML. The XML has an explicit vertex list and an explicit index list. Vertices are already shared. The loader decompresses the archive and parses the XML.

**STEP (via OCCT)** stores analytic geometry — exact equations, not triangles. The loader:
1. Parses the STEP text and rebuilds planes, cylinders, spheres, NURBS surfaces in memory
2. Repairs tolerance errors with `ShapeFix_Shape`
3. Tessellates (converts to triangles) using `BRepMesh_IncrementalMesh` at a user-controlled chord-error setting
4. Harvests the triangles and keeps the analytic B-rep alive for later fidelity queries

All three formats produce the same output type: `LoadedGeometry` — a welded vertex list and a triangle index list. Everything downstream is format-agnostic.

---

## Stage 2 — Process: Clean and Prepare the Surface Mesh

### `processRawGeometry()` — the shared pipeline

Every format's geometry passes through this function. It has seven steps.

---

### Step 2.1 — Optional Decimation (if "Vertex Smoothing" is ON)

**What problem this solves:**
High-resolution files (especially STEP with fine chord-error) can have tens of thousands of triangles. More triangles = more constraints for TetGen = exponentially longer meshing time. Decimation reduces triangle count while staying within a geometric error budget.

**Geometry:**
Decimation collapses edges. When an edge is collapsed, its two endpoint vertices merge into one, and the triangles that used those vertices either become smaller or disappear entirely. The surface "simplifies" — small details are smoothed away. The algorithm prioritises collapsing edges where the resulting surface deviation is smallest.

**Algorithm:**
`meshopt_simplify` (meshoptimizer library):
- Target: reduce to 70% of the original triangle count (`indices.size() * 7/10`)
- Maximum allowed geometric error: 5% of the bounding box (`target_error = 5e-2`)
- Border lock: edges on the boundary of the mesh are never collapsed (preserving the outline shape)
- After simplification, degenerate triangles are removed — these are triangles where two indices are equal, or where the three corners are collinear (cross product ≈ 0, meaning zero area)
- Orphaned vertices (vertices no longer referenced by any triangle after decimation) are compacted out

**Why border lock matters:**
Without locking borders, the decimation could collapse the rim of a hole or the sharp edge of a flange, changing the topology of the model. Locking prevents this. The result is a reduced mesh that has the same silhouette as the original.

**What it doesn't do:**
Decimation changes the surface shape within the allowed error budget. It does not change the topology (number of holes, handles). It does not make the mesh watertight if it wasn't already.

---

### Step 2.2 — Per-Vertex Normal Recomputation

**What problem this solves:**
For smooth shading on screen, each vertex needs a normal vector (an arrow pointing outward from the surface). Raw normals from STL are per-face (every vertex of a triangle gets the same normal). This produces faceted, "flat shading" appearance. Smooth normals are computed by blending the normals of all triangles that share each vertex.

**Geometry:**
A face normal is the vector perpendicular to a triangle. It is computed as the cross product of two edges:

```
face_normal = (B − A) × (C − A)
```

This vector is perpendicular to the triangle's plane and its magnitude equals twice the triangle's area. Accumulating the un-normalised face normals at each vertex and then normalising produces an **area-weighted average normal**. Larger triangles have more influence than small ones, which is geometrically correct — a large flat region should dominate a small neighbouring wedge.

**Algorithm:**
OpenMP parallel reduction:
- Each thread gets a private copy of the normal accumulator array
- Each thread processes a subset of triangles, accumulating face normals to its private array
- A `#pragma omp critical` section merges all private arrays into the shared result
- Each accumulated normal is normalised by dividing by its length (`glm::length`)
- Degenerate vertices (zero normal) get an arbitrary fallback (0, 1, 0)

**Why parallelise:**
A high-resolution mesh can have hundreds of thousands of triangles. The accumulation loop is the bottleneck. Each thread operating on its own private array avoids lock contention — the only synchronisation is the single merge at the end.

---

### Step 2.3 — AABB Centering and Uniform Scale

**What problem this solves:**
Files arrive in arbitrary coordinates. A STEP file from a mechanical design may use millimetres, so a 100mm part arrives at coordinates like (0, 0, 0) to (100, 50, 30). A scan of a building may span thousands of metres. TetGen's robustness tolerance and the display camera are both calibrated for a scene of roughly unit scale. Normalisation makes everything well-conditioned.

**Geometry:**
An axis-aligned bounding box (AABB) is the smallest box, aligned with the X/Y/Z axes, that contains all vertices. Its six faces are at the minimum and maximum X, Y, Z values across all vertices.

**Algorithm:**
1. Find `minAABB` and `maxAABB` by iterating all vertices
2. Compute `center = (minAABB + maxAABB) / 2`
3. Compute `maxDim = max(width, height, depth)` of the bounding box
4. Compute `scale = 3.0 / maxDim` — this maps the longest axis to 3 units
5. Apply to every vertex: `position = (position − center) × scale`

The result: the model is centred at the world origin and its longest axis spans ±1.5 units.

**What this affects and what it doesn't:**
- All vertex positions change — the model is in a different coordinate system
- Triangle connectivity (indices) does not change
- Triangle shapes change proportionally — no distortion (uniform scale)
- The computed `bboxVolume` (used later as the TetGen volume reference) is also scaled accordingly

---

### Step 2.4 — Store Surface Mesh, Reset FEA State, Upload to GPU

The cleaned, centred, normal-equipped vertex list and index list are saved as `surfaceVertices` and `surfaceIndices`. All previous volumetric mesh data and FEA results are cleared. The mesh is uploaded to the GPU via `buildBuffers()` and is now visible on screen as the grey surface with wireframe overlay.

---

## Stage 3 — Volume Mesh: Fill the Interior with Tetrahedra (TetGen)

### Why tetrahedra?

A tetrahedron (4 triangular faces, 4 vertices, 6 edges) is the simplest 3D solid. For FEA, the entire volume of the object must be divided into elements — sub-regions where the physics equations are solved. Tetrahedra can fill any arbitrarily shaped volume, they have well-understood mathematical properties for stiffness matrix computation, and they can be graded in size (small near curved boundaries, large in flat interiors).

### The constrained Delaunay tetrahedralization

TetGen uses a **constrained Delaunay tetrahedralization (CDT)** algorithm, authored by Hang Si. Here is what that means, step by step.

---

### Step 3.1 — Pack the Input: a Piecewise Linear Complex (PLC)

**What TetGen receives:**
- A list of all surface vertices (positions)
- A list of constrained facets — each facet is a surface triangle that must appear as a face of some tetrahedron in the output. No tet boundary is allowed to cut through a surface triangle.

**Why "constrained":**
Without constraints, Delaunay tetrahedralization would just tetrahedralise the convex hull of the points. The surface triangles as constraints force TetGen to respect the actual shape of the object, including concavities, holes, and thin features.

**Code:**
```cpp
in.numberofpoints = surfaceVertices.size();
// ... fill in.pointlist with x,y,z of each vertex
in.numberoffacets = surfaceIndices.size() / 3;
// ... fill in.facetlist: each facet is one triangle
```

---

### Step 3.2 — The TetGen Switch String

```
pq<radius-edge>/<min-dihedral>a<maxVol>AO<level>T<tol>
```

Each letter controls one aspect of the meshing:

| Switch | Meaning | Geometry |
|--------|---------|----------|
| `p` | PLC mode | Treat input as a closed solid boundary with constrained faces |
| `q<r>/<d>` | Quality | Insert Steiner points until every tet has radius-edge ratio ≤ r and minimum dihedral angle ≥ d° |
| `a<vol>` | Volume cap | No single tet may be larger than `bboxVolume × maxVolPercent / 100` |
| `A` | Region attributes | Label interior regions (unused without explicit region seeds) |
| `O<n>` | Optimisation level | After Delaunay refinement, run n passes of quality improvement (flips, Laplacian smoothing) |
| `T<tol>` | Robustness tolerance | Floating-point predicate tolerance for Shewchuk's exact arithmetic |

**What "radius-edge ratio" means geometrically:**
Every tetrahedron has a circumsphere — the unique sphere that passes through all 4 of its vertices. The radius-edge ratio is `circumsphere radius / shortest edge length`. A regular tetrahedron (all faces equilateral) has ratio ≈ 0.612. A flat, needle-like tet has a very large ratio (small shortest edge, huge circumsphere). The quality bound `q<r>` prevents degenerate tets from appearing. Default: 1.4 (user-adjustable via the UI slider "Mesh Quality p").

**What "minimum dihedral angle" means geometrically:**
A dihedral angle is the angle between two faces of the tetrahedron along a shared edge. A well-shaped tet has all dihedral angles between roughly 20° and 140°. Very small dihedral angles (nearly flat tets) cause ill-conditioned stiffness matrices in FEA, leading to inaccurate stress results. The `/<d>` bound rejects tets with any dihedral angle below d°.

---

### Step 3.3 — Delaunay Tetrahedralization

**The Delaunay property** (in 3D): a tetrahedralization is Delaunay if, for every tetrahedron, no other vertex in the mesh lies inside its circumsphere.

**Why Delaunay produces good tets:**
The Delaunay property maximises the minimum solid angle across all tetrahedra. Equivalently, it avoids long, flat, needle-like tetrahedra as much as possible given the current set of points. This is a mathematical optimality result — there is no other triangulation of the same points that has a better minimum solid angle.

**What TetGen does:**
1. Start with the convex hull of all surface vertices as a Delaunay tetrahedralization
2. Enforce the constrained facets — this may temporarily violate the Delaunay property, which is why it is a *constrained* CDT
3. Identify the interior region (the "inside" of the solid, determined by the closed surface)
4. Remove all tetrahedra outside the solid

**Steiner points (the refinement part):**
The initial CDT from just the surface vertices almost certainly has poor-quality tetrahedra near curved or fine features. TetGen inserts **Steiner points** — new vertices added to the interior — to fix this. For each tet that violates the quality constraints (radius-edge ratio too high, or dihedral angle too small), TetGen computes the optimal location to insert a new point (typically the circumcentre of the offending tet), inserts it, and re-triangulates. This repeats until all quality constraints are met or the volume constraint stops further refinement.

**This is why STEP files take longer:** OCCT's fine tessellation gives TetGen a denser, more constrained boundary. More constrained boundary triangles → more initial tetrahedra → more refinement iterations needed to reach the quality target.

---

### Step 3.4 — Mesh Optimisation (O level)

After Delaunay refinement converges, TetGen runs additional improvement passes:

- **Edge and face flips:** Swap the shared face between two adjacent tetrahedra if the swap produces better-quality tets. Analogous to edge flips in 2D Delaunay.
- **Laplacian smoothing:** Move each interior vertex to the centroid of its neighbouring vertices. This "relaxes" the mesh — vertices move away from clusters and toward evenly spaced positions. Done iteratively.
- **Combined smoothing + flipping:** alternating both passes until improvement stalls.

These passes do not add or remove vertices — they only change connectivity and positions. The mesh topology (which vertices are connected) changes; the number of tets stays approximately the same.

---

### Step 3.5 — Harvest the Output

TetGen returns:
- `out.pointlist` — all vertices, including the Steiner points it added. This will be more vertices than the input surface had.
- `out.tetrahedronlist` — connectivity: for each tetrahedron, the indices of its 4 vertices (stored as 4 integers per tet)
- `out.trifacelist` — boundary triangles: the outer surface of the tet mesh (for display)

The boundary triangles may differ slightly from the original surface triangles because TetGen may have split some input facets to accommodate Steiner points on the surface.

---

### Step 3.6 — Optional Tet4 → Tet10 Promotion

**Tet4 (linear):** 4 nodes, one at each corner. Displacement within the element is a linear function of position. The strain (derivative of displacement) is constant throughout the element — every point inside a tet has the same stress. This is a coarse approximation; stress concentrations and bending effects are poorly captured.

**Tet10 (quadratic):** 10 nodes — the 4 corner nodes plus 6 mid-edge nodes, one at the midpoint of each edge. Displacement is a quadratic function of position. Strain (and therefore stress) varies linearly within the element. Bending, curvature, and stress gradients are captured much more accurately.

**How promotion works (`generateMidEdgeNodes`):**
For every unique edge in the tet mesh (identified by the canonical pair `(min(a,b), max(a,b))`):
1. Insert a new vertex at the midpoint: `x_m = (x_a + x_b) / 2`
2. Store the new vertex's index in a map keyed by the edge
3. Update each tetrahedron's connectivity from 4 to 10 indices, using the map to look up mid-edge nodes

The mid-edge nodes are straight midpoints — they are not projected onto the analytic B-rep surface. This means the quadratic tet mesh still has straight edges at the boundary. True curved-element meshing (isogeometric analysis) would snap mid-edge nodes to the exact surface — a future enhancement.

**DOF count:** promoting N_linear nodes and E_unique edges gives:
`N_DOF_quadratic = 3 × (N_linear + E_unique)`
Typically 3–4× more degrees of freedom than the linear mesh, but with substantially better accuracy per DOF.

---

## Stage 4 — Quality Check: How Well Does the Tet Mesh Match the Original?

### Two passes: forward and reverse

**Forward pass (vol boundary → input surface):**
For each boundary triangle of the tet mesh, sample a point on it and find the nearest point on the original surface. The distance between these two points is the forward error at that sample.

- Without B-rep: "nearest point on original surface" uses a triangle BVH (bounding volume hierarchy) — fast but only as accurate as the original triangulation.
- With B-rep (STEP): uses `BRepExtrema_DistShapeShape` to query the true analytic surface — exact to floating-point precision.

**Reverse pass (input surface → vol boundary):**
For each triangle on the original surface, find the nearest boundary triangle of the tet mesh. Uses the triangle BVH.

**Hausdorff distance (symmetric):**
```
H = max(max_forward_error, max_reverse_error)
```
This is the worst-case deviation between the two surfaces in either direction. A Hausdorff distance of 1mm means some point on one surface is at least 1mm away from any point on the other surface.

**Normal deviation:**
At each sample, the angle between the tet boundary face normal and the original surface normal. Reported as p50, p95, p99 percentiles and max. High normal deviation indicates the mesh is faceted where the original was smooth — important for stress concentrations.

---

## Summary: Data Flow Table

| Stage | Input | Output | Key algorithm |
|-------|-------|--------|---------------|
| Load | File on disk | `LoadedGeometry` (welded verts + triangle indices) | Format-specific parser / OCCT tessellation |
| Decimate | Triangle mesh | Reduced triangle mesh (70% tris, ≤5% error) | `meshopt_simplify` (edge collapse) |
| Normals | Position + index list | Per-vertex smooth normals | OpenMP parallel cross-product accumulation |
| Normalize | Arbitrary coords | Centred, ±1.5 unit scale | AABB + uniform scale |
| Volume mesh | Surface triangle mesh | Tet mesh (interior + boundary) | Constrained Delaunay refinement (TetGen) |
| Tet10 | Tet4 connectivity | Tet10 connectivity + mid-edge nodes | Edge midpoint insertion |
| Quality | Tet boundary + original surface + optional B-rep | Hausdorff distance, normal deviation report | BVH nearest-point / `BRepExtrema` exact query |

---

## Common Misconceptions Addressed

**"The tet mesh represents the exact geometry."**
No. The tet mesh boundary is a triangulated approximation of the surface. For STL input, it approximates the STL triangles. For STEP input, it approximates OCCT's tessellation, which in turn approximates the analytic surface. The fidelity check measures how far the approximation is from the true geometry.

**"More tets = more accurate FEA."**
Not directly. More tets reduce discretisation error but cost more compute time. The accuracy of each individual tet depends on its shape quality (radius-edge ratio, dihedral angles). A smaller number of well-shaped tets can be more accurate than a larger number of poorly-shaped ones.

**"Decimation makes the FEA less accurate."**
It depends. Decimation reduces geometric fidelity of the surface mesh by up to 5% of the bounding box diagonal. If the mesh is very fine and the 5% error is small relative to the feature you care about, the FEA accuracy loss is negligible and the speed gain is substantial. For fine features (thin walls, small holes), decimation should be turned off.

**"Tet10 is always better than Tet4."**
Tet10 is more accurate per element, but costs 3–4× more DOF and correspondingly more solver time. For coarse geometry or a quick feasibility check, Tet4 is often sufficient. For stress concentrations, bending, and curved surfaces, Tet10 is necessary for reliable results.

**"The quality check result is the error of the FEA solution."**
No. The quality check (Hausdorff distance) measures geometric fidelity — how well the tet mesh boundary represents the input surface. FEA solution error additionally depends on mesh density, element quality, constitutive model, boundary conditions, and solver tolerance. Geometric fidelity is a prerequisite for FEA accuracy, not a guarantee of it.

---

## Code Reference

| Concept | File | Function / line |
|---------|------|----------------|
| Load dispatch | `src/FEAModel.cpp` | `loadFile()` line 226 |
| Shared pipeline | `src/FEAModel.cpp` | `processRawGeometry()` line 251 |
| Decimation | `src/FEAModel.cpp` | lines 263–332 (meshopt_simplify) |
| Normal computation | `src/FEAModel.cpp` | lines 338–362 (OpenMP) |
| AABB normalise | `src/FEAModel.cpp` | lines 382–401 |
| TetGen call | `src/FEAModel.cpp` | `generateVolumetricMesh()` line 537 |
| TetGen switches | `src/FEAModel.cpp` | lines 592–599 |
| Tet10 promotion | `src/FEAModel.cpp` | `generateMidEdgeNodes()` line 722+ |
| Quality check | `src/MeshQuality.cpp` | `computeFidelity()`, `emitFidelityReport()` |
| Exact B-rep query | `src/BRepHandle.cpp` | `nearestPointOnShape()` |

---

## Implementation — Code Location and Data Flow

### Classes and methods involved

| Class / method | File | Role |
|---|---|---|
| `FEAModel::loadFile(filepath)` | [src/FEAModel.cpp:226](../src/FEAModel.cpp) | Extension dispatch → `loadSTL`, `load3MF`, or `loadSTEP` |
| `FEAModel::processRawGeometry(geo, formatTag)` | [src/FEAModel.cpp:251](../src/FEAModel.cpp) | Shared post-load pipeline: decimate → normals → AABB scale → GPU upload |
| `meshopt_simplify(...)` | called at [src/FEAModel.cpp:277](../src/FEAModel.cpp) | Meshoptimizer edge-collapse decimation (Stage 2.1) |
| `FEAModel::generateVolumetricMesh()` | [src/FEAModel.cpp:537](../src/FEAModel.cpp) | Packs `tetgenio in`, calls `tetrahedralize`, harvests `tetgenio out` |
| `tetrahedralize(&b, &in, &out)` | TetGen (src/tetgen.cxx) | CDT(3) + Ruppert refinement + Steiner insertion + `-O7` smoothing |
| `FEAModel::generateMidEdgeNodes()` | [src/FEAModel.cpp:748](../src/FEAModel.cpp) | Tet4 → Tet10: inserts midpoints, builds `tetrahedraQuadratic` |
| `MeshQuality::emitReport(out, params)` | [include/MeshQuality.h:207](../include/MeshQuality.h) | Per-element quality: Knupp shape, dihedral, scaled Jacobian, radius ratio |
| `MeshQuality::emitFidelityReport(ref, out, params)` | [include/MeshQuality.h:181](../include/MeshQuality.h) | Hausdorff + normal-deviation between tet boundary and reference surface |

### Stupid-clerk data flow — Stage by Stage

**Stage 1: Load → `FEAModel::loadFile`** [src/FEAModel.cpp:226]

User drops a file. `loadFile` inspects `filepath` extension:
- `.3mf` → calls `load3MF(filepath)` → `GeometryLoaderDispatch::load(filepath, geo)` → fills `LoadedGeometry geo`
- `.step`/`.stp` → calls `loadSTEP(filepath)` → `StepLoader::loadWithBRep(filepath, geo, newBrep, params)` → fills `LoadedGeometry geo` + `std::unique_ptr<BRepHandle> newBrep`
- anything else → `loadSTL(filepath)` → same dispatch

`LoadedGeometry geo` holds:
- `geo.positions` — `std::vector<glm::vec3>` of welded vertex coordinates
- `geo.indices` — `std::vector<unsigned int>` flat triangle list (3 per triangle)
- `geo.sourceLabel`, `geo.objectCount` — metadata

All three load paths hand `geo` to Desk 2.

---

**Stage 2: `FEAModel::processRawGeometry(geo, formatTag)`** [src/FEAModel.cpp:251]

Receives `geo` and `formatTag` (e.g. `"STEP"`). Works entirely on:
- Local `weldedPos` — copy of `geo.positions`
- `indices` — reference to `geo.indices`

**Step 2.1 — Optional decimation** [line 263] (only if `params.enablePolarRemoval == true`):
- Flattens `weldedPos` into `posFlat` (`std::vector<float>`)
- Target: `indices.size() * 7/10` triangles, max error `5e-2f`
- `meshopt_simplify(new_indices.data(), indices.data(), ..., meshopt_SimplifyLockBorder, &result_error)` → writes reduced index list into `new_indices`
- Degenerate triangles removed; orphaned vertices compacted out of `weldedPos`

**Step 2.2 — OpenMP normals** [line 344]:
- Each thread accumulates face cross-products into private `localNrm` (`std::vector<glm::vec3>`, one per vertex)
- `#pragma omp critical` merges all `localNrm` into shared `weldedNrm`
- Normalised → packed into `Vertex` structs

**Step 2.3 — AABB scale** [line 382]:
- `minAABB`, `maxAABB` found by iterating `vertices`
- `scale = 3.0f / max(width, height, depth)` — fits longest axis to 3 units
- Every `v.position = (v.position - center) * scale`
- `this->bboxVolume = sizeVec.x * sizeVec.y * sizeVec.z * scale³` — scaled bbox volume, used later as TetGen volume cap reference

**Output** [line 406–407]:
- `this->surfaceVertices = vertices` — `std::vector<Vertex>`, every entry has `.position`, `.normal`, `.texCoords`
- `this->surfaceIndices = indices` — `std::vector<unsigned int>`
- All volumetric and FEA state cleared (tetrahedra, deformedPositions, etc.)
- `buildBuffers()` uploads `surfaceVertices`/`surfaceIndices` to GPU via `VAO`/`VBO`/`EBO`

---

**Stage 3: `FEAModel::generateVolumetricMesh()`** [src/FEAModel.cpp:537]

**Pre-snapshot** [line 547–551]:
- Copies `this->surfaceVertices[i].position` → `this->refSurfaceForFidelity.positions` (a `MeshQuality::RefSurface`)
- Copies `this->surfaceIndices` → `this->refSurfaceForFidelity.indices`
- This is the reference surface the fidelity check will measure against

**Pack TetGen input** [line 553–583]:
- `tetgenio in`
- `in.numberofpoints = surfaceVertices.size()`
- `in.pointlist[i*3+0/1/2] = surfaceVertices[i].position.x/y/z` — flat `REAL[]` array
- `in.numberoffacets = surfaceIndices.size() / 3`
- `in.facetlist[i]` — each `tetgenio::facet` gets one `polygon` with `vertexlist[0/1/2]` = three surface indices

**Switch string** [line 592–599]:
```
"pq{tetRadiusEdge}/{tetMinDihedralDeg}a{absoluteMaxVol}AO{tetOptimizeLevel}T{tetRobustnessTol}"
```
All values come from `this->params` (`FEAParams`):
- `params.tetRadiusEdge = 1.2f` — radius-edge bound
- `params.tetMinDihedralDeg = 10.0f` — target minimum dihedral (degrees)
- `absoluteMaxVol = bboxVolume * (params.maxVolPercent / 100.0f)` — per-tet volume cap
- `params.tetOptimizeLevel = 7` — full flip + Laplace smoothing
- `params.tetRobustnessTol = 1e-10` — Shewchuk predicate tolerance

**TetGen run** [line 622–635]:
- `tetrahedralize(&b, &in, &out)` — fills `tetgenio out`
- `out.numberofpoints` — total nodes including Steiner points
- `out.numberoftetrahedra` — tet count
- `out.tetrahedronlist` — flat `int[]`, 4 per tet
- `out.trifacelist` — flat `int[]`, 3 per boundary triangle
- `out.pointlist` — flat `REAL[]`, 3 per node

**Quality report** [line 645]:
- `MeshQuality::emitReport(out, params)` → iterates every tet in `out.tetrahedronlist`, computes `ElemQuality` (Knupp shape, dihedral range, scaled Jacobian, radius ratio, equiangular skew), fills `QualityReport`, prints to `std::cout`

**Fidelity report** [line 648–651]:
- If `this->hasBRep()` → `MeshQuality::emitFidelityReport(refSurfaceForFidelity, *brep, out, params)` (exact path)
- Else → `MeshQuality::emitFidelityReport(refSurfaceForFidelity, out, params)` (BVH path)
- Both fill and print `FidelityReport`: `hausdorffMax`, `hausdorffP95`, `normalDev_*`

**Harvest to FEAModel** [line 670–708]:
- `out.pointlist` → `this->volumetricVertices` (`std::vector<Vertex>`) + `this->originalVolumetricPositions` (`std::vector<glm::vec3>`)
- `out.trifacelist` → `this->volumetricIndices` (`std::vector<unsigned int>`) — boundary triangles for rendering
- `out.tetrahedronlist` → `this->tetrahedra` (`std::vector<unsigned int>`, 4 per tet) — connectivity for FEASolver

---

**Stage 4 (optional): `FEAModel::generateMidEdgeNodes()`** [src/FEAModel.cpp:748]

Reads `this->tetrahedra` (4 × nElems `unsigned int`). For each of the 6 canonical edges per tet (defined by `edgeLocal[6][2]` at line 756):

- Canonical key: `std::pair<unsigned int, unsigned int>(min(a,b), max(a,b))`
- Looks up key in `this->edgeToMidNode` (`std::map<pair<uint,uint>, uint>`)
- **If new edge**: computes `mid = 0.5f * (originalVolumetricPositions[a] + originalVolumetricPositions[b])`, appends to `this->originalVolumetricPositions` and `this->volumetricVertices`, stores new index in `edgeToMidNode[key]`
- **If existing edge**: reuses the index already in `edgeToMidNode`
- Pushes 10 indices per tet into `this->tetrahedraQuadratic` (`std::vector<unsigned int>`, 10 per tet): first 4 corners, then 6 mid-edge indices in the order `[m(0,1), m(1,2), m(0,2), m(0,3), m(1,3), m(2,3)]`

Output:
- `this->tetrahedraQuadratic` — 10 × nElems connectivity for `Tet10Element`
- `this->originalVolumetricPositions` — extended with all mid-edge positions
- `this->hasQuadraticMesh = true`

---

*Author: Claude Sonnet 4.6 — 2026-05-19*
