# TODO_04 — STEP loader as primary input + B-rep retention

> **Sequence note:** This TODO bumps every subsequent planned TODO by +1 (the load gizmo TODOs are already renamed TODO_22..25). Once this lands, STEP becomes the *default* test fixture format and the primary input for every downstream TODO; STL / 3MF stay as the **fallback** path for legacy / scanned / dirty data.

## Goal
Add OpenCASCADE (OCCT) as a dependency, implement a `StepLoader` that reads `.step` / `.stp` files, retains the underlying `TopoDS_Shape` on `FEAModel` for downstream use (exact features, exact curvature, exact projection), tessellates the B-rep to triangles via `BRepMesh_IncrementalMesh`, and feeds the result through the existing `surfaceVertices` / `surfaceIndices` pipeline. As a bonus sub-task, extend TODO_03's Hausdorff / normal-deviation routines to compare against the **exact NURBS surface** when STEP is the source (replacing the snapshotted-triangulation reference).

## Files added / modified
- **Add** `include/StepLoader.h`, `src/StepLoader.cpp` — pImpl-style wrapper so OCC headers stay out of public includes (they're heavy).
- **Add** `include/BRepHandle.h` — opaque forward declaration: `class BRepHandle;` with a `std::unique_ptr<BRepHandle>` field on `FEAModel`. Definition lives in the `.cpp` and holds `TopoDS_Shape` + face/edge maps.
- **Modify** `include/FEAModel.h` — add `std::unique_ptr<BRepHandle> brep`, `bool hasBRep() const`, `std::string lastLoadedFormat` (STL/3MF/STEP).
- **Modify** `src/FEAModel.cpp` — extend `loadFile()` to dispatch `.step` / `.stp` → `StepLoader::load`; `processRawGeometry` populates `brep` when source was STEP.
- **Modify** `src/SimpleUI.cpp` — File-Open default filter starts with `*.step;*.stp`; STL/3MF still supported but lower in the list. Status panel shows `Source: STEP (B-rep retained)` vs `Source: STL (triangulated)`.
- **Modify** `CMakeLists.txt` — add OCCT via `FetchContent` from `https://github.com/Open-Cascade-SAS/OCCT` (pin a tagged release SHA, e.g. `V7_8_1`). Link only the modules we use: `TKSTEP`, `TKMesh`, `TKBRep`, `TKMath`, `TKernel`, `TKTopAlgo`, `TKShHealing`. Behind `-DUSE_OCCT=ON` (default ON; OFF disables STEP loader gracefully — the loader returns false with a helpful message).
- **Modify** `include/MeshQuality.h`, `src/MeshQuality.cpp` — extend `computeHausdorffToSurface` and `computeNormalDeviation` (from TODO_03) to dispatch on `model.hasBRep()`: BRep path uses OCC `ShapeAnalysis_Surface::NearestPoint`; legacy path keeps existing BVH-on-triangulation. **This is the TODO_03 patch promised in the analysis.**
- **Add** `assets/test_fixtures/unit_cube.step`, `sphere_r1.step` — generate programmatically in a one-off helper using OCC primitives (`BRepPrimAPI_MakeBox`, `MakeSphere`) + `STEPControl_Writer`. ~30 LOC helper kept in `tools/gen_step_fixtures.cpp`.

## Algorithm summary

### Load and tessellate
```text
StepLoader::load(path, out_brep, out_vertices, out_indices, params):
    STEPControl_Reader reader
    if reader.ReadFile(path) != IFSelect_RetDone: return false
    reader.TransferRoots()
    shape = reader.OneShape()              // TopoDS_Shape (multiple solids possible)
    healShape(shape)                       // ShapeFix_Shape: sew faces, fix orientation
    out_brep = make_unique<BRepHandle>(shape, faceMap, edgeMap, vertexMap)

    // Tessellation parameters tied to user intent:
    lin_def = params.sizingChordError * L_diag           // linear deflection
    ang_def = 0.3                                        // 17 deg, matches COMSOL default
    BRepMesh_IncrementalMesh mesher(shape, lin_def, false, ang_def, /*parallel=*/true)
    mesher.Perform()

    // Harvest triangles from each face's Poly_Triangulation
    for each TopoDS_Face f in shape (parallel):
        TopLoc_Location loc
        tri = BRep_Tool::Triangulation(f, loc)
        for each node n in tri: append loc.Transformation() * n to out_vertices
        for each triangle (a,b,c): append (a,b,c) to out_indices, with face orientation
    return true
```

### BRepHandle data model
```cpp
class BRepHandle {
    TopoDS_Shape shape;
    TopTools_IndexedMapOfShape faceMap;   // face id -> TopoDS_Face
    TopTools_IndexedMapOfShape edgeMap;   // edge id -> TopoDS_Edge
    TopTools_IndexedMapOfShape vertexMap; // vertex id -> TopoDS_Vertex
    // Per-triangle face-id mapping (populated during tessellation):
    std::vector<int> triangleFaceId;  // index by surfaceIndices/3
public:
    // Public-but-OCC-free API for downstream TODOs:
    glm::vec3 nearestPointOnShape(glm::vec3 query) const;
    glm::vec3 nearestPointOnFace(int faceId, glm::vec2 uvHint) const;
    glm::vec3 normalAt(int faceId, glm::vec2 uv) const;
    std::pair<double,double> principalCurvatures(int faceId, glm::vec2 uv) const;
    std::vector<int> ridgeEdgeIds() const;   // for TODO_10 future use
    std::vector<int> cornerVertexIds() const;
};
```

The header forward-declares; the `.cpp` is the only place OCC types appear. Downstream TODOs include `BRepHandle.h` only, paying no OCC compile-time cost.

### TODO_03 patch: Hausdorff / normal-deviation against NURBS
```cpp
double computeHausdorffToSurface(const FEAModel& m, ...) {
    if (m.hasBRep()) {
        // Sample 4 quadrature points per boundary face; for each, call
        // m.brep->nearestPointOnShape(p) and take max distance.
        // Symmetric pass: sample BRep faces, project to discrete mesh BVH.
    } else {
        // Existing TODO_03 path: BVH on snapshotted refSurfaceForFidelity.
    }
}
```

The verbatim recipe in TODO_03's `## Screen-visible acceptance check` remains valid — only the *value* of Hausdorff improves (it's now distance to ground-truth NURBS, not to a discrete reference).

### Healing dirty STEP (rare but real)
`ShapeFix_Shape` is the catch-all OCC tool. Apply with default options: sews open edges within tolerance, fixes face orientation. If `healShape` modifies more than a few faces, log a warning to console — the user should check the STEP exporter that produced the file.

## Multithreading
- `BRepMesh_IncrementalMesh(..., parallel=true)` — OCC's mesher uses TBB internally; we set `OMP_NUM_THREADS` and OCC respects it via its own thread pool (since OCCT 7.5).
- Triangle harvesting per face: `#pragma omp parallel for schedule(dynamic, 8)` over `TopoDS_Face`s; each thread appends to a thread-local triangle buffer; merge afterwards (matches the existing PolyFEA pattern from `src/FEASolver.cpp:526`).
- Default `useMultithreading = true` (per project convention).

## Numerical care points
- **OCC tolerance vs PolyFEA bbox scaling** — `BRepMesh_IncrementalMesh` interprets `lin_def` in **input file units** (typically mm). Always call `BRepBndLib::Add(shape, bbox)` to discover the bbox and scale `lin_def` to a sensible fraction of it (`sizingChordError * L_diag`), NOT to a hard-coded constant. Hard-coded constants produce dense tessellations for tiny parts and coarse tessellations for big ones.
- **Face orientation** — OCC faces have an `Orientation()` of `TopAbs_FORWARD` or `TopAbs_REVERSED`. The tessellated triangle winding must be flipped for `REVERSED` faces, else half the surface points the wrong way and TODO_03's normal-deviation report goes to ~180° everywhere.
- **STEP file unit detection** — STEP can store length in mm, cm, m, inches. `STEPControl_Reader::WS()->Model()` exposes the unit; convert to PolyFEA's internal metres at load time. Document a console line: `[STEP] file units: mm; converted to m`.
- **Multiple solids in one file** — `reader.OneShape()` returns a `TopoDS_Compound`. We currently treat all sub-solids as one mesh; downstream multi-body simulation is out of scope (would need per-solid material assignments). Log: `[STEP] N solids found; meshed as a single assembly`.
- **Healing side-effects** — `ShapeFix_Shape` can alter face IDs (face renumbering after sew). Build `faceMap` *after* healing, not before.
- **Empty triangulation on a face** — some degenerate faces (zero-area, spline-degenerate) produce no triangles. Skip them with a warning rather than crashing.

## Downstream integration touchpoints

When the future TODOs are created, each must check `model.hasBRep()` and prefer the exact OCC path. The branches are:

| Future TODO (post-shift number) | Was | What to bake in |
|---|---|---|
| **TODO_08** Curved Tet10 mid-edge projection | 07 | If `hasBRep()`: project mid-edge to `brep->nearestPointOnFace(triangleFaceId[edgeTri], uvHint)`. Exact NURBS projection (drift cap still applies). Else: existing nearest-triangle projection. |
| **TODO_10** Sharp feature detection | 09 | If `hasBRep()`: `FeatureGraph::ridges = brep->ridgeEdgeIds()`, `corners = brep->cornerVertexIds()`. Skip dihedral heuristic. Mark source as `"STEP B-rep (exact)"` in console. Else: existing dihedral-angle path. |
| **TODO_11** Curvature + sizing field | 10 | If `hasBRep()`: per surface vertex, look up its (faceId, uv) hint from tessellation; query `brep->principalCurvatures(faceId, uv) -> (κ₁, κ₂)`. Use `max(|κ|)` for sizing. Else: existing cot-Laplacian. |
| **TODO_14** Dirty input + fTetWild | 13 | If `hasBRep()`: skip the dirty-input check (BRep is clean by construction post-healing); route directly to TetGen. Else: existing self-intersection check + fTetWild routing. |
| **TODO_20** AMR cycle solution transfer | 19 | Re-project anchors (TODO_25) using `brep->nearestPointOnShape(anchor.position)` when STEP source. Cheaper and exact vs. BVH-on-new-mesh search. |
| **TODO_25** Surface-patch application | 24 (already renamed) | (Already noted in TODO_25's Cross-references section.) Anchor re-projection during patch resize should use `brep->nearestPointOnFace` when STEP source for sub-pixel accuracy of patch placement on curved CAD. |

Each downstream TODO's screen-check recipe stays valid; the *quality* of the result jumps when the source is STEP.

## Screen-visible acceptance check

**Setup**
1. `cmake --build build --config Release` (first build: OCCT compiles, ~5 min added).
2. Run `./build/FEAPreProcessor`.

**Action**
1. File → Open. Confirm the file-filter dropdown lists `*.step;*.stp` first, `*.stl` second.
2. Select `assets/test_fixtures/unit_cube.step`. (Generated programmatically — see `tools/gen_step_fixtures.cpp`.)
3. Observe rendering and status panel.
4. Click `Generate 3D Mesh` (existing button, no UI change).
5. Run the TODO_03 Hausdorff regression check (`assets/test_fixtures/sphere_r1.step` instead of `.stl`).

**Expected**
- After step 2: cube renders identically to its STL counterpart. Status panel reads `Source: STEP (B-rep retained)`. Console:
  ```text
  [STEP] read OK, 1 solid, 6 faces, 12 edges, 8 vertices
  [STEP] file units: mm; converted to m
  [STEP] tessellated → 12 triangles (lin_def=1.0e-3, ang_def=0.3 rad, parallel=true)
  ```
- After step 4: `Generate 3D Mesh` works without any code change — uses TODO_01/02's pipeline. Quality report PASS as before.
- After step 5 (sphere): `[Fidelity] Hausdorff (NURBS reference, exact): 8e-7 m` (was `4.8e-4 m` from triangulated reference; the value drops 2–3 orders of magnitude because we're now comparing against ground truth). Normal-deviation p95 also tighter. Console line includes `reference: NURBS B-rep (exact)`.

**Failure modes**
- "Cannot read STEP file" → OCCT not linked (check CMake `USE_OCCT=ON`) OR file path has spaces (quote arguments).
- Cube renders 50× too big or 1/50 too small → STEP file units (mm vs m) not detected; check the unit conversion log line.
- Half the cube's faces render dark / inside-out → face-orientation handling missing for `TopAbs_REVERSED` faces during triangle harvesting.
- Hausdorff value unchanged after switching to STEP → `MeshQuality` dispatch on `hasBRep()` not wired; the BRep path is dead code.
- First build hangs or takes > 20 min → OCCT pulling in too many modules; pare back the `target_link_libraries` list to just the 7 enumerated above.

**Pass criterion**
STEP cube and STEP sphere both load, render, mesh, and solve; status panel shows `Source: STEP (B-rep retained)`; Hausdorff value on the sphere drops by at least 2 orders of magnitude compared to the STL version.

## Regression sentinel
- `regression/step_cube_load.txt` — programmatic load of `unit_cube.step`; asserts (`hasBRep() == true`, `surfaceVertices.size() == 24`, `surfaceIndices.size()/3 == 12`).
- `regression/step_sphere_hausdorff.txt` — load `sphere_r1.step`, mesh, run `computeHausdorffToSurface`; assert Hausdorff $< 1\mathrm{e}{-5}\,\text{m}$ (vs. $\sim 5\mathrm{e}{-4}$ from STL).

## Depends on
TODO_03 (the Hausdorff routine being patched). TODO_01 / TODO_02 already done.

## Estimated effort
**4 days.** Breakdown:
- 1.5 days OCCT FetchContent + MSVC linkage debugging (single biggest risk; pin a tag with known-good Windows build).
- 1 day `StepLoader` + `BRepHandle` pImpl wrapper.
- 0.5 day extend `processRawGeometry` + UI status panel.
- 0.5 day TODO_03 Hausdorff/normal-dev patch (sub-task — pure dispatch addition).
- 0.5 day STEP fixtures (`tools/gen_step_fixtures.cpp`) + regression scripts.
