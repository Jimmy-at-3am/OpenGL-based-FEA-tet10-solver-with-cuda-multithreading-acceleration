# TODO_01 — TetGen switches & console quality report

> First TODO in the [knowledge/](knowledge/) implementation plan. See plan §A/§B at `C:\Users\Lenovo\.claude\plans\create-a-thorough-implementatble-hidden-scroll.md`.

## Goal
Tighten TetGen invocation (`-O7`, tighter radius-edge, tighter min-dihedral), introduce the `MeshQuality` library, and print a quality-report block to the console after every `Generate 3D Mesh` click.

## Files added / modified
- **Add** `include/MeshQuality.h`, `src/MeshQuality.cpp` (extract & extend routines currently in `src/mesh_diag.cpp`).
- **Modify** `include/FEAData.h` — extend `FEAParams` with quality-related knobs (see Plan Appendix §2 Phase A.5).
- **Modify** `src/FEAModel.cpp` lines 546–548 — append `O{level}T{tol}` to the switch string; call `MeshQuality::emitReport` after `tetrahedralize`.
- **Modify** `CMakeLists.txt` — add `MeshQuality.cpp` to the `FEAPreProcessor` and existing `mesh_diag` targets so both link the same library.
- **Add** `assets/test_fixtures/unit_cube.stl` — generated once (programmatically saved from `FEAModel::generateCube`) for regression checks.

## Algorithm summary
- TetGen switches: `pq{tetRadiusEdge}/{tetMinDihedralDeg}a{maxVol}AO{tetOptimizeLevel}T1e-10` (note: `T` for robustness tolerance, `O7` enables flips + Laplace smoother). See plan Appendix §2 Phase A.4 and [knowledge/04_Delaunay_CDT_and_TetGen.md §4.3](knowledge/04_Delaunay_CDT_and_TetGen.md).
- `MeshQuality::emitReport` runs a histogram + worst-N report (the metrics themselves are extended in TODO_02; here we only ship the radius-ratio routine already used by `mesh_diag`, the worst-N collector, and the verdict line).

## Multithreading
Quality computation is per-element embarrassingly parallel. Use `#pragma omp parallel for schedule(static)` with thread-local histogram bins; merge serially after the loop. Pattern matches existing assembly in `src/FEASolver.cpp:526–570`. `useMultithreading == true` by default.

## Numerical care points
- Guard `Knupp` denominator: `if (det < 1e-30) return 0` (care-point #2 in plan §4).
- Use `std::clamp(x, -1.0, 1.0)` before `acos` in dihedral computation (#16 indirectly).
- `exactinit()` must be called before any quality routine that uses `orient3d`/`insphere` (care-point #1).
- Use `double` throughout, not `float`, for shape measures.

## Screen-visible acceptance check

**Common preamble**
1. `cmake --build build --config Release`
2. Run `./build/FEAPreProcessor` (or `build\Release\FEAPreProcessor.exe` on Windows)
3. Console window must be visible alongside the OpenGL viewer (both at default size)
4. Test fixtures live in `assets/test_fixtures/` — created by this TODO.

**Setup**
1. Add `assets/test_fixtures/unit_cube.stl` (1 m³, generated programmatically via `FEAModel::generateCube` saved to STL).
2. Launch viewer. Click `Generate Cube` (existing button).

**Action**
1. Click `Generate 3D Mesh`.

**Expected console output (verbatim block, values may vary)**
```text
[Mesh] Quality Report (radius-edge ratio bound: 1.20, min-dihedral: 18.0 deg)
  Knupp shape    : [0.00, 0.20): 0   [0.20, 0.50): 12   [0.50, 0.80): 248   [0.80, 1.00]: 1340
  min dihedral   : min = 23.7 deg   median = 58.1 deg   max-of-min = 70.5 deg
  scaled Jacobian: min = 0.41   median = 0.91   max = 1.00
  Worst-10 elements (by Knupp):
    elem 421: q=0.21 dihedral_min=24.1 sJac=0.42 at (0.50, 0.50, 0.50)
    ...
  Verdict: PASS (0 inverted, 0 slivers below threshold)
```

**Failure modes**
- No `Quality Report` block printed → MeshQuality library not linked into FEAPreProcessor target
- All metrics zero → wrong vertex/index pointers passed (`pointlist` vs `tetrahedronlist`)
- `Verdict: FAIL — N inverted` → exact predicates not initialised (`exactinit()` missing at startup)

**Pass criterion**
The manual screen-visible check passes only if all of the following are true:
1. Console contains `Running TetGen with command:` and the printed switch string contains `O7` and `T1e-10`.
2. Console contains `Meshing Complete! Generated N tetrahedrons` with `N > 0`.
3. The quality-report header echoes the intended active bounds: `radius-edge ratio bound: 1.20` and the configured `min-dihedral` threshold.
4. Console contains `Knupp shape`, `min dihedral`, `scaled Jacobian`, `Worst-10 elements`, and `Verdict: PASS`.
5. The Knupp histogram bin counts sum to `N`.
6. The `Worst-10 elements` section prints exactly `min(10, N)` element rows.
7. `Verdict: PASS` must mean `0 inverted` and `0 slivers below threshold`; a report that prints the required labels but has nonzero inverted/sliver counts fails.
8. The generated cube report either matches `regression/cube_default.txt` or the snapshot is intentionally updated with a note explaining the algorithmic change.

## Regression sentinel
`regression/cube_default.txt` — snapshot of the quality histogram on unit cube. Future commits diff against this; any deviation flags an algo change.

## Depends on
None — first TODO in chain.

## Estimated effort
1.5 days (mostly extracting `mesh_diag.cpp` cleanly into a library + wiring CMake).
