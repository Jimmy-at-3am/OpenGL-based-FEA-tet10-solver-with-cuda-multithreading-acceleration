# TODO_11 — Curvature + sizing field visualisation

## Goal
Compute discrete mean curvature on the input surface and the resulting sizing field $h(x)$; visualise both via keypress (`C` for curvature heat-map, `S` for sizing-glyph). Foundation for TODO_12 (sizing-driven TetGen).

## Files added / modified
- **Add** `include/SizingField.h`, `src/SizingField.cpp` — discrete curvature + sizing field + gradation smoothing.
- **Modify** `include/FEAModel.h` — store `std::vector<float> meanCurvaturePerVertex`, `sizingPerVertex`.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — `C` and `S` toggle keys; legends.
- **Modify** `src/ShaderSources.h` — surface heatmap shader path; sphere-glyph instanced rendering.

## Algorithm summary
From [knowledge/03_Surface_Meshing_Curved_Manifolds.md §1](knowledge/03_Surface_Meshing_Curved_Manifolds.md), [knowledge/12_Mesh_Smoothing_CVT_and_ODT.md §1.2](knowledge/12_Mesh_Smoothing_CVT_and_ODT.md), plan Appendix Phase C.1, C.2:

**Discrete mean curvature** (Pinkall–Polthier cotangent Laplacian — used when source is STL/3MF):
$$H(v_i) = \frac{1}{2 A_{\text{mixed}}(v_i)} \left\| \sum_{j\in\mathcal{N}(i)} \tfrac{1}{2}(\cot\alpha_{ij} + \cot\beta_{ij}) (v_j - v_i) \right\|$$
$A_{\text{mixed}}$ = Meyer's mixed Voronoi/barycentric area (handles obtuse triangles).

For sharper $\max|\kappa|$ estimate use **Taubin normal-deviation tensor** (1995); use Taubin in implementation, mean-curvature as fallback if Taubin's eigensolver fails.

**STEP source — exact NURBS curvature** (when `model.hasBRep()`, from TODO_04):
For each surface vertex, look up its (faceId, uv) from the tessellation map kept by TODO_04. Query `brep->principalCurvatures(faceId, uv) -> (κ₁, κ₂)` (OCC `BRepLProp_SLProps`). Use `max(|κ₁|, |κ₂|)` for sizing — the same role $H$ plays in the discrete path. Result is **smooth and continuous** across NURBS face boundaries (no banding artefacts that the cot-Laplacian produces near face seams). Log: `[Curvature] source: NURBS (exact); range [κ_min, κ_max] = [0.99, 1.01] on sphere`.

**Sizing field:**
```text
For each surface vertex v_i:
    kappa = computeTaubinMaxCurvature(v_i)
    h_curv = sqrt(8) * sizingChordError * L_diag / max(kappa, eps)
    h = clamp(h_curv, sizingHMinRatio * L_diag, sizingHMaxRatio * L_diag)
    sizingPerVertex[i] = h
At feature ridges (TODO_10): clamp h to local h_min.
At feature corners (TODO_10): clamp to h_min.
```

**Gradation smoothing** (Persson 2006 eikonal):
```text
for sweep = 1..maxGradationSweeps:
    converged = true
    #pragma omp parallel for reduction(&&:converged)
    for each surface edge (i, j):
        Lij = length(v_i, v_j)
        target_i = min(sizingPerVertex[i], sizingPerVertex[j] * (1 + grad * Lij))
        // atomic CAS update
    if converged: break
```

## Multithreading
- Cot-Laplacian assembly: per-vertex parallel-for; output is per-vertex (no shared write).
- Gradation sweeps: per-edge parallel with atomic CAS on per-vertex sizing values.

## Numerical care points
- **Mixed area** is the correct Voronoi-area for non-obtuse triangles; falls back to barycentric for obtuse. Plain Voronoi area gives negative values on obtuse triangles → wrong curvature.
- Curvature on a perfect sphere should be constant ($H = 1/R$); use this as a sanity check in tests.
- Gradation parameter `α ∈ [0.2, 0.4]` typical; `0.3` default.

## Screen-visible acceptance check

**Setup** Load `assets/test_fixtures/sphere_r1.stl`.

**Action** Press `C` for curvature colour-map; then `S` for sizing-field glyphs.

**Expected visible**
- With `C`: surface coloured uniformly (sphere has constant $H = 1/R$); console: `[Curvature] H min=0.99 max=1.01 (sphere check)`.
- With `S`: small wireframe spheres at every 10th vertex, radius proportional to $h(x_i)$; uniform for sphere; legend bottom-right.

**Failure modes**
- Curvature wildly non-uniform → Voronoi area computed wrong (using barycentric instead of mixed Voronoi area near obtuse triangles).
- Glyphs only at boundary → vertex loop skipping interior nodes.
- Toggle keys override each other → key-event handler doesn't allow stacking.

**Pass criterion** Sphere $H$ within $\pm 5\%$ of $1/R$ everywhere; glyphs visible and roughly uniform.

## Regression sentinel
`regression/curvature_sphere.txt` — H min/max + sizing min/max for sphere.

## Depends on
TODO_10 (feature graph for ridge/corner clamps).

## Estimated effort
2.5 days.
