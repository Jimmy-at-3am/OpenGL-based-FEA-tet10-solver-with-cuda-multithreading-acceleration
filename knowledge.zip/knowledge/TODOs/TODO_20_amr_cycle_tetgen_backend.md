# TODO_20 — AMR cycle (TetGen-region backend)

## Goal
Wire the full SOLVE → ESTIMATE → MARK → REFINE → TRANSFER loop using TetGen-region refinement. A `Run AMR` button iterates 5+ cycles, mesh visibly densifies at singularities each cycle, progress bar tracks cycles.

## Files added / modified
- **Add** `include/AdaptiveSolver.h`, `src/AdaptiveSolver.cpp`.
- **Add** `include/SolutionTransfer.h`, `src/SolutionTransfer.cpp` — old→new mesh interpolation.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — `Run AMR` button + iteration counter widget.
- **Modify** `src/FEAModel.cpp::generateVolumetricMesh()` — accept marked elements via TetGen region-list mechanism.

## Algorithm summary
From [knowledge/11_Adaptive_Refinement_hp_and_DWR.md](knowledge/11_Adaptive_Refinement_hp_and_DWR.md) and plan Appendix Phase E.3, E.4, E.5, E.6:

```cpp
struct AMRResult { int cycles; double finalEta; double qoiValue; };

AMRResult AdaptiveSolver::solve(FEAModel& model, FEASolver& solver,
                                const FEAParams& params, AsyncTask& task) {
    double eta0 = -1.0;
    for (int k = 0; k < params.amrMaxIterations; ++k) {
        if (task.cancelled) return {k, -1, 0};

        // (S) SOLVE — reuses existing solver, untouched
        solver.solveNonlinearStatic(model, /*visualScale=*/1.0f);

        // (E) ESTIMATE — TODO_19 reused
        auto sigmaStar = ZZRecovery::recoverNodal(model);
        auto etaT      = ZZRecovery::elementIndicators(model, sigmaStar);

        double etaG = std::sqrt(std::accumulate(etaT.begin(), etaT.end(), 0.0,
                                  [](double a, double b){return a + b*b;}));
        if (eta0 < 0) eta0 = etaG;
        task.progress.store(float(k + 1) / params.amrMaxIterations);

        if (k >= 1 && etaG / eta0 < params.amrTolerance) {
            return {k+1, etaG, evalQoI(model)};
        }

        // (M) MARK — Dörfler bulk marking
        // sort descending, accumulate until sum(eta^2) >= theta * total
        std::vector<size_t> indices(etaT.size());
        std::iota(indices.begin(), indices.end(), 0);
        std::sort(std::execution::par_unseq, indices.begin(), indices.end(),
                  [&](size_t a, size_t b){return etaT[a] > etaT[b];});
        double target = params.amrDorflerTheta * etaG * etaG;
        std::vector<bool> marked(etaT.size(), false);
        double sum = 0;
        for (size_t i : indices) {
            marked[i] = true; sum += etaT[i] * etaT[i];
            if (sum >= target) break;
        }

        // (R) REFINE via TetGen region-list (default backend)
        FEAModel oldModel = model;  // snapshot for transfer
        refineViaTetGenRegion(model, marked, params);

        // Solution transfer — TODO_20's SolutionTransfer
        SolutionTransfer::transferState(oldModel, model);

        // Load-anchor re-projection (TODO_25's cross-ref requirement).
        // For STEP source, project via OCC's NURBS NearestPoint; else
        // project via new mesh's surface BVH.
        for (auto& anchor : model.loadAnchors) {
            if (model.hasBRep())
                anchor.reproject(*model.brep);          // exact NURBS, TODO_04
            else
                anchor.reproject(newSurfaceBVH);        // BVH on new triangulation
            anchor.invalidatePatchCache();
        }

        if (params.enableODTSmoothing) ODTSmoother::run(model, params);
        publishMesh(model);   // GL buffer swap so user sees the cycle
    }
    return {params.amrMaxIterations, -1, evalQoI(model)};
}
```

**TetGen-region refinement** (the simplest backend, per plan Appendix Phase E.4):
- For each marked element, compute its centroid and a target volume = current_volume / 2.
- Pass these as `regionlist` entries to TetGen with `-r` switch (refine mode).
- Re-run `generateVolumetricMesh()` from scratch with constraints.

**Solution transfer:**
```text
Build BVH on old mesh (parallel)
#pragma omp parallel for schedule(dynamic, 256)
For each new node n_new:
    Locate enclosing old element T_old via BVH (may need tolerance for boundary)
    Compute barycentric coords (xi, eta, zeta) in T_old
    u_new[n_new] = sum over T_old nodes (N_i * u_old[i])
For nodes outside old convex hull: use nearest-point projection
```

## Multithreading
- All sub-steps internally parallel as documented in their TODOs (TODO_06 ODT, TODO_19 ZZ).
- Outer AMR loop is sequential by design (each step depends on prior).
- Runs in AsyncTask (TODO_13) so the cycle's whole 30-90 s doesn't freeze the UI.

## Numerical care points
- **Determinism in parallel sort** (care-point #12) — use `std::stable_sort` with `std::execution::par_unseq` for reproducibility.
- **Solution transfer at boundary** (care-point #10) — old-mesh BVH can give "outside" for a new node on the geometry boundary (numerical bbox slack). Use tolerance + nearest-old-face projection.
- **Energy after transfer** — log primal residual after transfer; if it jumps, transfer quality is poor (may need higher-order shape function evaluation, not just $P_1$). For `enableAMRCycle = false` users can disable transfer for cold-start.

## Screen-visible acceptance check

**Setup** Same as TODO_19.

**Action** Open params panel, enable `enableAMRCycle`, set `amrMaxIterations=5`. Click `Run AMR`.

**Expected**
- Animated viewer: every cycle the mesh re-renders with progressively denser elements near the re-entrant corner.
- Progress bar tracks `AMR cycle 1/5 ... 5/5`.
- Console per cycle:
  ```text
  [AMR k=0] nodes: 1247 → 1832   η_global: 2.41e-3 → 1.51e-3 (×0.63)
  [AMR k=1] nodes: 1832 → 2741   η_global: 1.51e-3 → 9.4e-4 (×0.62)
  ...
  [AMR] CONVERGED at cycle 4   final η/η0 = 0.0089
  ```
- HUD overlay (Q) shows quality preserved.

**Failure modes**
- $\eta$ doesn't decrease → marking wrong (refining low-error elements).
- $\eta$ jumps up after a cycle → solution-transfer broken (cold-start losing information).
- Viewer doesn't animate → buffer-swap missing between cycles.

**Pass criterion** $\eta$ decreases monotonically for $\ge 3$ cycles AND visible mesh densification at corner.

## Regression sentinel
`regression/amr_lshape.txt` — per-cycle (nodes, η, time) tuples on L-shape.

## Depends on
TODO_13 (progress UI), TODO_19 (ZZ indicators). Optional integration with TODO_16 (MMG-local backend) for higher-quality refinement.

## Estimated effort
4 days.
