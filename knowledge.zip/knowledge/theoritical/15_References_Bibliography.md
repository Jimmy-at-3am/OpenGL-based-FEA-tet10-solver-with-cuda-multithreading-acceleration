---
title: References — Annotated Bibliography
type: reference
tags: [bibliography, papers, google-scholar, books, vendor-manuals]
created: 2026-05-16
---

# 15 — Annotated Bibliography

Organised by topic to mirror the vault structure. Each entry includes a one-line annotation. Google Scholar hits should be the primary route; key author homepages link to PDFs.

---

## A. Foundations (Voronoi, Delaunay, manifolds)

- M. de Berg, O. Cheong, M. van Kreveld, M. Overmars, *Computational Geometry: Algorithms and Applications*, 3rd ed., Springer, 2008. — textbook reference for Voronoi/Delaunay.
- F. Aurenhammer, "Voronoi diagrams — a survey of a fundamental geometric data structure," *ACM Computing Surveys* 23(3), 1991. — canonical Voronoi survey.
- D.-T. Lee, B. J. Schachter, "Two algorithms for constructing a Delaunay triangulation," *Int. J. Comp. Inf. Sci.* 9, 1980. — historical incremental construction.
- N. Amenta, S. Choi, G. Rote, "Incremental construction with monotone curves and good Delaunay refinement," *Discrete & Comput. Geom.* 30, 2003. — Bowyer–Watson with BRIO.
- H. Federer, "Curvature measures," *Trans. AMS* 93, 1959. — reach of a smooth surface.
- L. Chen & M. Holst, "Efficient mesh optimization schemes based on Optimal Delaunay Triangulations," *CMAME* 200, 2011. — ODT theory and algorithm.
- Q. Du, V. Faber, M. Gunzburger, "Centroidal Voronoi tessellations: applications and algorithms," *SIAM Review* 41(4), 1999. — CVT canonical reference.

## B. Quality Metrics

- J. R. Shewchuk, "What is a Good Linear Finite Element? Interpolation, Conditioning, Anisotropy, and Quality Measures," unpublished, 2002. — the must-read reference; available on Shewchuk's home page at Berkeley.
- P. Knupp, "Algebraic mesh quality metrics," *SIAM J. Sci. Comput.* 23, 2001. — mean ratio measure and friends.
- A. Liu, B. Joe, "Relationship between tetrahedron shape measures," *BIT Numer. Math.* 34, 1994. — equivalence classes among quality measures.
- S.-W. Cheng, T. K. Dey, H. Edelsbrunner, M. A. Facello, S.-H. Teng, "Sliver exudation," *J. ACM* 47(5), 2000. — sliver elimination via weight perturbation.

## C. Surface Meshing on Manifolds

- W. Tutte, "How to draw a graph," *Proc. London Math. Soc.* 13, 1963. — Tutte embedding.
- M. S. Floater, "Mean value coordinates," *CAGD* 20, 2003. — MVC, standard surface barycentric coords.
- B. Lévy, S. Petitjean, N. Ray, J. Maillot, "Least squares conformal maps for automatic texture atlas generation," *ACM TOG (SIGGRAPH)* 21, 2002. — LSCM.
- A. Sheffer, B. Lévy, M. Mogilnitsky, A. Bogomyakov, "ABF++: Fast and robust angle based flattening," *ACM TOG* 24, 2005. — angle-based parametrisation.
- D.-M. Yan, B. Lévy, Y. Liu, F. Sun, W. Wang, "Isotropic Remeshing with Fast and Exact Computation of Restricted Voronoi Diagram," *SGP* 2009. — RVD/RCVT surface meshing.
- B. Lévy, N. Bonneel, "Variational Anisotropic Surface Meshing with Voronoi Parallel Linear Enumeration," *IMR* 2013. — anisotropic surface CVT.
- F. Hildebrandt, K. Polthier, M. Wardetzky, "Smooth feature lines on surface meshes," *SGP* 2005. — feature graph extraction.
- N. Amenta & M. Bern, "Surface reconstruction by Voronoi filtering," *Discrete & Comput. Geom.* 22, 1999. — $\varepsilon$-sample theory.

## D. Delaunay, CDT, TetGen

- A. Bowyer, "Computing Dirichlet tessellations," *Comp. J.* 24, 1981.
- D. F. Watson, "Computing the n-dimensional Delaunay tessellation," *Comp. J.* 24, 1981.
- J. R. Shewchuk, "Adaptive Precision Floating-Point Arithmetic and Fast Robust Geometric Predicates," *Discrete & Comput. Geom.* 18, 1997. — the predicates used in `src/predicates.cxx`.
- J. Ruppert, "A Delaunay refinement algorithm for quality 2-dimensional mesh generation," *J. Algorithms* 18, 1995.
- J. R. Shewchuk, "Tetrahedral mesh generation by Delaunay refinement," *SoCG* 1998.
- H. Si, J. R. Shewchuk, "Incrementally constructing and updating constrained Delaunay tetrahedralizations with finite-precision coordinates," *Engineering with Computers* 30(2), 2014.
- H. Si, "TetGen, a Delaunay-Based Quality Tetrahedral Mesh Generator," *ACM TOMS* 41(2), 2015. — TetGen 1.5/1.6 reference paper.

## E. Advancing-Front, Frontal-Delaunay

- R. Löhner, "Generation of three-dimensional unstructured grids by the advancing-front method," *Int. J. Numer. Methods Fluids* 8, 1988.
- J. Peraire, J. Peiró, K. Morgan, "Adaptive remeshing for three-dimensional compressible flow computations," *J. Comput. Phys.* 103, 1992.
- C. Geuzaine, J.-F. Rémacle, "Gmsh: a 3-D finite element mesh generator with built-in pre- and post-processing facilities," *IJNME* 79, 2009.
- J.-F. Rémacle, V. Henrotte, T. Carrier-Baudouin, E. Béchet, "A frontal Delaunay quad mesh generator using the L∞ norm," *IJNME* 94, 2013.
- F. Hecht, "BAMG: Bidimensional Anisotropic Mesh Generator," INRIA Report, 1998.

## F. Octree, BCC, Implicit, Isosurface Stuffing

- F. Labelle, J. R. Shewchuk, "Isosurface Stuffing: Fast Tetrahedral Meshes with Good Dihedral Angles," *ACM TOG (SIGGRAPH)* 26, 2007. — the canonical "guaranteed angle" implicit mesher.
- R. Bridson, F. Labelle, "Adaptive Isosurface Stuffing," lecture notes, 2008.
- W. E. Lorensen, H. E. Cline, "Marching cubes: A high resolution 3-D surface construction algorithm," *ACM TOG (SIGGRAPH)* 21, 1987.
- T. Ju, F. Losasso, S. Schaefer, J. Warren, "Dual Contouring of Hermite Data," *ACM TOG (SIGGRAPH)* 21, 2002.
- A. Düster, J. Parvizian, Z. Yang, E. Rank, "The finite cell method for three-dimensional problems of solid mechanics," *CMAME* 197, 2008.
- E. Burman, S. Claus, P. Hansbo, M. G. Larson, A. Massing, "CutFEM: Discretizing geometry and partial differential equations," *IJNME* 104, 2015.
- Z. Chen, A. Tagliasacchi, H. Zhang, "Neural Marching Cubes," *ACM TOG* 40, 2021.

## G. Polyhedral, Mosaic, VEM

- E. L. Wachspress, *A Rational Finite Element Basis*, Academic Press, 1975.
- L. Beirão da Veiga, F. Brezzi, A. Cangiani, G. Manzini, L. Marini, A. Russo, "Basic principles of virtual element methods," *Math. Models Methods Appl. Sci.* 23, 2013.
- C. Talischi, G. H. Paulino, A. Pereira, I. F. Menezes, "PolyMesher: A general-purpose mesh generator for polygonal elements written in MATLAB," *Struct. Multidisc. Optim.* 45, 2012.
- L. Beirão da Veiga, F. Brezzi, L. Marini, "Virtual elements for linear elasticity problems," *SIAM J. Numer. Anal.* 51, 2013.
- ANSYS, "Fluent Meshing — Mosaic Technology," *Release Notes* 19R1 (2019).

## H. Anisotropic Metric Adaptation

- F. Loseille, F. Alauzet, "Continuous mesh framework Part I & II," *SIAM J. Numer. Anal.* 49(1), 2011. — the canonical pair of papers.
- V. Arsigny, P. Fillard, X. Pennec, N. Ayache, "Log-Euclidean metrics for fast and simple calculus on diffusion tensors," *Magnetic Resonance in Medicine* 56, 2006.
- C. Dapogny, C. Dobrzynski, P. Frey, "Three-dimensional adaptive domain remeshing, implicit domain meshing, and applications to free and moving boundary problems," *J. Comput. Phys.* 262, 2014. — MMG3D paper.
- A. Loseille, "Unstructured mesh generation and adaptation," in *Handbook of Numerical Analysis* 18, 2017.
- A. Loseille, F. Alauzet, V. Menier, "Unique cavity-based operator and hierarchical domain partitioning for fast parallel generation of anisotropic meshes," *Computer-Aided Design* 85, 2017.

## I. Robust Tetrahedralisation (TetWild family)

- A. Jacobson, L. Kavan, O. Sorkine-Hornung, "Robust inside-outside segmentation using generalized winding numbers," *ACM TOG* 32, 2013.
- Y. Hu, Q. Zhou, X. Gao, A. Jacobson, D. Zorin, D. Panozzo, "Tetrahedral meshing in the wild," *ACM TOG (SIGGRAPH)* 37, 2018. — TetWild.
- Y. Hu, T. Schneider, B. Wang, D. Zorin, D. Panozzo, "Fast tetrahedral meshing in the wild," *ACM TOG (SIGGRAPH)* 39, 2020. — fTetWild.
- B. Wang, Y. Hu, D. Panozzo, "Exact and Efficient Polyhedral Envelope Containment Check," *ACM TOG* 39, 2020.
- Q. Zhou, A. Jacobson, "Thingi10K: A Dataset of 10,000 3D-Printing Models," arXiv:1605.04797, 2016.

## J. Hex / Quad Meshing, Frame Fields

- D. Bommes, H. Zimmer, L. Kobbelt, "Mixed-integer quadrangulation," *ACM TOG (SIGGRAPH)* 28, 2009.
- W. Jakob, M. Tarini, D. Panozzo, O. Sorkine-Hornung, "Instant Field-Aligned Meshes," *ACM TOG (SIGGRAPH Asia)* 34, 2015.
- D. Bommes, M. Campen, H.-C. Ebke, P. Alliez, L. Kobbelt, "Integer-grid maps for reliable quad meshing," *ACM TOG (SIGGRAPH)* 32, 2013.
- F. Knöppel, K. Crane, U. Pinkall, P. Schröder, "Globally optimal direction fields," *ACM TOG (SIGGRAPH)* 32, 2013.
- J. Huang, Y. Tong, H. Wei, H. Bao, "Boundary aligned smooth 3D cross-frame field," *ACM TOG (SIGGRAPH Asia)* 30, 2011.
- J. Solomon, A. Vaxman, D. Bommes, "Boundary element octahedral fields in volumes," *ACM TOG* 36, 2017.
- M. Livesu, N. Vining, A. Sheffer, J. Gregson, R. Scateni, "PolyCut: monotone graph-cuts for PolyCube base-complex construction," *ACM TOG (SIGGRAPH Asia)* 32, 2013.
- C. Marot, J. Pellerin, J.-F. Rémacle, "One machine, one minute, three billion tetrahedra," *IJNME* 117, 2019.

## K. Adaptive Refinement, A Posteriori, DWR

- O. C. Zienkiewicz, J. Z. Zhu, "A simple error estimator and adaptive procedure for practical engineering analysis," *IJNME* 24, 1987.
- O. C. Zienkiewicz, J. Z. Zhu, "The superconvergent patch recovery and a posteriori error estimates," *IJNME* 33, 1992.
- R. Verfürth, *A Posteriori Error Estimation Techniques for Finite Element Methods*, Oxford Univ. Press, 2013.
- R. Becker, R. Rannacher, "An optimal control approach to a posteriori error estimation in finite element methods," *Acta Numerica* 10, 2001.
- W. Dörfler, "A convergent adaptive algorithm for Poisson's equation," *SIAM J. Numer. Anal.* 33, 1996.
- J. M. Cascón, C. Kreuzer, R. H. Nochetto, K. G. Siebert, "Quasi-optimal convergence rate for an adaptive finite element method," *SIAM J. Numer. Anal.* 46, 2008.
- C. Schwab, *p- and hp-Finite Element Methods*, Oxford, 1998.
- D. A. Venditti, D. L. Darmofal, "Anisotropic grid adaptation for functional outputs," *J. Comput. Phys.* 187, 2003.
- T. Grätsch, K.-J. Bathe, "A posteriori error estimation techniques in practical finite element analysis," *Computers & Structures* 83, 2005.

## L. Smoothing (Laplacian, CVT, ODT)

- L. R. Herrmann, "Laplacian-isoparametric grid generation scheme," *J. Eng. Mech. Div.* 102, 1976.
- L. A. Freitag, "On combining Laplacian and optimization-based mesh smoothing techniques," *Trends in Unstructured Mesh Generation* AMD-220, 1997.
- L. Freitag, P. Knupp, "Tetrahedral mesh improvement via optimization of the element condition number," *IJNME* 53, 2002.
- Y. Liu, W. Wang, B. Lévy, F. Sun, D.-M. Yan, L. Lu, C. Yang, "On centroidal Voronoi tessellation—energy smoothness and fast computation," *ACM TOG* 28, 2009. — L-BFGS CVT.
- L. Chen, J. Xu, "Optimal Delaunay triangulations," *J. Comput. Math.* 22, 2004.
- J. Tournois, C. Wormser, P. Alliez, M. Desbrun, "Interleaving Delaunay refinement and optimization for practical isotropic tetrahedron mesh generation," *ACM TOG (SIGGRAPH)* 28, 2009.
- B. Joe, "Three-dimensional triangulations from local transformations," *SIAM J. Sci. Stat. Comput.* 10, 1989.
- M. Desbrun, M. Meyer, P. Schröder, A. H. Barr, "Implicit fairing of irregular meshes using diffusion and curvature flow," *SIGGRAPH* 1999.

## M. Machine Learning for Meshing (2020–2025)

- T. Pfaff, M. Fortunato, A. Sanchez-Gonzalez, P. W. Battaglia, "Learning mesh-based simulation with graph networks," *ICLR* 2021. — MeshGraphNets.
- Z. Zhang, Y. Wang, P. K. Jimack, H. Wang, "MeshingNet: a new mesh generation method based on deep learning," *Int. Conf. Comp. Sci.* 2020.
- C. Bohn, B. Riepl, S. Klus, "Graph-neural-network-based size field prediction for finite-element meshing," *CMAME* 421, 2024.
- C. Nash, Y. Ganin, S. M. A. Eslami, P. W. Battaglia, "PolyGen: an autoregressive generative model of 3D meshes," *ICML* 2020.
- R. Hanocka, A. Hertz, N. Fish, R. Giryes, S. Fleishman, D. Cohen-Or, "MeshCNN: a network with an edge," *ACM TOG* 38, 2019.
- X. Wang, B. Xu, K. Mu, "PIE-Net: parametric inference of point cloud edges," *NeurIPS* 2020.
- NVIDIA Modulus, "Physics-ML framework," NVIDIA documentation, 2024.

## N. Books / Surveys (textbook treatments)

- P.-L. George, H. Borouchaki, *Delaunay Triangulation and Meshing: Application to Finite Elements*, Hermes, 1998. — early French school comprehensive volume.
- P. J. Frey, P.-L. George, *Mesh Generation: Application to Finite Elements*, 2nd ed., Wiley, 2008. — broadest survey.
- S.-W. Cheng, T. K. Dey, J. R. Shewchuk, *Delaunay Mesh Generation*, CRC, 2012. — modern theoretical reference.
- J. R. Shewchuk, "Delaunay Refinement Algorithms for Triangular Mesh Generation," *CGTA* 22, 2002.
- O. C. Zienkiewicz, R. L. Taylor, J. Z. Zhu, *The Finite Element Method: its Basis and Fundamentals*, 7th ed., Elsevier, 2013. — definitive ZZ recovery, adaptive solve.
- R. Verfürth, *A Posteriori Error Estimation*, Oxford, 2013.

## O. Vendor Manuals (version-pinned)

- COMSOL Multiphysics, *Reference Manual* 6.3, 2024.
- COMSOL Multiphysics, *Release Highlights* 5.6 → 6.0 → 6.3.
- ANSYS, *Mechanical APDL Theory Reference* 2024R2.
- ANSYS, *Fluent Meshing User's Guide* 2024R2.
- ANSYS, *Workbench Meshing User's Guide* 2024R2.
- ANSYS, *Discovery AI Acceleration Whitepaper*, 2023.
- MathWorks, *Partial Differential Equation Toolbox User's Guide*, R2024b.

## P. Open-Source Project Documentation

- C. Geuzaine, J.-F. Rémacle, *Gmsh Reference Manual* 4.13, https://gmsh.info.
- H. Si, *TetGen User's Manual* 1.6.0, https://wias-berlin.de/software/tetgen.
- INRIA MMG team, *MMG3D Reference Manual* 5.7, https://www.mmgtools.org.
- Y. Hu et al., *fTetWild* repository, https://github.com/wildmeshing/fTetWild.
- CGAL Editorial Board, *CGAL User and Reference Manual* 5.6.
- libigl, *Documentation*, https://libigl.github.io.
- Geogram, *Reference Manual*, https://github.com/BrunoLevy/geogram.
- Cleaver2, https://github.com/SCIInstitute/Cleaver.

## Q. Useful Datasets and Benchmarks

- **Thingi10K** — 10K real-world 3-D printing STL models, often used as the robustness benchmark for meshers (TetWild, fTetWild). https://ten-thousand-models.appspot.com.
- **ABC Dataset** — 1M CAD models with B-rep, used for ML pre-training (Koch 2019).
- **PARSEC** — parametric airfoils, classical CFD benchmark for adaptation.
- **NACA0012** — classical CFD validation problem.
- **DLR-F6 / NASA Common Research Model** — industrial-scale CFD geometries for Mosaic benchmarks.

## R. Recommended Reading Path

For a one-week deep dive in 2025:

1. **Day 1** — *Mesh Generation* (Frey & George 2008) ch. 1–4, with [[01_Mathematical_Foundations]].
2. **Day 2** — Shewchuk's "What is a Good Linear Finite Element?" and [[02_Mesh_Quality_Metrics]].
3. **Day 3** — Loseille & Alauzet 2011 part I+II and [[08_Anisotropic_Metric_Adaptation]].
4. **Day 4** — TetWild + fTetWild papers and [[09_Robust_TetWild_for_Dirty_Geometry]].
5. **Day 5** — Instant Meshes + Bommes 2013 and [[10_Hex_QuadMeshing_FrameFields]].
6. **Day 6** — Becker & Rannacher 2001 (DWR) and [[11_Adaptive_Refinement_hp_and_DWR]].
7. **Day 7** — Pfaff 2020 (MeshGraphNets) and [[13_ML_and_Neural_Mesh_Generation]].

This sequence builds from classical theory through 2020s methodology and primes the reader to evaluate vendor releases (ANSYS Mosaic, COMSOL physics-controlled mesh) on first principles rather than marketing claims.
