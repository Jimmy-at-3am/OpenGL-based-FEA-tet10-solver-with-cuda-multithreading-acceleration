# TODO_02 â€” Quality library: full metrics set

## Goal
Extend `MeshQuality` with the full set of shape measures from [knowledge/02_Mesh_Quality_Metrics.md](knowledge/02_Mesh_Quality_Metrics.md) â€” Knupp shape, equiangular skew, scaled Jacobian (Tet4 + Tet10), min/max dihedrals â€” plus per-metric percentile tables.

## Files added / modified
- **Modify** `include/MeshQuality.h`, `src/MeshQuality.cpp` â€” add per-metric functions.
- **Modify** `src/FEAModel.cpp` â€” pass Tet4 vs Tet10 to the report so the right Jacobian sampler runs.

## Algorithm summary
Implement (each parallel `#pragma omp parallel for schedule(static)` with thread-local bins):
- `computeRadiusRatio(tet) -> rho_T = 3 r/R` ([knowledge/02_Mesh_Quality_Metrics.md Â§1.1](knowledge/02_Mesh_Quality_Metrics.md)).
- `computeMinMaxDihedral(tet) -> (theta_min, theta_max)` â€” six dihedrals via face-normal dot products (Â§1.4).
- `computeScaledJacobian(tet) -> J* in [-1,1]` â€” for Tet4 use constant Jacobian; for Tet10 take min over the 4 Hammer integration points (Â§1.3).
- `computeKnuppShape(tet) -> q in [0,1]` $= 3\det(J)^{2/3} / \|J\|_F^2$ (Â§1.5).
- `computeEquiangularSkew(tet) -> S in [0,1]` â€” ANSYS convention (Â§1.2).
- `computeIsoparametricKnupp(tet10)` â€” Knupp averaged over 4 Hammer points.

Percentile table per metric: `p05 / p50 / p95 / p99` via `std::nth_element` on a copy.

## Multithreading
All metric loops parallel-for over elements with thread-local accumulators. Percentile computation is serial but $O(N\log N)$ on a `std::nth_element` partial sort.

## Numerical care points
- Knupp denominator guard `det < 1e-30` (care-point #2).
- `acos` clamp (care-point #16).
- Equiangular skew formula: $S = (V_{\text{equi}}(R) - V_T)/V_{\text{equi}}(R)$ with $V_{\text{equi}}$ the volume of the equilateral simplex sharing the circumradius â€” NOT in degrees.
- Tet10 scaled Jacobian sampled at exactly the 4 Hammer points used by the solver (`Tet10Element.cpp` Gauss points), not more â€” sampling extra is wasteful and confusing.

## Screen-visible acceptance check

**Setup** Same as TODO_01.

**Action** Click `Generate 3D Mesh`; the report from TODO_01 is automatic.

**Expected additional output**
Report now also includes `equiangular skew` histogram and per-metric **percentile table** (5th / 50th / 95th / 99th).
```text
  equiangular skew: [0.00, 0.25): 1492   [0.25, 0.50): 78   [0.50, 0.80): 30   [0.80, 1.00]: 0
  percentiles
    Knupp           p05=0.32 p50=0.78 p95=0.94 p99=0.97
    min dihedral    p05=24.1 p50=58.4 p95=68.9 p99=70.5
    scaled Jacobian p05=0.42 p50=0.91 p95=0.99 p99=1.00
    skew            p05=0.03 p50=0.13 p95=0.41 p99=0.62
```

**Failure modes**
- Equiangular skew values $>1$ â†’ formula uses degrees instead of normalised fraction.
- 99th percentile equals 100th (max) â†’ fewer than 100 elements; percentile interpolation degenerate (acceptable for tiny meshes, document it).
- Tet10 `scaled Jacobian` reports < 0 even for nice meshes â†’ wrong Hammer-point coordinates.

**Pass criterion** Report contains `equiangular skew` AND a `p05/p50/p95/p99` line for every metric.

## Regression sentinel
Append to `regression/cube_default.txt` the new metrics' p50 values; future runs diff.

## Depends on
TODO_01.

## Estimated effort
1 day.

## Final verdict policy

TODO_02 accepts practical fine meshes with a very small residual sliver tail. The console verdict is:

- `FAIL` if any element is inverted (`scaledJacobian <= 0`).
- `WARN` if no elements are inverted but either the severe-sliver tail (`min dihedral < 5 deg`) or below-target tail (`min dihedral < tetMinDihedralDeg`) exceeds `1.0%` of elements.
- `PASS` if no elements are inverted and both tails are `<= 1.0%`.

This keeps TetGen's min-dihedral value as a reported target while avoiding forced over-coarsening just to reach zero residual slivers.
