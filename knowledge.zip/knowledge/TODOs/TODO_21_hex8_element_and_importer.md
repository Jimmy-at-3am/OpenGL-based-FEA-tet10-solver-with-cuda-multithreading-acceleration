# TODO_21 — Hex8 element + .inp / .vtu / .msh importer

## Goal
Add `Hex8Element` (trilinear hexahedron, $2\times2\times2$ Gauss, optional B-bar) as a new `IElement` subclass, plus an importer for hex meshes generated externally (Cubit, HexBox, ANSYS, Gmsh). Renders distinctly; solves correctly on a simple cantilever.

## Files added / modified
- **Add** `include/HexElement.h`, `src/HexElement.cpp`.
- **Add** `include/HexMeshImporter.h`, `src/HexMeshImporter.cpp` — supports `.inp` (Abaqus), `.vtu` (VTK), `.msh` (Gmsh v4 ASCII).
- **Modify** `include/FEAModel.h` — add `std::vector<unsigned int> hexes` (8 per element), element-type flag.
- **Modify** `src/FEASolver.cpp` — element-factory loop instantiates HexElement when appropriate.
- **Modify** `src/FEAModel.cpp::loadFile()` — dispatch by extension; route `.inp/.vtu/.msh` to `HexMeshImporter`.
- **Modify** `src/ShaderSources.h` — hex element wireframe rendering (12 edges, 6 quad faces).
- **Add** `assets/test_fixtures/cube_hex_2x2x2.inp` — Abaqus-format hex mesh, 8 hex elements, 27 nodes.

## Algorithm summary
From plan Appendix Phase G ([knowledge/10_Hex_QuadMeshing_FrameFields.md](knowledge/10_Hex_QuadMeshing_FrameFields.md) background, [knowledge/00_Overview_and_Taxonomy.md §3](knowledge/00_Overview_and_Taxonomy.md)):

**Hex8 reference shape:** $[-1, 1]^3$ with 8 corner nodes (ANSYS/ABAQUS convention):
- Nodes 0..3 = bottom face CCW (z=-1)
- Nodes 4..7 = top face CCW (z=+1) above 0..3

Shape functions:
$$N_i(\xi,\eta,\zeta) = \tfrac{1}{8}(1+\xi_i\xi)(1+\eta_i\eta)(1+\zeta_i\zeta)$$

Quadrature: $2\times2\times2$ Gauss-Legendre (8 points). Each weight = 1, Gauss coords $\pm 1/\sqrt{3}$. Sufficient for $\int B^T D B \,dV$ since $B^T D B$ is degree-2 in each ref-coordinate.

B-matrix: $6 \times 24$ per integration point, Voigt order matches theory.md §1.2.

Element stiffness: $K_e = \sum_{g=1}^{8} w_g |\det J_g| B_g^T D B_g$.

**B-bar option** for near-incompressible cases (Poisson $\nu \to 0.5$): replace dilatational part of $B$ with the volume-averaged dilatational part. Behind `params.enableHexBBar` (default true). ~30 LOC add.

**Importers:**
- `.inp` (Abaqus): parse `*Node` block (id, x, y, z) and `*Element, type=C3D8` block (id, n1..n8).
- `.vtu` (VTK): pugixml parser (header-only, add to ext), look for `<DataArray name="connectivity">` and cell-type `VTK_HEXAHEDRON=12`.
- `.msh` (Gmsh v4 ASCII): hex elements are type 5.

## Multithreading
Hex element instantiation and assembly inherit OMP-parallel-for loops from FEASolver (TODO_06/TODO_17 pattern). No new threading code.

## Numerical care points
- **Hex8 Jacobian orientation** (care-point in plan §7) — must be right-handed (nodes traversed CCW from outside). Left-handed nodes give negative $\det J$ at every Gauss point → indefinite $K_e$. Verify with `orient3d(n0, n1, n2, n4) > 0` at element load.
- **B-bar applied only to dilatational part** (care-point #7) — apply to whole $B$ produces hourglassing. Implement carefully or default to full integration.
- **Importer line endings** — handle CR-LF on Windows .inp files; some Abaqus exports use comma-space-separated, some space-only.

## Screen-visible acceptance check

**Setup** Place `assets/test_fixtures/cube_hex_2x2x2.inp` (Abaqus-format hex mesh, 8 hex elements, 27 nodes).

**Action** File menu → Open → select the .inp; clamp one face; apply tension to opposite face; click `Solve Linear Static`.

**Expected**
- Viewer renders 8 hex elements; each shown as 6 quad faces; edges in distinct colour from tets.
- Console: `[Mesh] format: Abaqus .inp   elements: Hex8:8   nodes: 27`.
- Solve converges; displacement field rendered; max displacement matches $u = F L / (A E)$ to 0.1%.
- B-bar toggle (if added): re-solve with B-bar on; for $\nu=0.3$ result barely changes; for $\nu=0.49$ result improves significantly toward analytical.

**Failure modes**
- Mesh renders as tets → importer recognised file but converted hex to 6 tets (silent fallback); check element-type dispatch.
- Solve diverges → Hex8 shape-gradient orientation wrong (left-handed vs right-handed reference).
- B-bar produces hourglassing → applied to deviatoric part too.

**Pass criterion** Hex elements visibly rendered AND solve converges AND analytical displacement within 0.1%.

## Regression sentinel
`regression/hex_cube_tension.txt` — analytical-vs-numerical displacement comparison.

## Depends on
None — independent (can run in parallel by a second developer).

## Estimated effort
4 days (importer is most of the work; element kernel is mechanical).
