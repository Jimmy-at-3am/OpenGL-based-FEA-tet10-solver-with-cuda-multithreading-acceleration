# TODO_99 — Deferred research items register

> Renamed from `TODO_MESH.md` on 2026-05-19 (+1 shift after STEP loader added at TODO_04). Slot 99 chosen so it always sorts after the active numbered chain.

Items intentionally **out of scope** of the active numbered TODO chain (`TODO_01` through `TODO_25`) but tracked so they don't get forgotten. Each entry: vault note reference, why deferred, estimated effort, prerequisites, sketch of approach.

References: [knowledge/](knowledge/) (notes 00–16) and the comprehensive plan at `C:\Users\Lenovo\.claude\plans\create-a-thorough-implementatble-hidden-scroll.md`.

---

## Hex / Polyhedral

### Sweep mesher for Hex8
- **Vault:** [knowledge/10_Hex_QuadMeshing_FrameFields.md §6](knowledge/10_Hex_QuadMeshing_FrameFields.md)
- **Effort:** ~2 weeks
- **Prereqs:** TODO_21 (Hex8 element class).
- **Why deferred:** practical only for extrudable geometries (cylinders, plates). Most user inputs won't sweep cleanly; the hex importer (TODO_21) covers the common case where users bring hex from Cubit/HexBox.
- **Sketch:** Identify source surface (lowest-DOF planar face), target surface (parallel face above), connecting lateral faces. Mesh source with quads, extrude each quad through the swept depth, snap to target. Add `SweptHexMesher::run(model, sourceFaceId, targetFaceId, divisions)`.

### Polyhedral VEM element
- **Vault:** [knowledge/07_Polyhedral_Mosaic_and_Voronoi.md §6.1](knowledge/07_Polyhedral_Mosaic_and_Voronoi.md)
- **Effort:** ~2 months
- **Prereqs:** Hex8 (TODO_21). Significant theoretical machinery.
- **Why deferred:** the user explicitly chose hex-only for the first cut; VEM is a research-grade addition not stable in commercial solvers (only ANSYS Mechanical 2023R1+ and COMSOL 6.x have experimental support).
- **Sketch:** Wachspress generalised barycentric coords + polynomial projector $\Pi^\nabla_k$ + stabilisation $S^P(v,v) \approx h^d \|v\|^2$. New `PolyhedralElement : IElement` with arbitrary node count. Wire to MPolyMesher-style topology optimisation if a polyhedral mesher gets added.

---

## Robust meshing extensions

### Multi-material via Cleaver2 / multi-material fTetWild
- **Vault:** [knowledge/09_Robust_TetWild_for_Dirty_Geometry.md §6.1](knowledge/09_Robust_TetWild_for_Dirty_Geometry.md)
- **Effort:** ~2 weeks
- **Prereqs:** TODO_14 (fTetWild). The `enableMultiMaterial` knob is already wired in TODO_14 but only passes through to fTetWild's interface; no Cleaver2 fallback.
- **Why deferred:** medical/biomechanics/battery niche; default users have single-material geometry.
- **Sketch:** add `ext/Cleaver2/` submodule; `Cleaver2Adapter::tetMultiMaterial(labelVolume, materialIds)`. Boundary-aware interface stitching across material labels.

### Isosurface stuffing for SDF / implicit / level-set input
- **Vault:** [knowledge/06_Octree_BCC_and_Isosurface_Stuffing.md §2](knowledge/06_Octree_BCC_and_Isosurface_Stuffing.md)
- **Effort:** ~1 week
- **Why deferred:** PolyFEA currently has no SDF/implicit input path. Worth adding when a use case appears (e.g. topology optimization output via SDF, medical CT).
- **Sketch:** `IsosurfaceStuffer::tetFromSDF(phi, h_target)`. BCC lattice generator + Labelle-Shewchuk stencil table (11 cases).

### Restricted-CVT surface preprocessing
- **Vault:** [knowledge/03_Surface_Meshing_Curved_Manifolds.md §4](knowledge/03_Surface_Meshing_Curved_Manifolds.md)
- **Effort:** ~1 week
- **Why deferred:** useful only when input surface quality is so poor it needs remeshing before tet meshing. fTetWild (TODO_14) handles the typical bad-input case differently (envelope-based).
- **Sketch:** Lévy-Bonneel restricted Voronoi diagram on input surface; Lloyd / L-BFGS iterations; output cleaner surface mesh for downstream TetGen/fTetWild.

---

## Mesh-generation alternative backends

### HXT backend (Gmsh's parallel frontal-Delaunay)
- **Vault:** [knowledge/05_Frontal_Delaunay_and_Advancing_Front.md §3.2](knowledge/05_Frontal_Delaunay_and_Advancing_Front.md)
- **Effort:** ~3 days
- **Why deferred:** only beneficial if TetGen becomes a throughput bottleneck on > 5 M-tet meshes. Most PolyFEA meshes are < 1 M.
- **Sketch:** `enum MeshBackend { TETGEN, FTETWILD, HXT }`. `HXTAdapter::run` calling Gmsh's standalone HXT library.

---

## Adaptive cycle alternatives

### Maubach bisection refinement (`AMR_BISECTION_MAUBACH`)
- **Vault:** [knowledge/11_Adaptive_Refinement_hp_and_DWR.md §5.1, §7.3](knowledge/11_Adaptive_Refinement_hp_and_DWR.md)
- **Effort:** ~1 week
- **Prereqs:** TODO_20 (AMR cycle).
- **Why deferred:** TODO_20 ships with `AMR_TETGEN_REGION` (simplest) and optionally `AMR_MMG3D_LOCAL` (if TODO_16 built). Maubach is more elegant — conformal, hierarchical, $O(1)$ coarsening — but the bookkeeping is non-trivial for the first cut.
- **Sketch:** longest-edge bisection with edge-marking propagation. Hierarchical refinement tree stored alongside mesh; coarsening = walking up the tree.

### Red-green refinement (`AMR_RED_GREEN`)
- **Vault:** [knowledge/11_Adaptive_Refinement_hp_and_DWR.md §5.1](knowledge/11_Adaptive_Refinement_hp_and_DWR.md)
- **Effort:** ~1 week
- **Why deferred:** alternative to Maubach; tighter shape-bound guarantees but more closure types to handle. Not necessary if Maubach lands.

### DWR goal-oriented error estimator
- **Vault:** [knowledge/11_Adaptive_Refinement_hp_and_DWR.md §4](knowledge/11_Adaptive_Refinement_hp_and_DWR.md), plan Appendix Phase F
- **Effort:** ~3 days
- **Prereqs:** TODO_20 (AMR cycle).
- **Why deferred:** ZZ-driven refinement (TODO_19+19) is sufficient for most users. DWR is highest ROI when the user cares about a specific QoI (max stress at marker, displacement at sensor, drag coefficient). Recommended addition when first such user appears.
- **Sketch:** dual problem solve (reuses primal factorisation for linear self-adjoint), $p$-enriched dual or recovery-based $z - z_h$, per-element weighted residual.

### Goal-oriented metric (combines DWR with anisotropic adapt)
- **Vault:** [knowledge/11_Adaptive_Refinement_hp_and_DWR.md §6](knowledge/11_Adaptive_Refinement_hp_and_DWR.md) — Power–Hannan 2006
- **Effort:** ~1 week
- **Prereqs:** TODO_16 (MMG3D) AND DWR estimator.
- **Why deferred:** only relevant when both anisotropic adapt and goal-oriented are present.

### hp- and p-adaptivity
- **Vault:** [knowledge/11_Adaptive_Refinement_hp_and_DWR.md §5.2, §5.4](knowledge/11_Adaptive_Refinement_hp_and_DWR.md)
- **Effort:** non-trivial (months)
- **Why deferred:** requires heterogeneous element-order infrastructure (Tet20 alongside Tet10 alongside Tet4) — significant solver refactor. Out of scope for PolyFEA's current Tet4/Tet10 dual-order setup.

### Conformal hanging-node constraint system
- **Vault:** [knowledge/11_Adaptive_Refinement_hp_and_DWR.md §7.2](knowledge/11_Adaptive_Refinement_hp_and_DWR.md)
- **Effort:** ~2 weeks
- **Why deferred:** PolyFEA's solver assumes conformal meshes; TODO_20's refinement strategies all produce conformal output. Only needed if a non-conformal octree mesher (e.g. Cleaver2-style) is added.
- **Sketch:** `ConstraintMatrix` modifies `IElement::GetGlobalDOFs` to project hanging-node DOFs onto parent-edge DOFs as a weighted linear combination.

---

## Hex/quad alternatives

### Frame-field hex meshing (HexEx / HexBox)
- **Vault:** [knowledge/10_Hex_QuadMeshing_FrameFields.md §3-4](knowledge/10_Hex_QuadMeshing_FrameFields.md)
- **Effort:** ~1 month
- **Why deferred:** TODO_21 covers hex via import (best Cubit-class quality, no in-house mesher needed). In-house frame-field hex meshing is research-grade (~80–95% success on HexMe benchmark).
- **Sketch:** add `ext/libHexEx/` and `ext/HexBox/` as submodules; `FrameFieldHexMesher::run(surfaceMesh)`.

### Quad-meshing on surfaces (Instant Meshes / QuadriFlow / MIQ)
- **Vault:** [knowledge/10_Hex_QuadMeshing_FrameFields.md §2](knowledge/10_Hex_QuadMeshing_FrameFields.md)
- **Effort:** ~2 weeks
- **Why deferred:** PolyFEA has no shell-element story yet. Add when shell elements get added.

---

## ML / Real-time

### MeshGraphNets / GNN-based AMR
- **Vault:** [knowledge/13_ML_and_Neural_Mesh_Generation.md](knowledge/13_ML_and_Neural_Mesh_Generation.md)
- **Effort:** ~1 month + GPU dep
- **Why deferred:** speculative; no certified error bound; commercial maturity is "preview" (ANSYS SimAI cloud, SimScale).
- **Sketch:** would need PyTorch C++ or ONNX runtime as ext dep. Train on a corpus of (input, ZZ-error-field) pairs; at runtime predict error field, skip the initial coarse-mesh solve.

### Real-time GPU-resident mesh ops
- **Effort:** ~1 month
- **Why deferred:** premature optimisation; current TetGen/fTetWild on CPU is adequate. Worth revisiting if PolyFEA becomes interactive (mesh adapts during user drag).

---

## CFD-specific (out of structural scope)

### ANSYS Mosaic poly-hex
- **Vault:** [knowledge/07_Polyhedral_Mosaic_and_Voronoi.md §3](knowledge/07_Polyhedral_Mosaic_and_Voronoi.md)
- **Why deferred:** CFD-only; requires polyhedral solver path (which would require VEM above).

### Voronoi BL
- **Vault:** [knowledge/07_Polyhedral_Mosaic_and_Voronoi.md §4](knowledge/07_Polyhedral_Mosaic_and_Voronoi.md)
- **Why deferred:** CFD-only feature. Structural BL (TODO_18) covers the analogous structural use case.

### CutFEM / Finite Cell methods
- **Vault:** [knowledge/06_Octree_BCC_and_Isosurface_Stuffing.md §5](knowledge/06_Octree_BCC_and_Isosurface_Stuffing.md)
- **Effort:** ~1 month
- **Why deferred:** body-fitted Tet10 is the right choice for current PolyFEA scope; embedded methods become valuable only for topology-changing simulation (crack growth, level-set shape opt).

---

## Notes on priority

The deferred items are roughly ordered above by "next likely to be requested." When prioritising:
1. **DWR** is the highest ROI single addition — turns ZZ-driven AMR into goal-oriented AMR.
2. **Maubach bisection** + coarsening unlocks transient-with-moving-features problems.
3. **Sweep mesher** is the most-requested hex feature after import.
4. **Multi-material** opens biomechanics / battery applications.

Update this file when items move to active TODOs (numbered) or land.
