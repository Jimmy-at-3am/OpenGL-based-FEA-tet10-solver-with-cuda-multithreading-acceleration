---
title: Hex and Quad Meshing — Frame Fields and PolyCubes
type: algorithm
tags: [hex-mesh, quad-mesh, frame-field, cross-field, polycube, integer-grid, instant-meshes]
created: 2026-05-16
---

# 10 — Hex / Quad Meshing via Frame Fields and PolyCubes

Hex/Quad meshes are mathematically and numerically superior to tet/tri meshes for many applications (incompressible elasticity, plates/shells, anisotropic stress recovery), but **automatic generation for arbitrary geometry remained unsolved until ~2010**. The breakthrough was the **frame-field paradigm** (Bommes 2009, Solomon 2017) — design a continuous rotational field on the surface/volume, then extract a quad/hex layout from its singularities.

This note covers (i) classical block-decomposition and sweep methods, (ii) frame-field theory, (iii) Instant Meshes (Jakob 2015) for surface quad meshing, (iv) PolyCube maps for volumetric hex meshing, and (v) the integer-grid map formulation (Bommes 2013).

---

## 1. Why Hex / Quad?

| Property | Hex / Quad | Tet / Tri |
|---|---|---|
| Convergence rate, smooth solutions | same $\mathcal{O}(h^p)$ | $\mathcal{O}(h^p)$ |
| Locking on incompressible | low (SRI, Q1P0) | high (volumetric locking) |
| Stress recovery | smooth, super-convergent | nodal-jumps |
| Memory per equivalent accuracy | 0.4× | 1× |
| Solver cost per accuracy | 0.5× | 1× |
| Automatic generation on arbitrary geometry | **hard** | easy |
| Robust software | only specific cases | universal |

The trade is decisive in shell mechanics, fatigue analysis, and incompressible elasticity, and material in CFD secondary flow regions. The 2018+ era closed much of the automation gap.

---

## 2. Classical Hex-Meshing Methods (Pre-Frame-Field)

Still in production for specific geometry classes:

| Method | Idea | Geometry class | Software |
|---|---|---|---|
| **Block decomposition** | manual partition → structured per block | revolved, swept | ICEM CFD, ANSYS Mechanical Multizone |
| **Sweep** | 2-D quad mesh extruded along axis | extrusion-like | ANSYS, COMSOL "Swept Mesh" |
| **Plastering (Blacker 1991)** | advancing-front quad on surface, then map inward | star-shaped | CUBIT |
| **Whisker weaving (Tautges 1996)** | dual chord representation | research only | — |
| **Medial-axis-based (Price 1995)** | decompose along medial sheet | tubular shapes | Hexotic |
| **Submapping (Mitchell 1995)** | constraint-based block + sweep | block-y CAD | CUBIT |

These remain useful when applicable but fail outside their geometry classes — motivating frame-field methods.

---

## 3. Frame Fields — Theory

### 3.1 Cross fields on surfaces

A **cross field** on a 2-manifold $\mathcal{S}$ is a continuous assignment of an **unordered set of four orthogonal directions** at each point (i.e. an element of $SO(2)/\mathbb{Z}_4 \cong S^1/\mathbb{Z}_4$ at each tangent plane).

Cross fields are dual to quad-meshes: every well-behaved quad mesh induces a cross field (mesh edge directions), and conversely every cross field can be integrated to produce a quad layout — except at **singularities** where the field has fractional index $\pm 1/4$. By the **Poincaré–Hopf theorem**:

$$
\sum_v \mathrm{index}(v) = \chi(\mathcal{S})/4 = \tfrac{1}{4}(V-E+F).
$$

A sphere ($\chi=2$) must therefore have eight $+1/4$ singularities — the *eight valence-3 vertices* of every quad-spherical mesh.

### 3.2 Frame fields in 3-D

A **3-D frame field** is a smooth field of orthonormal triples (modulo the octahedral group $\mathcal{O}_h$, order 24). Singular structures:

- **Lines (1-D)** along which the frame "twists" — corresponding to **irregular hex edges**.
- **Junctions** where multiple singularity lines meet — irregular hex vertices.

The classification of allowable singularities in 3-D is far more complex than in 2-D (Liu et al. 2018); only certain index combinations admit a hex-mesh.

### 3.3 Computing a smooth frame field

Solve the optimisation:

$$
\min_{f:\Omega\to\mathcal{O}_h} \int_\Omega \|\nabla f\|^2 \,dx + \lambda \sum_{\partial\Omega} (\text{boundary alignment})^2,
$$

with the discrete unknown $f$ on tet/voxel grid vertices. The lifting from $\mathcal{O}_h$ to a continuous representation uses **spherical harmonics of degree 4** (Huang 2011): each frame is encoded as a 9-vector in $\mathbb{R}^9$, and the energy becomes quadratic.

Result: a smooth field with optimal-position singularities; the heavy lift is then **parametrising** the singular-structure-respecting domain into a 3-D grid.

---

## 4. Instant Meshes (Jakob et al., SIGGRAPH 2015)

Instant Meshes is the practical answer for **surface quad-meshing of arbitrary triangle meshes**:

```text
INPUT: triangle mesh M of a 2-manifold
OUTPUT: pure quad (or quad-dominant) mesh M_q

1. EXTRINSIC orientation field via Iterative averaging:
     for each vertex v, average rotation operator over 1-ring,
     reproject onto SO(3) (cross product re-orthogonalisation).
2. POSITION field, also via iterative averaging:
     each vertex stores a (u,v) offset within its local frame;
     averaging round-robin with neighbours yields a smooth position field.
3. ROOSTING (the key trick): both fields converge in O(few iterations)
     because the energy is convex modulo the symmetry group.
4. EXTRACTION:
     follow the (u,v) integer iso-lines on M to harvest quad faces.
     singularities of the orientation field become valence-3 / valence-5 vertices
     in the output quad mesh.
```

**Speed:** ~10 s for a 1M-triangle input on a workstation; 100× faster than prior frame-field methods (Bommes 2009, Knöppel 2013).

**Quality:** pure-quad output on 95% of inputs; quad-dominant on the rest with $<5\%$ triangles.

**Limitations:** does not respect sharp features or anisotropic sizing well; for those use the original Bommes 2013 integer-grid maps (§5).

---

## 5. Integer-Grid Maps (Bommes 2013) — The Rigorous Surface-Quad Pipeline

The "mathematically pure" surface-quad approach:

```text
1. SOLVE for a smooth cross field on M (mixed-integer formulation).
2. PARAMETRIZE M by a global function f: M → ℝ² such that the gradient
   ∇f aligns with the cross field everywhere (subject to integer
   transition jumps across cut lines).
3. The resulting (u,v) map has the property that integer iso-lines
   {u = i, v = j} form a quad mesh on M when lifted back.
4. EXTRACT and clean (remove non-manifold artifacts at singularities).
```

The "mixed-integer" optimisation in step 1 is **NP-hard** in general but admits very effective heuristics; Bommes et al. provide a $\mathcal{O}(n^{1.5})$ algorithm that succeeds on most inputs.

**Relationship to Instant Meshes:** Instant Meshes is the *non-rigorous* version — same final goal, much faster, no global parametrisation, no anisotropy.

---

## 6. PolyCube Maps — Volumetric Hex Meshing

For **3-D hex meshing**, the canonical approach is:

```text
1. POLYCUBE CONSTRUCTION:
     a. Compute a deformation D: ∂Ω → ∂P where P is an axis-aligned
        polycube (union of axis-aligned hexahedra in some scaled grid).
     b. P should have the same topology as Ω and a low number of corners.
2. VOLUMETRIC MAP:
     extend D to the interior via harmonic / inversion-free map.
3. HEX EXTRACTION:
     P is trivially hex-meshable (grid). Pull the grid back through D⁻¹
     to get hex elements in Ω.
4. SMOOTHING:
     ODT-style hex smoothing to fix near-corner distortion.
```

Key works:
- Gregson et al. 2011 — first robust polycube algorithm.
- Livesu et al. 2013 — interactive polycube construction.
- Fang et al. 2016 — automatic polycube via integer optimisation.

**Limitation:** the polycube construction inflates the corner count in geometries with many local features, and the inversion-free volumetric extension can fail. Robust hex meshing of arbitrary CAD is still **an open problem** in 2025.

---

## 7. Hybrid and "Hex-Dominant" Meshes

When pure-hex fails, modern tools fall back to **hex-dominant** outputs: hex cells where possible, pyramids + tets to fill the remainder. Standard pipeline:

```text
1. Frame-field-driven structured hex generation in the geometry interior.
2. Tetrahedral / Frontal-Delaunay fill of the residual void.
3. Pyramid transition cells at hex-tet interfaces.
4. ODT smoothing across the whole mesh.
```

Tools: **CUBIT** (Sandia), **OCTREE** (Marechal 2009), **HXT** (Marot 2018 — fastest open-source hex-dominant).

---

## 8. Software Status (2024)

| Tool | Surface quad | Volumetric hex | Notes |
|---|---|---|---|
| **Gmsh 4.13** | Frontal-Delaunay + quasi-structured | hex-dominant via Marot HXT | open source |
| **CUBIT 15+** | plastering, submapping | sweep, multi-block, Hex-O-Mesh | Sandia, closed |
| **ANSYS Workbench** | "Quad Dominant" sweep | Multizone, sweep, hex-dominant | mature |
| **COMSOL 6.3** | swept + boundary layer | mainly swept; experimental hex-dom | mature |
| **Trelis** | CUBIT commercial fork | same as CUBIT | Coreform |
| **Instant Meshes** | yes (surface) | no | research / 3-D-printing |
| **fHEX (Liu 2018)** | — | research hex from frame fields | open source |

---

## 9. The Open Frontier (2020–2025)

- **Provably correct hex from frame fields**: Liu, Solomon et al. — verified topology recovery (2018–2024).
- **Neural frame fields**: learned cross fields with smoother singularity placement (Bohn et al. 2024). See [[13_ML_and_Neural_Mesh_Generation]].
- **Hex meshing of non-orientable manifolds**: still partially open.

---

## 10. References

- D. Bommes, H. Zimmer, L. Kobbelt, "Mixed-integer quadrangulation," *ACM TOG (SIGGRAPH)* 28, 2009.
- W. Jakob, M. Tarini, D. Panozzo, O. Sorkine-Hornung, "Instant Field-Aligned Meshes," *ACM TOG (SIGGRAPH Asia)* 34, 2015.
- D. Bommes, M. Campen, H.-C. Ebke, P. Alliez, L. Kobbelt, "Integer-grid maps for reliable quad meshing," *ACM TOG (SIGGRAPH)* 32, 2013.
- F. Knöppel, K. Crane, U. Pinkall, P. Schröder, "Globally optimal direction fields," *ACM TOG (SIGGRAPH)* 32, 2013.
- J. Huang, Y. Tong, H. Wei, H. Bao, "Boundary aligned smooth 3D cross-frame field," *ACM TOG (SIGGRAPH Asia)* 30, 2011.
- J. Solomon, A. Vaxman, D. Bommes, "Boundary element octahedral fields in volumes," *ACM TOG* 36, 2017.
- M. Livesu, N. Vining, A. Sheffer, J. Gregson, R. Scateni, "PolyCut: monotone graph-cuts for PolyCube base-complex construction," *ACM TOG (SIGGRAPH Asia)* 32, 2013.
- C. Marot, J. Pellerin, J.-F. Rémacle, "One machine, one minute, three billion tetrahedra," *IJNME* 117, 2019.
- Annotated list in [[15_References_Bibliography]].
