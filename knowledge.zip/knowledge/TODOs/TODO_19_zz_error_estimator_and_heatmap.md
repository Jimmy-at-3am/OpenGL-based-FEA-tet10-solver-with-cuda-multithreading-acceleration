# TODO_19 — ZZ error estimator + per-element heatmap

## Goal
After a solve, compute Zienkiewicz-Zhu (ZZ) per-element error indicators via SPR-recovered stress; visualise as a heat-map overlay (`E` key). Foundation for TODO_20 (AMR cycle).

## Files added / modified
- **Add** `include/ZZRecovery.h`, `src/ZZRecovery.cpp`.
- **Modify** `include/FEAModel.h` — store `std::vector<double> elementErrorEta`, `nodalStressStar`.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — `E` key toggle.
- **Modify** `src/ShaderSources.h` — per-element scalar overlay (reuses HUD shader path from TODO_05).

## Algorithm summary
From [knowledge/11_Adaptive_Refinement_hp_and_DWR.md §2](knowledge/11_Adaptive_Refinement_hp_and_DWR.md) and plan Appendix Phase E.1, E.2:

**SPR — Superconvergent Patch Recovery (per-node stress):**
```text
Build vertex->elements adjacency (parallel)
For each corner node n (skip Tet10 mid-edge nodes initially):
    Patch P_n = elements incident on n
    For each Gauss point gp in P_n: compute sigma_h(gp) = D * B(gp) * u_e (Voigt 6-comp)
    For each stress component c in {sxx, syy, szz, txy, tyz, txz}:
        Fit polynomial p_c(x,y,z) of degree = element-order:
            degree 1 for Tet4, degree 2 for Tet10
        Solve a = (Phi^T Phi)^-1 Phi^T sigma_h^(c)
        sigma_star_n[c] = p_c(x_n, y_n, z_n)
For mid-edge nodes (Tet10): average sigma_star from the two endpoint nodes
For boundary nodes: average from incident interior-node patches (boundary-aware)
```

**ZZ element indicator:**
```text
For each element T (parallel):
    sigma_star_at_gauss = interpolate sigma_star to T's Gauss points via shape functions
    sigma_h_at_gauss    = D * B(gp) * u_e   (from stored solution)
    eta_T^2 = sum_gp w_g * |det J_g| * (sigma_star - sigma_h)^T * D^-1 * (sigma_star - sigma_h)
elementErrorEta[T] = sqrt(eta_T^2)
```

Heatmap: same shader pattern as TODO_05 (Quality HUD), but coloured by `elementErrorEta` (log scale, since the error spans orders of magnitude near singularities).

## Multithreading
- Vertex-element adjacency: parallel-for, output is per-vertex (no shared write).
- SPR per node: `#pragma omp parallel for schedule(dynamic, 64)`. Each patch ≤ 20 dofs → fast.
- ZZ per element: parallel-for; thread-local accumulators not needed (each element writes only its own `eta_T`).

## Numerical care points
- **ZZ on Tet10** (care-point #8): SPR patch uses Gauss-point stresses (not nodal stresses, which Tet10 doesn't have until SPR runs). Fit a quadratic to capture Tet10's linear strain field.
- **Boundary patches** (care-point #3): polynomial bases degenerate when patch is one-sided. Average from incident interior-patch neighbours.
- Numerical floor on `eta_T`: clamp to `1e-30` before passing to log-scale colormap; otherwise `log(0) = -inf` corrupts the visualisation.

## Screen-visible acceptance check

**Setup** Mesh `assets/test_fixtures/lshape.stl` (re-entrant L-shaped 2D-extruded part); click `Solve Linear Static`.

**Action** Press `E` (error heatmap toggle).

**Expected visible**
- Per-element overlay: rainbow heat-map with red concentrated at the re-entrant corner; blue/green in the body.
- Console: `[ZZ] η_global = 2.41e-3   max η_T = 4.7e-4 at elem 829 (re-entrant corner)`.

**Failure modes**
- Uniform colour → ZZ indicator constant (e.g. SPR returned $\sigma^* = \sigma_h$).
- Red everywhere → indicator normalisation wrong (per-element vs. global).
- Hot spot in wrong location → wrong stress component recovered, or wrong constitutive matrix in error norm.

**Pass criterion** Visible spatial concentration at the singularity; max element matches expected location.

## Regression sentinel
`regression/zz_lshape.txt` — η_global + max-η element coords for L-shape.

## Depends on
TODO_05 (HUD overlay shader). Benefits from TODO_15 (SPR helper code).

## Estimated effort
3 days.
