# TODO_12 — Sizing-field-driven TetGen call

## Goal
Pass per-vertex sizing field (TODO_11) to TetGen via the `-m` switch, so curved regions get denser tets and flat regions stay coarse. Visible refinement gradient in the viewer.

## Files added / modified
- **Modify** `src/FEAModel.cpp::generateVolumetricMesh()` lines 514–548 — populate `in.pointmtrlist` from `sizingPerVertex`; append `m` to switches.
- **Modify** `include/FEAData.h` — `params.enableCurvatureSizing` default `true` after this lands.

## Algorithm summary
From plan Appendix Phase C.3:

```cpp
if (params.enableCurvatureSizing) {
    in.numberofpointmtrs = 1;
    in.pointmtrlist = new REAL[in.numberofpoints];
    for (size_t i = 0; i < surfaceVertices.size(); ++i)
        in.pointmtrlist[i] = sizingPerVertex[i];
}
// switches string: append "m"
snprintf(switches + strlen(switches), ..., "m");
```

TetGen reads `pointmtrlist` when `m` is in the switch string; uses inverse-distance interpolation to derive per-tet target volume from the per-vertex sizing values.

## Multithreading
The sizing-field computation (TODO_11) is already parallel. The TetGen call itself is serial inside TetGen; PolyFEA simply hands off the array.

## Numerical care points
- TetGen expects sizing in absolute units (same as point coordinates), not ratios — `sizingPerVertex[i]` from TODO_11 is already absolute (in metres, scaled to bbox).
- `pointmtrlist` must be heap-allocated with `new REAL[...]`, NOT `malloc` — TetGen frees it with `delete[]`.
- If `numberofpointmtrs = 0`, TetGen ignores `pointmtrlist` even if non-NULL. Must set both.

## Screen-visible acceptance check

**Setup** Load `assets/test_fixtures/curvy_bracket.stl` (mixed flat + curved regions).

**Action** Enable curvature sizing in params panel; click `Generate 3D Mesh`.

**Expected**
- Visual: viewer shows visibly higher tet density on curved regions (small fillets, holes) vs. flat planes.
- Console:
  ```text
  [Sizing] h_min=2.1e-3 h_max=4.8e-2 ratio=22.9
  [Sizing] nodes in high-curvature (h<5e-3): 4218  low-curvature (h>2e-2): 1872
  ```
- Quality report (TODO_01) still PASS.

**Failure modes**
- Uniform density → `-m` switch not appended to TetGen call or `pointmtrlist` not populated.
- All nodes in "high-curvature" bucket → sizing field clamped wrong way.
- Quality regresses → sizing too aggressive for `tetQuality` ratio; loosen one or the other.

**Pass criterion** Density ratio $\ge 3$ between curved and flat regions; quality still PASS.

## Regression sentinel
`regression/sizing_curvy.txt` — node-count breakdown by sizing bucket on `curvy_bracket.stl`.

## Depends on
TODO_11.

## Estimated effort
1 day (mostly verification + tuning defaults).
