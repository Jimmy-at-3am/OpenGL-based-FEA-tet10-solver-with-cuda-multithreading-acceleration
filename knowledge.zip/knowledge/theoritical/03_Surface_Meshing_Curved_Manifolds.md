---
title: Surface Meshing on Curved Manifolds
type: algorithm
tags: [surface, manifold, parametrization, restricted-cvt, curvature, nurbs, brep]
created: 2026-05-16
---

# 03 — Surface Meshing on Curved Manifolds

This note covers all algorithms that produce a 2-D triangular (or quad) mesh **of a surface $\mathcal{S}$** sitting in $\mathbb{R}^3$. The surface may be:

1. **Smooth $C^k$ manifold** — analytic, B-spline, subdivision, or implicit.
2. **CAD B-rep** — piecewise $C^k$ with explicit feature graph (vertices, ridges, faces).
3. **Discrete mesh** — input triangle soup that we want to **remesh** for higher quality.

Two algorithmic philosophies dominate:

- **Parametric (extrinsic → 2-D)**: build a flattening $\varphi:\mathcal{S}\to\Omega^*\subset\mathbb{R}^2$, mesh $\Omega^*$ with a 2-D Delaunay-type mesher, lift the result back. Requires cutting if $\mathcal{S}$ is closed.
- **Intrinsic (work directly on $\mathcal{S}$)**: never flatten; mesh through **Restricted Voronoi Diagrams** or particle systems on the surface. No cuts; handles any topology.

The modern method of choice for free-form curved manifolds is **Restricted CVT** (Yan–Lévy 2009/2010), discussed in §4.

Cross-refs: parametrization energies generalise the LSCM / ABF / SCP family used in mesh deformation and texture mapping; restricted CVT relies on the foundations in [[01_Mathematical_Foundations]] §2 and §5.

---

## 1. Sizing Field Construction

Before any algorithm runs, a **sizing field** $h(x):\mathcal{S}\to\mathbb{R}_{>0}$ — prescribing local edge length — must be computed. It is driven by:

### 1.1 Curvature sizing

For a surface with principal curvatures $\kappa_1,\kappa_2$:

$$
h_{\kappa}(x) = \frac{2\,\sin(\theta_{\max}/2)}{\max(|\kappa_1(x)|, |\kappa_2(x)|)}, \qquad
h_{\kappa}(x) = \frac{\delta_{\max}}{\max(|\kappa_1|,|\kappa_2|)}\sqrt{8},
$$

where $\theta_{\max}$ is the maximum allowed normal deviation per element (typical: $15°$–$30°$) and $\delta_{\max}$ the maximum sagitta (chord-deviation, typical $10^{-3}L_{\text{diag}}$). The two formulae are equivalent under the chordal-error model. COMSOL exposes this as *Resolution of curvature*, ANSYS Fluent Meshing as *Curvature size function*, Gmsh as `MeshSizeFromCurvature`.

### 1.2 Local feature size (LFS)

$$
\mathrm{lfs}(x) = \mathrm{dist}(x, \mathrm{MA}(\mathcal{S})),
$$

where $\mathrm{MA}(\mathcal{S})$ is the medial axis. Sampling at $h(x) = K\,\mathrm{lfs}(x)$ with $K<1$ guarantees the **$\varepsilon$-sample** condition (Amenta–Bern 1998) under which the restricted Delaunay triangulation is topologically faithful. In practice, LFS is approximated by **the Voronoi pole distance** (Amenta–Choi 2001).

### 1.3 Gradient-graded sizing

Once a target field $h_0(x)$ is identified, enforce a smoothness constraint to avoid jumps between adjacent elements:

$$
|\nabla \log h(x)| \le \alpha, \qquad \alpha\in[0.2,\,0.4]\text{ typ.}
$$

This is the **gradation parameter** — COMSOL `hgrad`, MATLAB `Hgrad`, Gmsh `MeshSizeFactor`. The graded field is obtained by solving the eikonal

$$
\|\nabla h\|_\infty \le \alpha
$$

via fast-marching on the surface (Persson 2006).

---

## 2. Parametric Surface Meshing (Classical, Robust for B-rep Faces)

Used inside Gmsh, OpenCASCADE, and the OCC-based CAD kernels. Workflow:

```text
For each face F of the B-rep:
  1. Compute the parameter-space chart  phi : F -> Omega* (2-D)
  2. Pull back the sizing field   h*(u,v) = h(phi(u,v)) / |J_phi(u,v)|
  3. Pull back the metric  M*(u,v) = I_phi(u,v) (first fundamental form)
  4. Mesh Omega* with an anisotropic 2-D Delaunay refiner (BAMG / Triangle-like)
  5. Lift vertices back: x_i = phi(u_i, v_i)
  6. Snap shared edges between adjacent faces (sew step)
```

### 2.1 Anisotropy in parameter space

Because $\varphi$ is generally not isometric, an isotropic mesh of $\Omega^*$ produces a *stretched* mesh on $\mathcal{S}$. The remedy is to mesh in $\Omega^*$ under the **first fundamental form** $\mathbf{I}_\varphi$:

$$
\text{edge length on }\mathcal{S} = \int_0^1 \sqrt{(u_q-u_p)^T \mathbf{I}_\varphi\,(u_q-u_p)}\,dt
$$

so the 2-D mesher uses $\mathbf{I}_\varphi$ as its (location-dependent) metric. This is exactly the **BAMG** approach (Hecht 2006) used by Gmsh's `Frontal-Delaunay for Quads` and `MeshAdapt` algorithms — see [[05_Frontal_Delaunay_and_Advancing_Front]].

### 2.2 Sewing across face boundaries

Adjacent B-rep faces $F_1,F_2$ share a 1-D edge $E$. Each face is meshed independently, so $E$ must be:

1. **Pre-discretised** on its own: a 1-D edge mesh is generated *first* (curvature-driven, gradation-respecting) and **frozen**.
2. **Used as a boundary constraint** when meshing each $F_i$ in parameter space (preserved by the CDT property).
3. **Verified** afterwards for matching node-by-node: the lift $\varphi_{F_i}$ must reproduce the frozen 1-D edge mesh exactly.

This is the standard pipeline in OpenCASCADE, Salomé, and ANSYS SpaceClaim. Failure modes: missing edges, periodic seams, degenerate edges at poles (UV-sphere singularities).

> [!warning] Periodic and degenerate parameters
> A UV-sphere parametrisation has degenerate poles (the whole $v=0$ line in UV maps to one point). Pure parametric meshing collapses elements there. Workaround: use **N-pole splitting** (CGAL) or switch to **intrinsic restricted CVT** (§4).

---

## 3. Discrete Parametrization (when no analytic chart exists)

Given a triangle-soup surface, build $\varphi$ numerically. Four canonical methods:

### 3.1 Tutte 1963

Solve a Laplace equation with fixed convex boundary:

$$
\sum_{j\in\mathcal{N}(i)} w_{ij}\,(\varphi_j-\varphi_i) = 0, \qquad \varphi|_{\partial}=\text{convex polygon}.
$$

Bijective (Tutte's theorem). Fast and robust but produces large distortion.

### 3.2 LSCM — Least-Squares Conformal Maps (Lévy 2002)

Minimise the Cauchy–Riemann residual

$$
E_{\mathrm{LSCM}} = \int_{\mathcal{S}} \left|\nabla \varphi_u - J\nabla\varphi_v\right|^2 dA,
$$

with $J$ the $90°$ rotation in the tangent plane. Two-point boundary fix; angle-preserving; sparse linear solve. Used by Maya, Blender, and Open Surface Mesh Parameterization libraries.

### 3.3 ABF / ABF++ (Sheffer 2001/2005)

Reformulate around **angles** rather than positions; enforce triangle inequality + global validity via Lagrangian. Best angle distortion; nonlinear solve but small (one angle per corner).

### 3.4 SCP — Spectral Conformal Parametrization (Mullen 2008)

The smallest non-trivial eigenvector of the conformal Laplacian gives a free-boundary conformal map. Most stable for highly curved meshes; one sparse eigenvalue solve. **Default in modern remeshers** (e.g. Instant Meshes, see [[10_Hex_QuadMeshing_FrameFields]]).

### 3.5 Distortion-bounded BFF (Sawhney–Crane 2017)

The **Boundary First Flattening** method gives interactive control over boundary shape while remaining a single linear solve. Used in modern CAD repair toolchains.

---

## 4. Restricted CVT (RCVT) — the Modern Default for Smooth Manifolds

When $\mathcal{S}$ is given as a (possibly noisy, possibly topologically complex) triangle soup or an implicit, the parametric path is brittle. **RCVT** sidesteps it by working intrinsically.

### 4.1 Restricted Voronoi Diagram

For sites $\{x_i\}\subset\mathbb{R}^3$ and surface $\mathcal{S}$:

$$
V_i|_{\mathcal{S}} = V_i \cap \mathcal{S}.
$$

The dual is the **restricted Delaunay triangulation** $\mathrm{Del}|_{\mathcal{S}}$. Edelsbrunner–Shah (1997) proved that for an $\varepsilon$-sample with $\varepsilon<0.1\,\mathrm{lfs}$, $\mathrm{Del}|_{\mathcal{S}}$ is a triangulation of $\mathcal{S}$ homeomorphic to it.

### 4.2 RCVT energy and Lloyd iteration

The CVT energy ([[01_Mathematical_Foundations]] §5) restricted to $\mathcal{S}$:

$$
\mathcal{F}_{\mathcal{S}}(\{x_i\}) = \sum_i \int_{V_i|_{\mathcal{S}}} \rho(x)\,\|x-x_i\|^2\,dA.
$$

Lloyd update: project the centroid of $V_i|_{\mathcal{S}}$ back onto $\mathcal{S}$:

$$
x_i^{(k+1)} = \Pi_{\mathcal{S}}\!\left(\frac{\int_{V_i^{(k)}|_{\mathcal{S}}} \rho x\,dA}{\int_{V_i^{(k)}|_{\mathcal{S}}} \rho\,dA}\right).
$$

Lloyd is slow; **L-BFGS on $\mathcal{F}_{\mathcal{S}}$** (Liu et al. 2009, Yan 2009) achieves super-linear convergence and is the recommended solver.

### 4.3 Computing the RVD efficiently — Lévy–Bonneel 2012

Naive RVD computation is $\mathcal{O}(n^2)$. Lévy–Bonneel propagate Voronoi cells through the mesh of $\mathcal{S}$ via a **breadth-first surface walk**, giving $\mathcal{O}(n\log n)$ amortised — the foundation of the **Geogram** library and of Gmsh's surface-CVT remesher.

### 4.4 Sizing-field RCVT

To encode the sizing field $h(x)$, use density $\rho(x)=h(x)^{-d}$ (so denser sites where $h$ is small). Equivalent for anisotropy: use the metric $M(x) = h(x)^{-2}\mathbf{I}$ in an **anisotropic** restricted Voronoi diagram — see [[08_Anisotropic_Metric_Adaptation]] §3.

### 4.5 Pseudocode

```text
input: surface S, target node count N, sizing field h(x) (or default)
1. Initialise sites x_1,...,x_N by Poisson-disk sampling on S
2. repeat until ||grad F_S|| < tol:
       a. Compute RVD(x_i) by Levy-Bonneel surface walk
       b. Compute centroids c_i and gradient g_i of F_S
       c. Take an L-BFGS step on x_i, project to S
3. Output Del|_S as the triangulation
```

### 4.6 Properties

- **No cuts, no UV singularities, any topology** (genus, multiple components, non-manifold patches once filtered).
- **Provably converges to a critical point of $\mathcal{F}_{\mathcal{S}}$**.
- Produces **isotropic, equilateral-dominant triangles** with $\rho_T>0.7$ typical.
- Adapts to curvature via $\rho(x)$.
- Used in Geogram, OpenVolumeMesh, MeshLab (`Surface Reconstruction → Poisson-disk sampling + Reconstruct`).

---

## 5. NURBS / CAD B-rep — Practical Recipe

For an industrial STEP file (typical scenario in COMSOL / ANSYS Workbench / SOLIDWORKS Simulation):

```text
1. Parse the B-rep into  (V_corner, E_ridge, F_face)
2. For each edge in E_ridge:
     - Build 1-D curvature-driven sizing on its NURBS curve
     - Discretise it with a frozen 1-D mesh, snap to corner vertices
3. For each face in F_face:
     - Pull back metric and sizing into (u,v) parameter space
     - Insert frozen boundary discretisation as CDT constraints
     - Run anisotropic 2-D Frontal-Delaunay (BAMG)
     - Lift result back via S(u,v)
4. Sew along shared edges (verify node-matching, fix tolerance issues)
5. Globally smooth with surface CVT (a few Lloyd / L-BFGS iterations) while
   projecting back to S after every move
6. Verify Hausdorff and normal-deviation thresholds; loop if needed
```

This is essentially the algorithm used by Gmsh, OpenCASCADE, and the ANSYS surface mesher; COMSOL uses a closely related "frontal-Delaunay surface mesher" in 6.x.

---

## 6. Feature Preservation (Sharp Edges and Corners)

A piecewise-smooth surface has $C^0$ but not $C^1$ ridges. Two strategies for preserving them:

### 6.1 Constrain-then-mesh (CAD-style)

Identify the feature graph $\mathcal{G}$ explicitly. Mesh ridges first (1-D), then mesh faces with those as constraints. Robust if the B-rep is clean.

### 6.2 Feature detection on discrete input

For a triangle soup, detect ridges as edges where the **dihedral angle** exceeds a threshold (default $30°$); detect corners as vertices on $\ge2$ ridges. Tag them and constrain RCVT to keep at least one site on each ridge and at each corner. Used by MMG2/3 (`-ar 30 -nr` options) and Gmsh's `ClassifySurfaces`.

> [!tip] When detection is unreliable
> For scanned or noisy inputs, **CGAL's Feature-Aware Surface Mesh Generator** (Boissonnat–Oudot 2005) computes a *protected ball cover* of all features, guaranteeing they survive refinement. This is the most rigorous approach and the one used in CGAL 6.0's `Mesh_3` package.

---

## 7. Comparison Summary

| Method | Best for | Robustness | Quality | Cost |
|---|---|---|---|---|
| **Parametric (UV) + 2-D Delaunay** | clean B-rep with bounded distortion | high | high (with anisotropy) | $\mathcal{O}(n\log n)$ |
| **Tutte / LSCM + Delaunay** | discrete disk-topology meshes | medium | medium | $\mathcal{O}(n)$ solve |
| **SCP / BFF + Delaunay** | discrete with high curvature | high | high | one eigen / linear solve |
| **Restricted CVT** | any topology, smooth manifold | very high | very high | $\mathcal{O}(nk\log n)$ |
| **CGAL Feature-Aware Mesh_3** | dirty input with features | highest | high | $\mathcal{O}(n\log n)$ |
| **MMG2/3 anisotropic** | adaptive remeshing of FEA surface | high | very high | $\mathcal{O}(n)$ per cycle |

---

## 8. References

- B. Lévy, S. Petitjean, N. Ray, J. Maillot, "Least-Squares Conformal Maps for Automatic Texture Atlas Generation," *SIGGRAPH* 2002.
- D.-M. Yan, B. Lévy et al., "Isotropic Remeshing with Fast and Exact Computation of Restricted Voronoi Diagram," *SGP* 2009.
- D.-M. Yan, B. Lévy, "Efficient Computation of Clipped Voronoi Diagram for Mesh Generation," *Computer-Aided Design* 45, 2013.
- Y. Liu, W. Wang, B. Lévy et al., "On Centroidal Voronoi Tessellation — Energy Smoothness and Fast Computation," *ACM TOG* 28(4), 2009.
- B. Lévy, N. Bonneel, "Variational Anisotropic Surface Meshing with Voronoi Parallel Linear Enumeration," *IMR* 2012.
- J.-D. Boissonnat, S. Oudot, "Provably good sampling and meshing of surfaces," *Graphical Models* 67, 2005.
- A. Sheffer, B. Lévy, M. Mogilnitsky, A. Bogomyakov, "ABF++: Fast and Robust Angle-Based Flattening," *ACM TOG* 24(2), 2005.
- C. Dapogny, C. Dobrzynski, P. Frey, "Three-dimensional adaptive domain remeshing, implicit domain meshing, and applications to free and moving boundary problems," *J. Comput. Phys.* 262, 2014. (MMG3D)
- ANSYS Fluent Meshing 2024 R2 User's Guide §"Curvature and Proximity Size Functions".
- COMSOL 6.3 Reference Manual §"Free Tetrahedral / Free Triangular".
