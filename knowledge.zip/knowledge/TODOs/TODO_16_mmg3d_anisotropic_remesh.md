# TODO_16 — MMG3D anisotropic remesh

## Goal
Hand the metric field (TODO_15) to MMG3D's local-operator loop. Result: tets stretched along stress directions in concentrators; far field stays roughly equilateral.

## Files added / modified
- **Add** `include/MMG3DAdapter.h`, `src/MMG3DAdapter.cpp`.
- **Add** `ext/mmg/` as `FetchContent` from https://github.com/MmgTools/mmg (pin SHA).
- **Modify** `CMakeLists.txt` — MMG dep, set `LIBMMG3D_STATIC ON`, link to `FEAPreProcessor`.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — `Remesh Anisotropic` button.
- **Modify** `include/MeshQuality.h`, `src/MeshQuality.cpp` — add metric-aware `q_M` quality computation for adapted-mesh reporting (note [[02_Mesh_Quality_Metrics]] §4).

## Algorithm summary
From [knowledge/08_Anisotropic_Metric_Adaptation.md §3-4](knowledge/08_Anisotropic_Metric_Adaptation.md) and plan Appendix Phase D.4:

```text
MMG3DAdapter::remesh(model, metric, params):
    MMG5_pMesh, MMG5_pSol  // MMG's internal types
    MMG3D_loadMesh from PolyFEA arrays (in-memory, not file):
        vertex coords, tet connectivity, boundary face tags
    MMG3D_loadSol with per-vertex 3x3 metric (Voigt-packed)
    MMG3D_Set_iparameter(MMG3D_IPARAM_aniso, 1)
    MMG3D_Set_iparameter(MMG3D_IPARAM_verbose, 5)
    MMG3D_Set_dparameter(MMG3D_DPARAM_hgrad, params.sizingGradation)
    MMG3D_Set_dparameter(MMG3D_DPARAM_hausd, params.fTetWildEnvelopeRatio * L_diag)
    MMG3D_mmg3dlib(mesh, sol)
    extract back to model.originalVolumetricPositions + model.tetrahedra
    invalidate model.tetrahedraQuadratic (force regen of Tet10 via generateMidEdgeNodes)
```

MMG3D internally runs its 4-step local-operator loop (split, collapse, swap, smooth) ([knowledge/08_Anisotropic_Metric_Adaptation.md §3.2](knowledge/08_Anisotropic_Metric_Adaptation.md)).

## Multithreading
- MMG3D is sequential internally (v5.7); not parallelised. Wrap call in AsyncTask (TODO_13) for UI responsiveness.
- The metric-aware quality report `q_M` after remesh is per-tet parallel-for.

## Numerical care points
- **Per-vertex metric** must be **SPD on every vertex** (no zero eigenvalues), otherwise MMG3D fails opaquely. Floor smallest eigenvalue at `(h_max)^(-2)` and clamp aspect ratio to `params.anisotropicMaxAspect` *before* handing off.
- **Boundary tags** must be preserved through the MMG round-trip — set MMG's `MMG3D_Set_meshSize` boundary-triangle count + tag each surface triangle.
- Inversions: MMG should handle them but log a warning if `MMG3D_outputMeshNumber` shows ill-shaped output.

## Screen-visible acceptance check

**Setup** Run TODO_15 setup through solve + metric visualisation.

**Action** Click `Remesh Anisotropic`.

**Expected**
- Progress bar: `MMG3D stage 1/4 ... 4/4`.
- Result viewer: tetrahedra near the hole are visibly stretched/elongated; far-field tets remain roughly equilateral.
- Console: `[MMG] aspect ratio histogram: median 1.4   p95 8.7   max 32   nodes: 1247 → 982`.
- Quality report on the new mesh: $q_M$ histogram shown (anisotropic quality), not Knupp.

**Failure modes**
- MMG returns same mesh → metric not transferred (file format error or wrong sol type).
- All elements elongated → metric not gradation-clamped; log-Euclidean smoothing missing.
- Inversions reported → MMG3D's internal validity not configured; check `MMG3D_IPARAM_aniso = 1`.

**Pass criterion** Aspect ratio $\ge 5$ visible at hole; far-field $\le 2$; node count within $\pm 30\%$ of target.

## Regression sentinel
`regression/mmg_cantilever.txt` — aspect ratio histogram + node count delta.

## Depends on
TODO_13, TODO_15.

## Estimated effort
3 days (MMG CMake integration is the bulk; library API is clean once linked).
