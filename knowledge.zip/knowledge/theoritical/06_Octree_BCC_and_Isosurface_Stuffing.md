---
title: Octree, BCC Lattice, and Isosurface Stuffing
type: algorithm
tags: [octree, bcc, isosurface, implicit, sdf, dual-contouring, finite-cell, cutfem]
created: 2026-05-16
---

# 06 — Octree, BCC Lattice, and Isosurface Stuffing

This note covers the **implicit / level-set / image-based** geometry class — domains defined by a signed distance function $\phi(\mathbf{x})\le0$, a segmentation, or a CSG tree. Three algorithm families dominate:

1. **Isosurface stuffing on a BCC lattice** (Labelle–Shewchuk 2007) — provably good tet meshing from any SDF.
2. **Octree dual contouring + tet-stuffing** (Schaefer–Warren 2002, Ju 2002) — sharp-feature reproduction.
3. **Embedded / fictitious-domain methods** (Finite Cell, CutFEM) — skip body-fitted meshing entirely.

Cross-refs: foundations in [[01_Mathematical_Foundations]] §1; for image-domain meshing see also COMSOL's *Image Import* workflow ([[14_Software_Comparison_Matrix]]).

---

## 1. Body-Centered Cubic (BCC) Lattice

The BCC lattice is the union of two interpenetrating cubic lattices offset by $(\tfrac{1}{2},\tfrac{1}{2},\tfrac{1}{2})$. Its Voronoi cell is the **truncated octahedron**; its Delaunay tetrahedralization is **regular and isotropic**, with every tet having $\theta_{\min}=\arccos(1/3)$ and aspect ratio $\rho_T = 1/\sqrt{2}\approx0.707$ — the highest-quality fully-periodic tet tiling of $\mathbb{R}^3$.

### 1.1 Why BCC for FEA

- Constant element quality everywhere (no slivers, no skewed transitions).
- Tetrahedra are oriented in only **4 symmetry classes** — vectorised element matrix evaluation.
- Naturally suited to **octree-style refinement**: each cube subdivides into 8 children, each with the same BCC structure.

The PolyFEA project does not currently use BCC; for dense Tet10 simulations it would yield $\sim1.4\times$ smaller stiffness-matrix condition number than TetGen output.

---

## 2. Isosurface Stuffing (Labelle & Shewchuk, SIGGRAPH 2007)

The reference algorithm for converting any SDF into a high-quality conforming tet mesh.

### 2.1 Inputs

- A signed-distance (or any) implicit $\phi:\mathbb{R}^3\to\mathbb{R}$.
- A target edge length $h$ (constant or position-dependent).

### 2.2 Steps

```text
1. Build an octree covering the bounding box of {phi <= 0}
   - subdivide if sizing field h is finer than current cell, or
     if cell straddles {phi=0} and is coarser than target
2. From the octree, generate a BCC lattice of vertices at each leaf
3. Sign each vertex by phi:  v.s = sign(phi(v))
4. For each background tet T with mixed signs:
       compute the cut points where edges of T cross phi=0
       SNAP each crossing to the nearest "negative" vertex IF distance < alpha*edge
       OTHERWISE create a new Steiner vertex on the edge
5. WARP positive vertices outside the boundary onto the cut points (snapping)
6. CULL tets that lie entirely in {phi > 0}
7. STUFF remaining cut tets with a precomputed lookup table of 11 stencils
   (each handling one combinatorial sign pattern of the 4 vertices)
8. Output: conforming, all-tet mesh of {phi <= 0}
```

### 2.3 Quality theorem (Labelle–Shewchuk 2007)

For appropriate snapping threshold $\alpha\in[0.2, 0.3]$ and a Lipschitz-bounded $\phi$, the algorithm produces tets with provable dihedral bounds:

$$
\theta_{\min} \ge 10.7°, \qquad \theta_{\max} \le 164.8°.
$$

These are the **best provable bounds of any 3-D mesher to date** for arbitrary geometry. In practice the produced meshes have $\theta_{\min}\approx20°$ — better than TetGen on the same inputs and without the need for sliver-removal post-processing.

### 2.4 Implementations

- **SIBL** (Labelle's original C code) — non-commercial license.
- **CleaverNG** (Bronson et al., SCI Institute) — open-source, optimised for medical imaging segmentations; the gold standard for converting label maps (multi-material) to FEA-quality meshes. Cleaver2 extension supports multi-material.
- **Mmg-Iso** (Dapogny 2014) — MMG3D's `-ls` mode runs anisotropic isosurface meshing from an LS field.

---

## 3. Dual Contouring for Sharp Features (Ju–Losasso–Schaefer–Warren 2002)

Isosurface stuffing assumes a smooth $\phi$. For CSG / piecewise-implicit geometries with **sharp features**, use dual contouring:

```text
1. Build adaptive octree covering the domain
2. For each octree edge crossing the implicit, compute crossing point AND normal
3. For each octree cell containing crossings:
       place ONE dual vertex at the position minimising the QEF
       (Quadric Error Function over its edge crossings + normals)
4. For each octree edge intersecting the surface, generate a quad face
   connecting the dual vertices of the 4 cells around it
5. Triangulate quads (split diagonal) -> conforming surface mesh
6. Tet-stuff the inside via Labelle-Shewchuk on the same octree
```

### 3.1 QEF objective

$$
\mathrm{QEF}(p) = \sum_{i=1}^k \bigl(n_i\cdot(p-p_i)\bigr)^2,
$$

solved by SVD (truncate small singular values to keep $p$ inside the cell). Reproduces sharp creases and corners exactly when the normals at crossings disagree.

### 3.2 Dual Marching Cubes (DMC)

A simpler dual variant that reproduces marching cubes' connectivity but with octree-adaptive resolution. Used in real-time / GPU implementations.

---

## 4. Multi-Material Meshing

For voxelised inputs with multiple labels (CT segmentation: bone vs. muscle vs. fat), the conformal mesh must have **boundary-matched interfaces** between materials.

### 4.1 Cleaver2 (Bronson 2014)

Extends Labelle–Shewchuk: each vertex is tagged with **multiple signs** (one per label); cut-point computation uses **interface barycentric weights**; output is a watertight, conformal, multi-material tet mesh.

### 4.2 Octree-Based Multi-Material BCC

Workflow used in COMSOL's *Image Import* (6.x) and Simpleware:

```text
1. Marching cubes on each material's indicator function -> surface mesh
2. Boolean intersect surfaces -> watertight conformal interface
3. Tet-mesh each material's region using TetGen/Cleaver2
4. Stitch across interfaces (shared face IDs preserved)
```

---

## 5. Embedded / Fictitious-Domain Methods (No Body-Fitted Mesh)

For some applications the boundary mesh is the bottleneck. **Embedded methods** skip it: cover the domain with a structured background grid and modify the FEM weak form to enforce the boundary.

### 5.1 Finite Cell Method (FCM) — Düster, Parvizian, Rank 2007

```text
1. Cover the domain with a regular Cartesian (or octree) grid of HEX cells
2. For each cell:
       if entirely inside domain: standard high-order FEM (p=4..8)
       if entirely outside: drop
       if cut: integrate with quadrature on inside subregion only
            quadrature obtained from octree subdivision OR moment-fitting
3. Enforce Dirichlet via Nitsche's method (penalty + consistency + symmetry)
4. Standard solver on the rectangular grid
```

Advantages: **no mesh generation cost**, regular structured solver. Disadvantages: condition number explosion in poorly-cut cells (cells with very small intersected volume), requiring stabilisation.

### 5.2 CutFEM (Burman, Hansbo 2014)

A theoretically cleaner cousin of FCM: adds **ghost-penalty terms** on cut-cell faces to control the conditioning:

$$
j(u_h,v_h) = \sum_{F\in\mathcal{F}_{\text{ghost}}} \gamma_F h_F \int_F [\![\partial_n u_h]\!] [\![\partial_n v_h]\!]\,ds.
$$

Robust to arbitrarily small cut volumes; optimal-order convergence; the leading method for implicit/level-set FEM in 2020+.

### 5.3 When to use embedded methods

| Scenario | Verdict |
|---|---|
| Topology-changing simulation (crack growth, level-set shape opt) | **YES** — remeshing per step is prohibitive |
| High-aspect-ratio anisotropic boundary | NO — body-fitted with [[08_Anisotropic_Metric_Adaptation]] |
| Standard structural FEA on fixed geometry | NO — body-fitted tetra is competitive |
| Multi-physics with moving interfaces (FSI) | YES |

COMSOL 6.x ships CutFEM via the `Wetted Wall` boundary condition; Abaqus has the Extended FEM (XFEM) which is closely related.

---

## 6. CSG Tree → Tet Mesh

For pure CSG (Constructive Solid Geometry: union/intersect/difference of primitives):

```text
1. Build SDF: phi(x) = combiner-tree-evaluation
       union:      min(phi_A, phi_B)
       intersect:  max(phi_A, phi_B)
       difference: max(phi_A, -phi_B)
2. Sample phi on adaptive octree (refine where |grad phi| is high)
3. Dual contouring + isosurface stuffing
4. Tag features (edges where phi is min of multiple primitives) for preservation
```

CGAL `Mesh_3` accepts arbitrary `Implicit_function` and runs Boissonnat–Oudot 2005 refinement (Delaunay-based), giving a conformal Tet mesh with provable Hausdorff bounds.

---

## 7. Voxel / Image Meshing — Practical Pipeline

```text
input: 3-D label volume (e.g., DICOM CT segmentation)
1. Pre-smoothing: anti-aliased SDF computation, anisotropic Gaussian on labels
2. Per-material: marching cubes -> surface; smooth with HC-Laplacian
3. Boolean union of surfaces -> joint manifold
4. Watertighten / fix self-intersections (fTetWild or MeshFix)
5. Cleaver2 OR TetGen on the watertight manifold -> tet mesh
6. Quality improvement: ODT / Stellar
7. Material-tag every tet by the label of its centroid in original volume
```

COMSOL's *Image Mesher* (6.3) implements steps 1-6 internally and is the standard tool for biomechanics, geophysics, and battery imaging.

---

## 8. When to Use This Family

| Scenario | Verdict |
|---|---|
| **SDF / implicit / level set** | Isosurface stuffing (Labelle-Shewchuk) is canonical |
| **Voxel / CT / segmentation** | Cleaver2 (multi-material) or COMSOL Image Mesher |
| **CSG primitives** | Dual contouring + isosurface stuffing; CGAL Mesh_3 alternative |
| **Sharp creases in implicit** | Dual contouring with QEF |
| **Moving boundaries / topology changes** | CutFEM (skip remeshing) |
| **Clean CAD B-rep** | use [[04_Delaunay_CDT_and_TetGen]] instead |
| **Dirty STL** | use [[09_Robust_TetWild_for_Dirty_Geometry]] |

---

## 9. References

- F. Labelle, J. R. Shewchuk, "Isosurface stuffing: Fast tetrahedral meshes with good dihedral angles," *ACM TOG* 26(3), SIGGRAPH 2007.
- T. Ju, F. Losasso, S. Schaefer, J. Warren, "Dual contouring of Hermite data," *SIGGRAPH* 2002.
- J. Bronson, J. Levine, R. Whitaker, "Lattice cleaving: A multi-material tetrahedral meshing algorithm with guarantees," *IMR* 2012; updated *IEEE TVCG* 2014 (Cleaver2).
- A. Düster, J. Parvizian, Z. Yang, E. Rank, "The finite cell method for three-dimensional problems of solid mechanics," *CMAME* 197, 2008.
- E. Burman, S. Claus, P. Hansbo, M. Larson, A. Massing, "CutFEM: discretizing geometry and partial differential equations," *IJNME* 104, 2015.
- J.-D. Boissonnat, S. Oudot, "Provably good sampling and meshing of surfaces," *Graphical Models* 67, 2005.
- C. Dapogny, C. Dobrzynski, P. Frey, "Three-dimensional adaptive domain remeshing…," *J. Comput. Phys.* 262, 2014. (MMG3D `-ls`)
- COMSOL 6.3 *Image Mesher* User's Guide.
