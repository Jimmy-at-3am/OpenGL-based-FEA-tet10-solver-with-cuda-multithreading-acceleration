# TODO_08 — Curved Tet10: mid-edge surface projection

## Goal
Make Tet10 *isoparametric* on curved boundaries by projecting boundary mid-edge nodes onto the original surface mesh. Currently `generateMidEdgeNodes()` uses the geometric midpoint, capping geometric accuracy at $\mathcal{O}(h^1)$ for curved geometries. After this TODO: $\mathcal{O}(h^2)$.

## Files added / modified
- **Modify** `src/FEAModel.cpp::generateMidEdgeNodes()` lines 689–744 — boundary edges get surface-projection.
- **Modify** `include/MeshSmoother.h`, `src/MeshSmoother.cpp` — add `class Tet10Projector` with two backends: triangulation (STL/3MF source) and NURBS (`BRepHandle` from TODO_04 when STEP source).
- **Add** `assets/test_fixtures/sphere_r1.stl` if not already present (reused from TODO_03). Also test against `assets/test_fixtures/sphere_r1.step` (from TODO_04) — the NURBS-projection path produces a 2-order-of-magnitude smaller area error.

## Algorithm summary
From plan Appendix Phase B.3:

```text
buildSurfaceFaceMap()   // from snapshotted surfaceIndices

#pragma omp parallel for schedule(dynamic, 256)
for each unique edge (a, b) in edgeToMidNode:
    pa, pb = corner positions
    mid = 0.5 * (pa + pb)               // linear baseline

    if isSurfaceEdge(a, b):              // both endpoints on the input surface
        candidates = surfaceFacesContainingEdge(a, b)
        proj, dist = projectToNearestTri(mid, candidates)
        local_h = 0.5 * length(pb - pa)
        if dist < params.curvedTet10MaxDriftRatio * local_h:
            VALIDITY: re-evaluate exact orient3d of all incident Tet10s at proj
            if all positive: mid = proj
            else: keep linear midpoint (log)
    write mid to position list
```

`projectToNearestTri` = Eberly point-to-triangle distance (~15 lines, closed form).

**STEP source — exact NURBS projection** (when `model.hasBRep()`, from TODO_04):
Replace the `projectToNearestTri` call with an OCC `BRepHandle::nearestPointOnFace(faceId, uvHint)` query. The `faceId` is the per-triangle face-tag stored by TODO_04's tessellation harvest (`BRepHandle::triangleFaceId[edgeTri]`); `uvHint` is the (u,v) of the corner-node tessellation parameter on that face, providing a warm start for OCC's local Newton iteration. The drift cap, validity guard, and rollback policy are **unchanged** — only the projection target swaps from a triangle plane to the exact NURBS surface. Expected drop in surface-area error on a sphere: 3e-5 (triangulated) → ~1e-7 (NURBS).

## Multithreading
Per-edge parallel; data race only on per-edge atomic position write (safe). `useMultithreading = true`.

## Numerical care points
- **Exact predicates for validity** (care-point #1 + #6). Projection on curved surfaces routinely inverts neighbour Tet10s; the guard is mandatory.
- Drift cap `curvedTet10MaxDriftRatio = 0.25` default — projection that moves more than 25% of half-edge-length almost always inverts something.
- Two endpoint nodes shared between adjacent surface triangles must both qualify as "surface" — use boundary-detection (face count == 1) from existing `mesh_diag.cpp` logic.

## Screen-visible acceptance check

**Setup** Load `assets/test_fixtures/sphere_r1.stl`. Enable Tet10 in solver params.

**Action** Click `Generate 3D Mesh`. Then enable surface-only visualisation (existing toggle).

**Expected**
- Console (STL source):
  ```text
  [Tet10] projection target: surface mesh (triangulated)
  [Tet10] mid-edge projections: 1284 attempted, 1241 accepted, 43 rejected (inversion guard)
  [Fidelity] surface area: analytical 12.5664   discrete 12.566 (err 3e-5, 0.0002%)
  ```
- Console (STEP source — re-run with `sphere_r1.step`):
  ```text
  [Tet10] projection target: NURBS surface (B-rep, exact)
  [Tet10] mid-edge projections: 1284 attempted, 1281 accepted, 3 rejected (inversion guard)
  [Fidelity] surface area: analytical 12.5664   discrete 12.56637 (err 8e-7, 6e-6%)
  ```
- Visual: the surface mesh visibly curves along the sphere when zoomed; straight-edge Tet10 (baseline) looked faceted at the same zoom.

**Failure modes**
- `0 accepted` → boundary detection wrong (no edge identified as surface edge).
- Area error > 0.5% → projection direction wrong (projecting to wrong triangle plane).
- Many `rejected` → drift threshold too tight; loosen `curvedTet10MaxDriftRatio`.

**Pass criterion** Surface area error $< 0.1\%$ for the sphere AND > 90% of projections accepted.

## Regression sentinel
`regression/sphere_tet10_area.txt` — surface area + acceptance ratio.

## Depends on
TODO_05 (for the surface-only visualisation toggle to demonstrate the result).

## Estimated effort
2 days.
