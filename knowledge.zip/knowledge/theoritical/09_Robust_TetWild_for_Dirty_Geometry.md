---
title: Robust Tetrahedralisation — TetWild & fTetWild
type: algorithm
tags: [tetwild, ftetwild, robust, envelope, winding-number, dirty-cad, non-manifold]
created: 2026-05-16
---

# 09 — Robust Tetrahedralization for Dirty Geometry (TetWild & fTetWild)

Classical Delaunay/CDT meshers ([[04_Delaunay_CDT_and_TetGen]]) require a **watertight, manifold, self-intersection-free** input. In the wild, CAD files routinely violate all three:

- Gaps and overlaps between faces (~0.001 of bounding box typical).
- Self-intersecting triangles in STL exports.
- Non-manifold edges shared by 3+ faces.
- Flipped normals on isolated patches.
- T-junctions on near-coincident edges.

Until 2018, the only workflow for such inputs was manual repair in MeshLab / Magics / 3-matic followed by Delaunay meshing — hours to days per part. **TetWild** (Hu et al., SIGGRAPH 2018) and its faster successor **fTetWild** (Hu et al., 2020) are the breakthrough: they accept *any* triangle soup and produce a high-quality tetrahedral mesh in one pass, with provable termination.

This note covers the algorithms, when they win, when they don't, and how to integrate them with the host project's pipeline.

---

## 1. The Core Idea — Envelope-Based Stuffing

**TetWild's insight:** abandon the requirement that the output mesh's surface **exactly** match the input. Instead, require it to lie within an **envelope** of half-thickness $\varepsilon$ (typically $10^{-3}$ of the bounding box diagonal):

$$
\mathrm{dist}(F_{\mathrm{out}}, F_{\mathrm{in}}) \le \varepsilon \quad \forall F_{\mathrm{out}}\in\partial\mathcal{T}_h.
$$

Once we accept this relaxation, the algorithm:

1. **Never re-intersects triangles** (root cause of CDT failure on dirty inputs).
2. Can choose where to place surface mesh nodes to **maximise element quality**.
3. Provably terminates because the envelope guarantees a feasible solution always exists.

The "filter" — what defines inside vs outside the resulting volume — is the **generalised winding number** (Jacobson et al., 2013):

$$
w(x) = \frac{1}{4\pi} \sum_{T\in F_{\mathrm{in}}} \Omega_T(x),
$$

where $\Omega_T(x)$ is the solid angle subtended by triangle $T$ at $x$. For a closed manifold mesh $w(x)$ is $1$ inside, $0$ outside. For a "soup" with self-intersections, $w(x)$ may take any integer (and even non-integer near boundaries); a cut $w(x)>0.5$ defines a robust *inside* domain even for very dirty inputs.

---

## 2. The TetWild Algorithm (Hu et al., 2018)

```text
INPUT  : triangle soup S = { triangles in R³ }
         envelope half-thickness ε
         target edge length ℓ_target

PIPELINE:
  1. PREPROCESS:
       - resolve self-intersections (CGAL): split triangles where they cross
       - merge near-duplicate vertices within ε/10
       - compute generalised winding number w(x)
  2. INITIAL BCC LATTICE:
       - place a BCC lattice ([[06_Octree_BCC_and_Isosurface_Stuffing]]) of edge ℓ_target
       - retain tets whose centroid has w > 0.5
  3. INSERT SURFACE:
       - for each input triangle t, insert via local re-tet inside cavity
         (BUT: vertex positions are free to move within ε-envelope)
  4. MESH IMPROVEMENT (iterative):
       - edge split / collapse / swap (quality-driven)
       - smoothing (Laplacian + projection back to envelope)
       - until quality threshold q_min (Knupp η) met for every element
  5. FILTER:
       - for each tet T: include iff (centroid winding > 0.5)
       - output the included tets

OUTPUT : tet mesh of {w > 0.5} ⊂ R³ with all elements satisfying
         η > 17° dihedral angle ≈ Knupp 0.4 typical.
```

**Termination guarantee.** Provided $\varepsilon > 0$, the algorithm terminates because the envelope contains the BCC lattice intersection (worst case) which is a valid output.

**Quality result.** Hu et al. report on **Thingi10K** (10K real-world STL models from Thingiverse):
- **100% success rate** (TetGen: 65%; CGAL: 70%).
- **Median min-dihedral angle**: 17° (TetGen: 12°; CGAL: 8°).
- **Hausdorff error**: bounded by user-specified $\varepsilon$.

**Cost.** Slower than TetGen by 5–20× wall time; usually acceptable for the robustness gain.

---

## 3. fTetWild — The Practical Successor (Hu et al., 2020)

fTetWild speeds TetWild up by **2–10×** through algorithmic restructuring while preserving the robustness guarantees:

- **No CGAL preprocessing**. Self-intersections are handled implicitly via the envelope; no expensive CGAL re-triangulation.
- **Floating-point envelope tests**. Replaces exact arithmetic with cone-based fast filters (Wang et al., 2020).
- **Improved smoothing**. Newton-style projection inside envelope.
- **Parallelism**. Cavities decomposed across threads.

For practical projects in 2024+, **fTetWild is the default recommendation** for any input that is not guaranteed clean.

Open source: `https://github.com/wildmeshing/fTetWild` (MIT licensed).

---

## 4. When TetWild / fTetWild Win — and When They Don't

### Wins:

- **STL from photogrammetry, 3-D scanning, segmentation** — always dirty.
- **Reverse-engineered CAD** — frequent T-junctions.
- **Multi-material 3-D printing files** — overlapping volumes.
- **Boolean operations on CAD** — produce near-degenerate sliver triangles.
- **Implicit surfaces with discretisation noise** — marching cubes output.

### Does not win:

- **Strict boundary preservation required** — envelope smears the surface by $\varepsilon$; not acceptable for IGES/STEP CAD where geometric exactness matters (use [[04_Delaunay_CDT_and_TetGen]]).
- **Curved manifold surface meshing** — TetWild outputs a tet mesh whose boundary is a triangle mesh, but with no respect for analytic curvature. Use [[03_Surface_Meshing_Curved_Manifolds]] for surface-only outputs.
- **Anisotropic meshes** — TetWild is isotropic by construction. For BL or shocks, use [[08_Anisotropic_Metric_Adaptation]] post-processing.
- **Tight memory budgets** — fTetWild peaks at 10× the memory of TetGen.

---

## 5. Comparison Table — Modern Robust Meshers

| Mesher | Year | Robustness | Speed | Quality | Boundary fidelity | Anisotropy |
|---|---|---|---|---|---|---|
| TetGen `-pq1.4Y` | 2015 | requires clean | fast | good | exact | no |
| CGAL Tet3 | 2018 | medium | medium | good | exact | no |
| Mmg3D | 2014 | medium | fast | excellent | exact | **yes** |
| TetWild | 2018 | **100% on Thingi10K** | slow | good | $\varepsilon$-envelope | no |
| fTetWild | 2020 | **100% on Thingi10K** | fast | good | $\varepsilon$-envelope | no |
| TetWild + MMG3D post-pass | 2020 | excellent | medium | excellent | $\varepsilon$ + anisotropic | **yes** |

The last line is the **2024 state-of-the-art recipe** for production: fTetWild for robustness, then MMG3D for anisotropic adaptation and final quality polish.

---

## 6. Integration Recipe for PolyFEA

The host project ([theory.md](../theory.md)) ingests STL/3MF via [src/STLLoader.cpp](../src/STLLoader.cpp) and currently invokes TetGen. For dirty inputs:

```text
1. STL → TetWild/fTetWild (./fTetWild --input model.stl --envelope 1e-3)
2. Output is a .msh tet mesh with vertex positions slightly perturbed.
3. (Optional) Apply MMG3D for ODT smoothing:
     ./mmg3d -in tet.msh -out polished.msh -hgrad 1.3 -hausd 1e-3
4. Convert .msh → PolyFEA format (Tet4 OR mid-edge-insert for Tet10).
```

Wrapper guidance:

- For Tet10, fTetWild outputs only **Tet4**; mid-edge nodes must be inserted by computing edge midpoints in the linear mesh, then optionally projecting onto a recovered surface (Loop subdivision or PN-triangles).
- The envelope $\varepsilon$ should be ≤ the FEA elastic deformation scale — for displacements of $\sim 1$ mm on a 1 m bounding box, $\varepsilon \le 10^{-4}$ m.

---

## 7. The Generalised Winding Number — A Robust Inside Test

The generalised winding number deserves a brief standalone treatment because it underlies not just TetWild but also Marching Tets robust variants, hex-meshing inside tests, and implicit-explicit coupling.

For a triangle $T = (a,b,c)$ with outward orientation:

$$
\Omega_T(x) = 2\,\mathrm{atan2}\!\left(\det\begin{bmatrix}a-x\\b-x\\c-x\end{bmatrix},\; \|a-x\|\,\|b-x\|\,\|c-x\| + (a-x)\cdot(b-x)\,\|c-x\| + \cdots\right).
$$

Summed over the input triangle set, $w(x)\in\mathbb{R}$; for a watertight manifold input it equals the number of times the surface wraps around $x$ (integer). For a soup, fractional values appear in self-intersection regions.

**Cut threshold:** $0.5$ is empirically robust. Tighter cuts (e.g., $0.99$) reject more outside cases; looser cuts ($0.1$) accept ambiguous regions as inside (useful for inclusion-aware meshing).

**Acceleration.** Hierarchical multipole expansion (Jacobson 2013) reduces $\Omega_T(x)$ for $n$ triangles from $\mathcal{O}(n)$ per query to $\mathcal{O}(\log n)$. Open-source `libigl::winding_number`.

---

## 8. References

- A. Jacobson, L. Kavan, O. Sorkine-Hornung, "Robust inside-outside segmentation using generalized winding numbers," *ACM TOG* 32, 2013.
- Y. Hu, Q. Zhou, X. Gao, A. Jacobson, D. Zorin, D. Panozzo, "Tetrahedral meshing in the wild," *ACM TOG (SIGGRAPH)* 37, 2018.
- Y. Hu, T. Schneider, B. Wang, D. Zorin, D. Panozzo, "Fast tetrahedral meshing in the wild," *ACM TOG (SIGGRAPH)* 39, 2020.
- B. Wang, Y. Hu, D. Panozzo, "Exact and Efficient Polyhedral Envelope Containment Check," *ACM TOG* 39, 2020.
- Q. Zhou, A. Jacobson, "Thingi10K: A Dataset of 10,000 3D-Printing Models," arXiv:1605.04797, 2016.
- Annotated list in [[15_References_Bibliography]].
