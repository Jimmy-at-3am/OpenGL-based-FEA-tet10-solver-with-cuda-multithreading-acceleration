# Session Lessons - TODO_02 MeshQuality Verdict Finalization

## Date
2026-05-18

---

## 1. Outcome

TODO_02's metric/reporting implementation is complete and the final verdict policy was refined after real variable sweeps over `tetRadiusEdge` / `p` and `maxVolPercent`.

The important conclusion: a practical TetGen mesh with zero inverted elements and a tiny residual sliver tail can be called `PASS`. TetGen's min-dihedral option is a target, not a strict guarantee, and forcing every run to have zero below-target tets can push the workflow toward an overly coarse simulation mesh.

Final MeshQuality verdict semantics:

- `FAIL`: one or more inverted elements (`scaledJacobian <= 0`).
- `WARN`: no inverted elements, but severe-sliver or below-target sliver tail exceeds `1.0%` of total elements.
- `PASS`: no inverted elements and both sliver tails are `<= 1.0%`.

The observed fine test case:

```text
p = 1.231
maxVolPercent = 6.3e-3
N = 30445 tets
severe slivers < 5 deg = 8  -> 0.026%
below target 10 deg = 57    -> 0.187%
inverted = 0
```

is therefore a valid `PASS`, not a reason to select the much coarser `p=1.1, maxVolPercent=0.2` mesh.

---

## 2. Why This Is Consistent with the Knowledge Base

The meshing notes and TODO roadmap separate three responsibilities:

1. TetGen creates the initial tetrahedralization using target quality switches.
2. `MeshQuality` reports metrics and catches unacceptable geometry.
3. Later TODOs (`TODO_05` ODT smoothing, `TODO_06` topology/stellar flips, `TODO_08` combined polish loop) reduce the residual sliver tail.

Because TetGen's `-q radius/min-dihedral` settings are targets, not guarantees, TODO_02 should not require zero slivers. A percentage-based tail rule preserves diagnostics without encouraging over-coarsening.

---

## 3. Implementation Lessons

### 3.1 Separate metric correctness from verdict policy

The TODO_02 metrics can be correct even when the first verdict policy is too strict. Validate structural requirements first:

- histogram bins sum to `N`
- percentile rows are monotonic
- skew stays in `[0, 1]`
- Worst-N prints the requested count
- inverted count is zero for valid meshes

Only after those checks should the pass/warn/fail semantics be tuned.

### 3.2 Use percentages for rare quality tails

Raw counts are misleading across meshes of different density. A count of 8 bad tets in 30k elements is not equivalent to 8 bad tets in 100 elements. Always print both:

- raw count for traceability
- percentage for decision-making

### 3.3 Do not coarsen just to satisfy a binary report

The coarse run (`p=1.1`, `maxVolPercent=0.2`) passed because it had only 1027 tets, but it is not automatically better for simulation. The verdict must not reward under-resolution.

### 3.4 Keep residual sliver removal in the right TODO

A small sliver tail after TetGen belongs to smoothing/topology improvement TODOs, not to TODO_02. TODO_02 should make the tail visible and quantify it.

---

## 4. Code Changes to Remember

- `include/MeshQuality.h`
  - Added `severeSliverCount`, `hardMinDihedralFailDeg`, `acceptableSliverPercent`, and `warn` to `QualityReport`.
- `src/MeshQuality.cpp`
  - Counts both below-target slivers (`tetMinDihedralDeg`, default `10 deg`) and severe slivers (`5 deg`).
  - Computes sliver percentages from `numElements`.
  - Emits `PASS`, `WARN`, or `FAIL` with both raw counts and percentages.
  - Uses `1.0%` as the accepted tail cap.

---

## 5. Rule of Thumb for Future Agents

When a user says a fine mesh is marked `FAIL` but a much coarser mesh is marked `PASS`, do not change TetGen parameters first. Check whether the verdict logic is confusing a target-quality tail with a hard invalid-mesh condition.

For PolyFEA as of TODO_02:

```text
0 inverted + sliver tails <= 1%  => PASS
0 inverted + sliver tail > 1%    => WARN
any inverted element             => FAIL
```

---

*Author: Cascade - 2026-05-18*
