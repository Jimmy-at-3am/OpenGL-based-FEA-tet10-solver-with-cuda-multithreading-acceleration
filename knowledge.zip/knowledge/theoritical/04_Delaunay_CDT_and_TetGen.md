---
title: Delaunay, Constrained Delaunay, and TetGen
type: algorithm
tags: [delaunay, cdt, ruppert, shewchuk, tetgen, sliver]
created: 2026-05-16
---

# 04 — Delaunay, Constrained Delaunay, and TetGen

The Delaunay family is the algorithmic backbone of nearly every tetrahedral mesher in service today (TetGen, Gmsh, NetGen, ANSYS, COMSOL all use a Delaunay kernel internally for at least part of the pipeline). This note covers:

1. Incremental Delaunay (Bowyer–Watson) — §2
2. Constrained Delaunay in 2-D (Triangle) — §3
3. Ruppert / Shewchuk Delaunay refinement with quality guarantees — §3.3
4. Constrained Delaunay Tetrahedralization (CDT(3)) and TetGen — §4
5. Robust geometric predicates — §5
6. The 3-D sliver problem and modern remedies — §6

Foundations: [[01_Mathematical_Foundations]] §2 (Voronoi/Delaunay). Quality framework: [[02_Mesh_Quality_Metrics]]. For dirty/non-manifold input see [[09_Robust_TetWild_for_Dirty_Geometry]].

---

## 1. Why Delaunay?

Three properties make Delaunay the universal starting point:

1. **Empty-circumball** ⇒ in 2-D, **angle-optimal** triangulation of a fixed point set.
2. **Locality** ⇒ an inserted point only affects elements whose circumball contains it. Insertion is $\mathcal{O}(\log n)$ amortised.
3. **Duality** with Voronoi ⇒ smoothing (CVT/ODT) is a closed-form gradient flow on the dual.

The trade-offs:

- In **3-D**, Delaunay does **not** maximise minimum dihedral; slivers appear.
- Pure (point-set) Delaunay does **not** respect boundaries — constrained variants are needed.

---

## 2. Incremental Delaunay — Bowyer (1981) and Watson (1981)

Given an existing Delaunay triangulation $T_k$ and a new point $p$:

```text
1. Locate the simplex sigma containing p     (walk, jump-and-walk, or kd-tree)
2. Compute the cavity C = { tau in T_k : p in circumball(tau) }   (BFS from sigma)
3. Delete C, leaving a star-shaped hole H around p
4. Re-triangulate H by connecting p to every boundary face of H
5. T_{k+1} = (T_k \ C) ∪ {new simplices}
```

The cavity is guaranteed star-shaped iff the point-in-circumball test is exact (see §5). In practice, both the location and cavity steps are $\mathcal{O}(1)$ amortised for uniformly random inserts (Mücke 1996), giving $\mathcal{O}(n\log n)$ total — and $\mathcal{O}(n)$ if a **Biased Randomised Insertion Order** (BRIO, Amenta 2003) is used.

### 2.1 Streaming Delaunay

For massive point sets (LiDAR, $n>10^9$): Isenburg's *Streaming Delaunay* (2006) processes the point cloud in spatial order with bounded memory. Modern implementations (CGAL `Triangulation_3_streaming`) achieve $>1$ M points/s on a single core.

### 2.2 Parallel Delaunay

Two productive ideas:

- **Lock-free parallel insertion** (Batista, Millman, Pion 2010 — CGAL `Spatial_sort + parallel_for`).
- **Bucket-based partitioning** (Funke, Sanders 2017 — GPU Delaunay).

CGAL 6.0 ships parallel 3-D Delaunay reaching $>10$ M tets/s on 64 cores; this is the kernel inside fTetWild ([[09_Robust_TetWild_for_Dirty_Geometry]]).

---

## 3. 2-D Constrained Delaunay + Quality Refinement

### 3.1 PSLG input

A **planar straight-line graph** (PSLG) is a set of vertices and constraint edges. A **Constrained Delaunay Triangulation** (CDT, Chew 1989) is a triangulation where every constraint edge is present and every triangle is Delaunay *modulo* the constraints (its circumcircle may contain points hidden behind a constraint edge).

### 3.2 Triangle (Shewchuk 1996)

The canonical CDT implementation. Inserts vertices one at a time using the **Anderson–Watson** algorithm for visible cavities. Time: $\mathcal{O}((n+k)\log n)$ for $n$ points and $k$ constraints.

### 3.3 Ruppert (1995) — quality-guaranteed refinement

The breakthrough that made automatic 2-D mesh generation routine:

```text
input: PSLG (V, E), threshold rho* (radius-edge ratio)
1. Build the CDT
2. Mark a triangle "bad" if its rho = R/l_min > rho*
3. Mark a constraint edge "encroached" if some vertex lies inside its diametral disk
4. while bad triangles or encroached edges exist:
       if any constraint edge e is encroached:
           split e at its midpoint, insert; recompute CDT
       else pick a bad triangle T:
           insert its circumcenter c into the CDT
           (if c encroaches a constraint edge, treat that instead)
5. Output the CDT
```

**Termination & quality theorem (Ruppert 1995):** If $\rho^* > \sqrt{2}\approx20.7°$, the algorithm terminates and every output triangle has minimum angle $\ge\arctan(1/(2\rho^*-1))$. Shewchuk (2002) extended this to $\rho^* > \tan(\pi/2\cdot1/k) \cdot \dots$ at higher angles with mild assumptions.

**Edge length bound:** No output edge is shorter than $\mathrm{lfs}(p)/(\rho^*+1)$ — the mesh is **size-optimal** within a constant factor of the input local feature size.

### 3.4 Modern 2-D refinements

| Variant | Improvement |
|---|---|
| **Chew's second algorithm (1993)** | Off-centre insertion → smoother gradation |
| **Üngör's off-centres (2009)** | Provable smaller node count by 20-50% |
| **BAMG / MMG2 anisotropic** | Refinement under a metric $M(x)$ — see [[08_Anisotropic_Metric_Adaptation]] |
| **Frontal-Delaunay (Rebay 1993)** | Combine AFM front advance with Delaunay structure — see [[05_Frontal_Delaunay_and_Advancing_Front]] |

---

## 4. Constrained Delaunay Tetrahedralization (CDT(3)) — Si 2015

Extending CDT to 3-D is **not straightforward**: even for piecewise-linear domains, a CDT may **not exist** for some inputs (Schönhardt polyhedron, 1928). Hang Si's 2015 TetGen 1.5/1.6 paper resolves this constructively.

### 4.1 The Schönhardt obstruction

The non-convex twisted-prism Schönhardt polyhedron has no tetrahedralization at all without adding Steiner points. So *any* 3-D constrained mesher must be allowed to insert Steiner points on input facets.

### 4.2 Si's CDT(3) algorithm

```text
1. Build a Delaunay tetrahedralization of input vertices V
2. Recover all input edges (1-D constraints):
     For each missing edge e:
         use edge flips (2-3, 3-2, 4-4) to gain it; if impossible insert Steiner pt
3. Recover all input facets:
     For each missing facet F:
         identify "missing region" R = F \ current_facets
         insert Steiner points inside R using Shewchuk's PFE strategy
4. Mark sub-tets as IN/OUT by flood-fill from input boundary
5. Remove OUT tets => the CDT(3) of the input domain
6. Refine with Shewchuk's variable-radius-edge bound (Ruppert in 3-D)
7. Run Stellar-style improvement to eliminate slivers
```

The full algorithm is implemented in **TetGen** (used here in [src/tetgen.cxx](../src/tetgen.cxx) / [include/tetgen.h](../include/tetgen.h) inside PolyFEA). Performance: $\sim2\,M$ tets/s on a single core; memory $\sim100$ B/tet.

### 4.3 TetGen command flags worth knowing

```text
-p   read PLC input              -q  quality (-q1.2 ⇒ R/l ≤ 1.2, default best practice)
-a   max volume constraint       -A  region attributes
-O7  optimisation level (1–10)    -k  output VTK
-Y   no Steiner points on input boundary (rigid feature preservation)
-V   verbose diagnostics
```

PolyFEA invokes TetGen with `-pq1.4Aa` for typical structural runs.

### 4.4 Limitations of CDT(3) and what supersedes them

CDT(3) requires a **valid PLC** input — watertight, no self-intersections, consistent facet orientations. Industrial CAD frequently fails these conditions. The robust answer:

- **fTetWild** (Hu 2020 — [[09_Robust_TetWild_for_Dirty_Geometry]]) — accepts arbitrary input via an envelope.
- **TetMeshing with conformal Delaunay refinement** (Tournois 2009, CGAL `Mesh_3`).

---

## 5. Robust Geometric Predicates

The two key predicates:

$$
\mathrm{orient3d}(a,b,c,d) = \mathrm{sign}\,\det\begin{bmatrix} a_x{-}d_x & a_y{-}d_y & a_z{-}d_z \\ b_x{-}d_x & b_y{-}d_y & b_z{-}d_z \\ c_x{-}d_x & c_y{-}d_y & c_z{-}d_z \end{bmatrix}
$$

$$
\mathrm{insphere}(a,b,c,d,e) = \mathrm{sign}\,\det\begin{bmatrix} a_x{-}e_x & a_y{-}e_y & a_z{-}e_z & \|a{-}e\|^2 \\ b_x{-}e_x & b_y{-}e_y & b_z{-}e_z & \|b{-}e\|^2 \\ c_x{-}e_x & c_y{-}e_y & c_z{-}e_z & \|c{-}e\|^2 \\ d_x{-}e_x & d_y{-}e_y & d_z{-}e_z & \|d{-}e\|^2 \end{bmatrix}
$$

Naively using `double` causes **catastrophic cancellation**: in degenerate or near-degenerate configurations the sign is wrong, the cavity is no longer star-shaped, and the mesher emits inverted tets or crashes.

### 5.1 Shewchuk's adaptive predicates (1997)

Adaptive multi-precision evaluation: start in `double`, escalate to expansion arithmetic only if the result lies within a computed error bound. Average overhead $<5\%$ vs. naive; correctness is **exact** within the input precision.

The original `predicates.c` (Shewchuk 1996) is the foundation; PolyFEA bundles it as [src/predicates.cxx](../src/predicates.cxx). Always initialise once via `exactinit()` at startup — a forgotten call here is the most common bug.

### 5.2 Modern alternatives

- **CGAL's `Exact_predicates_inexact_constructions_kernel`** (filtered + interval arithmetic + exact fallback).
- **`indirect_predicates`** (Attene 2020) — fully implicit, handles even-mesh intersections without computing them, used by fTetWild.

---

## 6. Slivers and Modern Sliver Removal

The Delaunay refinement of §3.3 generalises to 3-D as a **radius-edge** guarantee: $R/\ell_{\min}\le\rho^*$ with $\rho^*\ge2$. But (see [[02_Mesh_Quality_Metrics]] §5) this does **not** bound the radius ratio $\rho_T$, and slivers persist.

Three productive remedies:

### 6.1 Sliver exudation (Cheng et al. 2000, Edelsbrunner–Guoy 2002)

Convert the Delaunay to a **weighted (regular) triangulation**; perturb the weight $w_i\in[0, w_{\max}]$ of each vertex to remove the sliver while keeping it locally regular. Yields $\theta_{\min}\ge5°$ provably.

### 6.2 Stellar (Klingner & Shewchuk 2007)

A flexible **mesh-improvement engine** that combines four kinds of edits:

1. Smoothing — coordinate descent in $\theta_{\min}$ neighbourhood
2. Topological transformations — 2-3, 3-2, 4-4 flips + edge insertion
3. Vertex insertion
4. Vertex deletion

Driven by a **steepest-descent on the worst-element quality**. Raises TetGen's default output from $\theta_{\min}\approx5°$ to $\theta_{\min}\ge30°$ on common benchmarks; the most aggressive open-source tet mesh improver.

### 6.3 ODT smoothing (Chen–Holst 2011)

A continuous flow that minimises the interpolation $L^2$ error; closed-form gradient. Cheaper per iteration than Stellar; lifts quality from "acceptable" to "excellent" but is less effective at saving truly broken meshes. Discussed in [[12_Mesh_Smoothing_CVT_and_ODT]].

---

## 7. Pseudocode — End-to-End TetGen-style Pipeline

```text
input: PLC (V, E, F)         output: high-quality CDT(3)
1. Robust predicates: exactinit()
2. Bowyer-Watson incremental Delaunay of V using BRIO order
3. Edge recovery via flips + Steiner points
4. Facet recovery via PFE
5. Region tagging (BFS) and removal of OUT tets
6. Delaunay refinement loop:
     while exists T with R/l_min > rho* or vol > vmax:
         insert circumcenter (or off-center per Üngör)
     handle facet encroachment by mid-edge splits
7. Sliver removal: weight perturbation OR Stellar OR ODT
8. Optional global ODT smoothing
9. Boundary mesh verification (Hausdorff)
```

For a 1-M-tet mesh of a typical mechanical part: stages 1-2 in <2 s, 3-5 in <10 s, refinement in <30 s, smoothing in <20 s on a 2024 desktop.

---

## 8. When to Use This Family

| Scenario | Method | Notes |
|---|---|---|
| **Clean PLC, structural FEA** | TetGen / Triangle with quality refinement | optimal first choice |
| **Clean PLC, anisotropic CFD/elasticity** | CGAL `Mesh_3` or feflo.a | anisotropic refinement |
| **Adaptive remeshing in cycle** | MMG3D | reuses prior mesh as starting state |
| **Dirty CAD / scanned STL** | **NOT this family** — use [[09_Robust_TetWild_for_Dirty_Geometry]] |
| **Implicit geometry** | Use [[06_Octree_BCC_and_Isosurface_Stuffing]] instead |
| **Hex / quad output required** | Use [[10_Hex_QuadMeshing_FrameFields]] (frame fields) |

---

## 9. References

- J. R. Shewchuk, "Delaunay refinement algorithms for triangular mesh generation," *Computational Geometry* 22, 2002.
- J. Ruppert, "A Delaunay refinement algorithm for quality 2-D mesh generation," *J. Algorithms* 18, 1995.
- L. P. Chew, "Constrained Delaunay triangulations," *Algorithmica* 4, 1989.
- H. Si, "TetGen, a Delaunay-based quality tetrahedral mesh generator," *ACM TOMS* 41(2), 2015.
- H. Edelsbrunner, D. Guoy, "An experimental study of sliver exudation," *IMR* 2002.
- B. M. Klingner, J. R. Shewchuk, "Aggressive Tetrahedral Mesh Improvement," *IMR* 2007.
- A. Üngör, "Off-centers: A new type of Steiner points for computing size-optimal quality-guaranteed Delaunay triangulations," *Computational Geometry* 42, 2009.
- J. R. Shewchuk, "Adaptive Precision Floating-Point Arithmetic and Fast Robust Geometric Predicates," *Discrete & Computational Geometry* 18, 1997.
- M. Attene, "Indirect predicates for geometric constructions," *CAD* 126, 2020.
- C. Boissonnat, S. Pion, M. Yvinec — CGAL 6.0 `Mesh_3` package documentation.
