# TODO_05 — Quality HUD colour overlay (OpenGL)

## Goal
A keypress (`Q`) toggles a Knupp-quality colour map in the OpenGL viewer: blue → green → yellow → red ramp keyed to the per-element Knupp $q$, with the worst 1% drawn fully opaque red. Legend in the top-right.

## Files added / modified
- **Modify** `include/FEAModel.h` — add `std::vector<float> elementKnuppQ` for the per-element scalar field.
- **Modify** `src/FEAModel.cpp::updateScalarFieldData()` — populate `elementKnuppQ` from `MeshQuality`.
- **Modify** `src/ShaderSources.h` / `BuiltInShader.cpp` — add a fragment-shader path that samples from a 1-D colour-ramp texture by the per-vertex (or per-instance) scalar.
- **Modify** `src/SimpleUI.cpp` — add the `Q` key handler, a legend widget that draws the colour bar + value labels.
- **Modify** `src/main.cpp` — wire the toggle bool into the draw path.

## Algorithm summary
Per-element Knupp $q$ → per-vertex average for smooth shading (mean of incident elements' $q$). Worst-1% threshold: `qThreshold = percentile(elementKnuppQ, 0.01)`; elements with $q < q_{\text{threshold}}$ override to solid red.

Colour ramp (matches ParaView "cool to warm"):
| $q$ | colour |
|---|---|
| 0.20 | red `#d62728` |
| 0.40 | orange `#ff7f0e` |
| 0.60 | yellow `#bcbd22` |
| 0.80 | green `#2ca02c` |
| 1.00 | blue `#1f77b4` |

Encoded as a 256×1 RGBA texture loaded at startup.

## Multithreading
Per-vertex average is a single OMP parallel-for over vertices (fast; not on the critical path). All rendering on main thread (GL context).

## Numerical care points
- For Tet10 with mid-edge nodes: assign mid-edge node's $q$ as the average of its parent-corner $q$ values, not a Tet10-specific recompute (mid-edge nodes don't have their own quality).
- Worst-1% cutoff via `std::nth_element` not full sort.

## Screen-visible acceptance check

**Setup** Mesh any STL.

**Action** Press `Q` (or click new toggle `Quality HUD`).

**Expected visible**
- Tetrahedra recoloured with a blue→green→yellow→red ramp keyed to Knupp $q$ (blue = $q=1$, red = $q=0.2$).
- The worst 1% (lowest $q$) drawn fully opaque red; others semi-transparent so the user can still see geometry.
- Top-right corner: a 200px-tall colour-bar legend with labels `q=0.2 (poor)` … `q=1.0 (ideal)`.
- Pressing `Q` again returns to default rendering.

**Failure modes**
- All red or all blue → colour map clamped wrong (min/max swapped) or division by zero in normalisation.
- Legend missing → UI overlay added but draw-order behind mesh; raise UI layer index.
- HUD persists after `Q` → toggle state not connected to render path.

**Pass criterion** Visible colour ramp + legend appears on `Q`; disappears on second `Q`; worst elements clearly identifiable in red.

## Regression sentinel
Add a screenshot `regression/screenshots/hud_cube.png` captured via the existing GL framebuffer-grab path (if any). Future reviewers do a visual diff.

## Depends on
TODO_02.

## Estimated effort
2 days (most is shader + UI plumbing, not algorithm).
