---
title: Software Comparison Matrix — COMSOL, ANSYS, MATLAB, OSS
type: reference
tags: [software, comsol, ansys, matlab, gmsh, tetgen, mmg, comparison, version]
created: 2026-05-16
---

# 14 — Software Comparison Matrix

A practical comparison of the meshers in COMSOL 6.3, ANSYS 2024R2 (Mechanical, Fluent, Workbench, Discovery), MATLAB R2024b (PDE Toolbox), and the open-source stack (Gmsh 4.13, TetGen 1.6, MMG 5.7, fTetWild 1.0, CGAL 5.6). Cross-references to algorithm notes provided throughout.

This note is intentionally version-pinned — meshing capabilities have moved substantially in commercial codes since 2018 (Mosaic), 2022 (anisotropic adaptation in MATLAB), and 2023 (AI-acceleration in ANSYS).

---

## 1. Feature Matrix

| Capability | COMSOL 6.3 | ANSYS 2024R2 | MATLAB R2024b | Gmsh 4.13 | TetGen 1.6 | MMG 5.7 | fTetWild | CGAL 5.6 |
|---|---|---|---|---|---|---|---|---|
| **Volume tet (clean CAD)** | ✓ ([[04_Delaunay_CDT_and_TetGen]]) | ✓ | ✓ (TetGen wrap) | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Volume tet (dirty STL)** | ✗ | partial | ✗ | ✗ | ✗ | ✗ | **✓** ([[09_Robust_TetWild_for_Dirty_Geometry]]) | ✗ |
| **Hex / quad meshing** | sweep + multi-block | sweep + Multizone + hex-dominant | ✗ | hex-dom (HXT) | ✗ | ✗ | ✗ | ✗ |
| **Polyhedral (Mosaic-style)** | conversion | **Mosaic** ([[07_Polyhedral_Mosaic_and_Voronoi]]) | ✗ | ✗ | ✗ | ✗ | ✗ | partial (Voronoi) |
| **Anisotropic adaptation** | yes (6.0+) | yes (Mosaic-implicit, explicit since 2022R2) | yes (R2023a+ Hgrad/Hedge) | yes (BAMG) | ✗ | **✓ (gold standard)** ([[08_Anisotropic_Metric_Adaptation]]) | ✗ | partial |
| **Boundary-layer prism** | ✓ | ✓ (advanced) | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ |
| **Surface RCVT** | ✓ (since 5.6) | ✓ | ✗ | ✓ | ✗ | ✓ (mmgs) | ✗ | ✓ |
| **Implicit / SDF input** | ✓ (LiveLink) | ✓ (Discovery) | ✗ | partial | ✗ | ✓ | ✓ | ✓ |
| **Adaptive refinement loop** | ✓ recovery + functional | ✓ (Workbench) | ✓ (`adaptmesh`) | ✓ | ✗ | ✓ | ✗ | ✗ |
| **DWR goal-oriented** | ✓ (Functional option) | research-only | manual | ✗ | ✗ | partial | ✗ | ✗ |
| **hp-FEM** | ✗ | ✗ (only p) | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ |
| **Parallel meshing** | shared-memory | shared + GPU (Discovery) | shared | shared | ✗ | MPI (feflo.a) | shared | ✗ |
| **GUI** | full | full | partial | partial | CLI | CLI | CLI | API |
| **License** | commercial | commercial | commercial | GPL | AGPL/MIT | LGPL/free academic | MIT | GPL/commercial |

---

## 2. COMSOL 6.3

### 2.1 Mesh sequence node

COMSOL's meshing is a **sequence of operations** ("Mesh node": Free Tetrahedral → Boundary Layers → Refine → Distribute). Each step modifies the mesh; the sequence is replayable on parametric geometry sweeps.

### 2.2 Algorithm engines

- **Free Tetrahedral**: proprietary CDT, comparable to TetGen with Si–Shewchuk feature protection.
- **Free Triangular** (surface): LSCM-based parametric + Frontal-Delaunay.
- **Free Quad** (2-D): patch + advancing front.
- **Swept**: 2-D mesh extruded along axis; produces hex / prism.
- **Boundary Layers**: anisotropic prism extrusion, growth rate 1.2 default, smoothed via local solver.

### 2.3 Adaptive mesh refinement

- **Method**: solution-based, supports "Maximum number of refinements" and "Element selection" by residual or functional.
- **Refinement type**: longest-edge bisection or full regular refinement.
- **Goal-oriented**: "Functional" option since 5.5 (recovery-based dual estimator, not full DWR).

### 2.4 Physics-controlled meshing

The default mesh is chosen by *physics interface*: e.g., for incompressible CFD, COMSOL automatically prescribes:
- Tet elements (or hex if swept geometry).
- Boundary layers, $y^+\approx 1$ on no-slip walls.
- Higher refinement at inflow and walls.
- Growth rate 1.2.

Equivalent settings for different physics are documented in *COMSOL Reference Manual* §"Physics-Controlled Mesh."

### 2.5 Mesh import / export

- Imports: NASTRAN, ABAQUS .inp, ANSYS .cdb, Gmsh .msh, STL.
- Exports: same + COMSOL .mphtxt.
- Dirty STL handling: **limited** — fails on self-intersections; preprocess with MeshLab or fTetWild.

---

## 3. ANSYS 2024R2

### 3.1 Workbench Meshing

Three tet algorithms:
- **Patch Conforming Tet**: CDT-based, default for solid mechanics. Equivalent to TetGen.
- **Patch Independent Tet**: octree-based, ignores intermediate CAD features (replaces with mesh-resolved approximations). For dirty/multi-body assemblies.
- **MultiZone**: hex-dominant via block decomposition. Excellent for prismatic-bias geometry.

### 3.2 Fluent Meshing — Mosaic

The defining ANSYS meshing technology since 19R1 (2019). See [[07_Polyhedral_Mosaic_and_Voronoi]] §2.3. Key new since 2024R2:

- **Mosaic Poly-Hex Core** with anisotropic core refinement.
- **Polyhedral Boundary Layer** (2021R1+).
- **Watertight workflow** — handles dirty multi-body CAD via automatic gap-filling.
- **Wrapper meshing** (octree pre-wrap then Mosaic core).

Typical workflow for external aero:
```text
1. Import CAD / STL (multi-body OK).
2. Watertight surface wrap (octree-based).
3. Surface mesh.
4. Mosaic Poly-Hex volume mesh:
     - hex core (1.5× wall cells).
     - poly-BL layers near walls.
     - poly cells filling complex regions.
     - automatic Mosaic interfaces.
5. Quality check (orthogonality, skewness).
```

### 3.3 Mechanical adaptive

The Workbench Adaptive Solution feature does h-refinement with ZZ recovery, controlling **stress error** (or user-defined functional). It is the only commercial code with built-in adaptive solve for the standard FEM user.

### 3.4 Discovery Live AI acceleration

Since 2023R2, ANSYS Discovery uses a neural mesh-size predictor trained on the company's solution database; produces an initial mesh in seconds. The classical Mosaic solver then takes over for the production mesh. See [[13_ML_and_Neural_Mesh_Generation]] §5.

---

## 4. MATLAB R2024b — PDE Toolbox

### 4.1 `generateMesh` (3-D)

Calls TetGen under the hood with options:

| Option | Default | Meaning |
|---|---|---|
| `Hmax` | auto from BBox | maximum element size |
| `Hmin` | auto | minimum element size (clamps refinement) |
| `Hedge` | none | per-edge size (anisotropy hint) |
| `Hface` | none | per-face size |
| `Hgrad` | 1.5 | growth rate |
| `GeometricOrder` | "quadratic" (Tet10) | "linear" or "quadratic" |

### 4.2 `adaptmesh` — adaptive solver loop

```matlab
[u, mesh] = adaptmesh(model, ...
    'tol', 1e-4, ...
    'maxt', 10000, ...
    'ngen', 10, ...
    'rmethod', 'longest');
```

- Estimator: residual-based jump indicator (`pdejmps`) + optional recovery.
- Marking: top-$\theta$ by indicator.
- Refinement: longest-edge bisection.
- Available **2-D only** for full automation; 3-D requires manual loop.

### 4.3 New since R2023a

- **Anisotropic sizing via `Hedge`** with full metric tensor input.
- **`generateMesh` accepts STL** directly (since R2022b), with optional `Repair` flag.
- **Improved mesh quality post-processing**: ODT smoothing pass added.

### 4.4 Position relative to commercial competitors

MATLAB PDE Toolbox is excellent for **prototyping** and **education**; its 3-D meshing maturity lags COMSOL/ANSYS but the gap is closing. Use it for:
- Custom PDEs (Schrödinger, Maxwell variants) where the commercial physics is absent.
- Coupled with Optimization Toolbox for PDE-constrained design.
- Education / research with full algorithmic transparency.

---

## 5. Open-Source Stack — Production-Grade Combinations

### 5.1 Recommended stack for solid mechanics

```text
Gmsh 4.13 (surface mesh)
    → fTetWild 1.0 (robust volume tet from STL)
    → MMG 5.7 (anisotropic smoothing + adaptation)
    → custom solver (deal.II, MFEM, FEniCS, or PolyFEA)
```

### 5.2 Recommended stack for CFD

```text
Gmsh 4.13 (frontal-Delaunay surface + BL extrusion)
    → MMG3D (anisotropic adaptation driven by Hessian recovery)
    → OpenFOAM polyDualMesh (poly conversion, optional)
    → solver (OpenFOAM, SU2)
```

### 5.3 Recommended stack for biomedical / level-set

```text
Cleaver2 (isosurface stuffing, multi-material)
    → MMG3D (smoothing)
    → solver (FEBio, FEniCS)
```

### 5.4 Gmsh 4.13 highlights

- 3-D Frontal-Delaunay default (as of 4.0).
- `Mesh.MeshSizeFromCurvature = N` curvature-adaptive sizing.
- `Mesh.Algorithm3D = 10` HXT hex-dominant (Marot 2018) — fastest open-source hex.
- Python API: scripting and parameter sweeps.

---

## 6. Selection Heuristic

| Scenario | Recommendation |
|---|---|
| Solid mechanics, clean CAD, "just works" | COMSOL Free Tet OR ANSYS Patch Conforming |
| CFD with complex geometry, BL | **ANSYS Mosaic** (no equivalent OSS yet) |
| FEA on dirty STL from scan / mesh repair | **fTetWild** (no commercial equivalent) |
| Adaptive solve driven by QoI | COMSOL Functional OR deal.II + DWR |
| Anisotropic shock / boundary-layer adaptation | **MMG3D + feflo.a** |
| Parametric design exploration (1000+ runs) | ANSYS Discovery + Mosaic |
| Education / algorithm experimentation | MATLAB PDE Toolbox + custom adaptmesh loop |
| Custom FEM kernel (this project) | **fTetWild → MMG3D → PolyFEA Tet10** |

---

## 7. Version History — Major Meshing Releases

| Year | Tool | Release |
|---|---|---|
| 2015 | TetGen | 1.5 — CDT(3) with Si–Shewchuk feature protection |
| 2018 | Gmsh | 4.0 — Frontal-Delaunay as default 3-D mesher |
| 2018 | TetWild | SIGGRAPH paper — envelope-based robust tet from any input |
| 2019R1 | ANSYS Fluent | **Mosaic** technology released |
| 2020 | fTetWild | 10× faster than TetWild |
| 2021R1 | ANSYS Fluent | Polyhedral Boundary Layers |
| 2022R2 | ANSYS Fluent | explicit anisotropic adaptation |
| 2023a | MATLAB PDE Toolbox | full anisotropic sizing (Hedge metric tensor) |
| 2023R2 | ANSYS Discovery | AI sizing predictor (ML accelerator) |
| 2024b | MATLAB PDE Toolbox | ODT smoothing post-pass |
| 6.3 | COMSOL | improved physics-controlled meshing, VEM experimental |

---

## 8. References

- COMSOL, *Reference Manual* 6.3, chapters "Meshing" and "Adaptive Solver."
- ANSYS, *Fluent Meshing User's Guide* 2024R2.
- ANSYS, *Mechanical APDL Theory Reference* 2024R2, ch. 19 "Adaptive Solution."
- MathWorks, *PDE Toolbox User's Guide* R2024b.
- C. Geuzaine, J.-F. Rémacle, *Gmsh Reference Manual* 4.13.
- H. Si, *TetGen User's Manual* 1.6, 2015.
- C. Dapogny, *MMG Reference Manual* 5.7, INRIA, 2024.
- C. Marot, J. Pellerin, J.-F. Rémacle, "One machine, one minute, three billion tetrahedra," *IJNME* 117, 2019.
- Annotated bibliography in [[15_References_Bibliography]].
