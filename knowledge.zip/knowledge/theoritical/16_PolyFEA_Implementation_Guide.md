---
title: PolyFEA — Practical Implementation Guide
type: implementation
tags: [polyfea, implementation, tetgen, tet10, ielement, project-specific]
created: 2026-05-16
---

# 16 — PolyFEA: Practical Implementation Guide

This note bridges the algorithmic theory in notes [[00_Overview_and_Taxonomy]]–[[15_References_Bibliography]] to **the actual code** of this project (PolyFEA — C++ real-time FEA solver with OpenGL visualisation, see [theory.md](../theory.md)). It documents the current meshing pipeline, the precise places where each algorithm in the vault could be slotted in, and a concrete roadmap for upgrading the mesher without disturbing the existing solver kernel.

> [!note] Scope
> Focused on *meshing* only. The Newton-Raphson, CUDA assembly, and OpenGL visualisation paths are out of scope and well-documented in [theory.md](../theory.md).

---

## 1. Current Meshing Pipeline (May 2026 baseline)

```text
                ┌───────────────────────────────┐
                │  STL or 3MF                   │
                │  (STLLoader / ThreeMFLoader)  │
                └──────────────┬────────────────┘
                               │
                               ▼
                ┌───────────────────────────────┐
                │ FEAModel::processRawGeometry  │
                │  - vertex welding             │
                │  - optional decimation        │
                │  - bbox centering/scaling     │
                └──────────────┬────────────────┘
                               │
                               ▼
                ┌───────────────────────────────┐
                │ FEAModel::generateVolumetric  │
                │   build tetgenio in:          │
                │     - in.pointlist            │
                │     - in.facetlist (PLC)      │
                │   call tetrahedralize(b,in,out)│
                │   switches: "-pq{Q}a{V}A"     │
                └──────────────┬────────────────┘
                               │
                               ▼
                ┌───────────────────────────────┐
                │  out.tetrahedronlist (Tet4)   │
                │  ↓                            │
                │  optional generateMidEdgeNodes│
                │   → Tet10 by 1:1 splitting    │
                │  ↓                            │
                │  FEASolver assembly &         │
                │  Newton-Raphson solve         │
                └───────────────────────────────┘
```

### 1.1 Concrete TetGen invocation

From [src/FEAModel.cpp:506-588](../src/FEAModel.cpp):

- Input: surface triangle mesh stored as `surfaceVertices` + `surfaceIndices`.
- Output: tetrahedral mesh in `tetrahedra` (4 indices/tet) and optionally `tetrahedraQuadratic` (10 indices/tet).
- Switches assembled from `FEAParams.tetQuality` and `FEAParams.maxVolPercent` ([include/FEAData.h:12-15](../include/FEAData.h)):
  - `tetQuality = 1.4` → radius-edge bound $R/\ell_{\min} \le 1.4$
  - `maxVolPercent = 0.1` → max-volume cap as fraction of bbox volume

This places PolyFEA's mesher squarely in the **Delaunay refinement** family — see [[04_Delaunay_CDT_and_TetGen]] §4. The current configuration corresponds to standard Ruppert refinement plus TetGen's built-in sliver-removal (`-O` not currently passed; see §3.1 below).

### 1.2 Tet4 → Tet10 promotion

`FEAModel::generateMidEdgeNodes()` ([src/FEAModel.cpp](../src/FEAModel.cpp), [include/FEAModel.h:86](../include/FEAModel.h)) walks each Tet4 and inserts a node at the midpoint of every edge, using `edgeToMidNode` to share nodes between adjacent tets. This is **linear mid-edge promotion** — the simplest form of $p$-refinement (cf. [[11_Adaptive_Refinement_hp_and_DWR]] §5).

> [!warning] Straight-edge mid-node placement
> The current implementation places each mid-edge node at the geometric midpoint of its two parent corners. For elements on the curved B-rep boundary this introduces a $\mathcal{O}(h^2)$ geometric error at the surface — typically negligible for low-curvature mechanical parts, but problematic for any analysis requiring high geometric fidelity (acoustics, EM, sensitive contact). The fix is to **snap mid-edge boundary nodes back to the original surface** (NURBS evaluator or nearest-surface projection). See §4.3.

### 1.3 Element interface

`IElement` ([include/IElement.h](../include/IElement.h)) is the abstraction the assembler uses. Today, the concrete implementations are `TetrahedralElement` (Tet4) and `Tet10Element`. The interface is well-designed for swapping in new element types — see §5.

---

## 2. Where Each Vault Algorithm Fits

| Vault note | Code touch-point | Adoption effort | Payoff |
|---|---|---|---|
| [[02_Mesh_Quality_Metrics]] | extend [src/mesh_diag.cpp](../src/mesh_diag.cpp) — already has element validity & shape histograms | low | every mesh gets a quality report |
| [[04_Delaunay_CDT_and_TetGen]] | currently used; tune switches | none | tunes for the current geometry profile |
| [[06_Octree_BCC_and_Isosurface_Stuffing]] | new code path; gated by input type | medium | enables voxel/image input |
| [[08_Anisotropic_Metric_Adaptation]] | new `MeshAdaptor` class wrapping MMG3D | medium-high | order-of-magnitude DOF reduction for stress concentrators |
| [[09_Robust_TetWild_for_Dirty_Geometry]] | replace `generateVolumetricMesh()` call when STL is dirty | medium | unblocks scanned / non-manifold STL |
| [[11_Adaptive_Refinement_hp_and_DWR]] | new `AdaptiveSolver` wrapping current solver | high | best DOF-per-accuracy at runtime |
| [[12_Mesh_Smoothing_CVT_and_ODT]] | new post-TetGen ODT pass | low-medium | raise minimum dihedral, cut iteration count |

---

## 3. Quick Wins (Days, Not Weeks)

### 3.1 Pass `-O7` to TetGen for free quality

The default TetGen mesher does **not** run its built-in mesh-improvement loop unless told. Change in [src/FEAModel.cpp](../src/FEAModel.cpp):

```cpp
// Replace existing switches string construction with:
std::string switches = "-pq" + std::to_string(params.tetQuality) +
                       "a" + std::to_string(maxVol) + 
                       "AO7";   // +O7 enables full-strength quality optimisation
```

`-O7` runs ODT-style smoothing + edge swaps. Typical effect on PolyFEA's test parts: minimum dihedral $5°$–$8°$ → $15°$–$20°$, with no API change and ~10% extra meshing time. **Free lunch.**

### 3.2 Tighten radius-edge default

The current `tetQuality = 1.4` is the TetGen-recommended default. For structural FEA where condition number matters more than meshing time, `1.2` is more appropriate (see [[02_Mesh_Quality_Metrics]] §5 — sliver bound depends on this).

### 3.3 Implement Knupp-style quality report

Extend [src/mesh_diag.cpp](../src/mesh_diag.cpp) to compute Knupp's algebraic shape measure ([[02_Mesh_Quality_Metrics]] §1.5) and emit a per-element histogram. Lines of code: ~40.

```cpp
// Add to mesh_diag.cpp
double computeKnuppShape(const Eigen::Matrix<double,3,3>& J) {
    double det  = J.determinant();
    double frob = J.squaredNorm();        // trace(J^T J)
    if (frob < 1e-30) return 0.0;
    return 3.0 * std::cbrt(det * det) / frob;
}
```

### 3.4 Geometric fidelity check after Tet10 promotion

After `generateMidEdgeNodes()`, for every boundary mid-edge node, compute the distance from the geometric midpoint to the nearest point on the original surface mesh. If this exceeds `tau_h * h_local` (typical `tau_h = 0.01`), warn and optionally snap. ~30 lines of code; required if the project ever moves to acoustics / EM physics.

---

## 4. Medium-Term Roadmap

### 4.1 Adopt fTetWild for dirty input

The single highest-impact change. Detect "dirty" STL (self-intersection count, non-manifold edges, gap fraction) in `processRawGeometry`; if dirty, route through fTetWild instead of TetGen. See [[09_Robust_TetWild_for_Dirty_Geometry]] for details.

Integration sketch:
1. Add `ext/fTetWild` as a submodule (it builds with CMake + Eigen — same stack as PolyFEA).
2. Add `FEAModel::generateVolumetricMeshFTetWild(envelope, target_edge)` wrapping the C++ API.
3. In `generateVolumetricMesh()`, decide TetGen vs fTetWild based on input characteristics.

Expected impact: STL files that currently fail (3-D-scanned models, complex CAD exports) become mesh-able with no manual repair.

### 4.2 Add post-TetGen ODT smoothing

Even with `-O7`, TetGen's smoother is not state-of-the-art. A simple gradient-descent ODT pass ([[12_Mesh_Smoothing_CVT_and_ODT]] §4) over the interior nodes is ~80 lines of code:

```cpp
void smoothODT(std::vector<glm::vec3>& nodes,
               const std::vector<unsigned int>& tets,
               int iters = 10) {
    for (int it = 0; it < iters; ++it) {
        std::vector<glm::vec3> newPos(nodes.size(), glm::vec3(0));
        std::vector<double>    accumVol(nodes.size(), 0.0);
        for (size_t t = 0; t < tets.size(); t += 4) {
            auto a = nodes[tets[t]], b = nodes[tets[t+1]],
                 c = nodes[tets[t+2]], d = nodes[tets[t+3]];
            glm::vec3 centroid = 0.25f * (a + b + c + d);
            double vol = std::abs(glm::dot(glm::cross(b-a, c-a), d-a)) / 6.0;
            for (int k = 0; k < 4; ++k) {
                int n = tets[t+k];
                newPos[n] += float(vol) * centroid;
                accumVol[n] += vol;
            }
        }
        for (size_t n = 0; n < nodes.size(); ++n) {
            if (isBoundaryNode(n) || accumVol[n] < 1e-30) continue;
            nodes[n] = newPos[n] / float(accumVol[n]);
        }
    }
}
```

Boundary nodes are pinned; the smoother lifts worst-case dihedral by another $5°$–$10°$ typically.

### 4.3 Curved Tet10 (surface-projecting mid-nodes)

For real curvature fidelity in Tet10, replace the linear mid-edge interpolation in `generateMidEdgeNodes()` with a **projection back to the original surface mesh** for boundary edges. Required steps:

1. Keep a `BoundarySurface` structure (the input `surfaceVertices`/`surfaceIndices` after welding) accessible during promotion.
2. For each candidate mid-edge: if both endpoints are surface nodes AND share a common surface triangle, project the midpoint onto that triangle's plane (or onto a NURBS chart if available).
3. Verify Jacobian positivity at the integration points after projection; reject and revert if any tet becomes inverted.

This converts the Tet10 from a *subparametric* (straight-edge) to a *isoparametric* (curved-edge) element — true second-order geometric accuracy.

### 4.4 Mesh size field from curvature

Currently the only sizing control is the global `maxVolPercent`. For high-curvature regions, a local refinement is wasted. Add a per-vertex sizing field computed from local discrete curvature:

```cpp
double h_target(const Vertex& v) {
    double kappa = discreteCurvature(v);   // cotangent-Laplacian based
    return std::clamp(2.0 * sin(theta_max/2.0) / std::max(kappa, 1e-3),
                      h_min, h_max);
}
```

Pass this to TetGen via the `-m` switch (with a `pointmtrlist` field on `tetgenio`). Typical impact: 30–50% node-count reduction on curved geometries at no quality cost.

### 4.5 Adaptive cycle (h-refinement with ZZ)

Sketch in [[11_Adaptive_Refinement_hp_and_DWR]] §9. Reuses the existing `IElement::ComputeStiffnessMatrix` pathway. Adding ZZ recovery + Dörfler marking + a TetGen remesh call is ~300 lines, no change to the solver kernel.

Outline:
1. After Newton-Raphson convergence in `FEASolver::solve()`, recover the stress field $\sigma^*$ by patch projection.
2. Compute per-element ZZ indicator $\eta_T$.
3. Dörfler-mark elements summing to fraction $\theta=0.3$ of total indicator.
4. Pass the marked elements as **internal refinement constraints** to a re-meshing call (TetGen's `-r` flag with an `area` field).
5. Project the previous solution onto the new mesh as warm-start.
6. Re-run Newton-Raphson.
7. Iterate until $\eta_{\text{global}} < \tau$.

---

## 5. Long-Term: Add a Hex / Polyhedral Element

The `IElement` interface is element-agnostic (see [include/IElement.h:30-79](../include/IElement.h)). Adding a Hex8 / Hex20 element is straightforward at the interface level — the meshing is the hard part (see [[10_Hex_QuadMeshing_FrameFields]]).

For a project of PolyFEA's scope, the realistic options are:

1. **Hex via sweep** — for simple geometries that can be parametrised as extrusions. Add a `SweptHexElement` and a sweep mesher around the surface contour. ~2 weeks of work.
2. **Polyhedral via VEM** — for general geometries. Implement a Wachspress or VEM polyhedral element. ~2 months of work and significant theoretical machinery (see [[07_Polyhedral_Mosaic_and_Voronoi]] §6).
3. **External hex meshing** — use HexBox or Cubit to pre-mesh hex, import the result, and add `Hex8Element`. ~3 days for the element class, no meshing development.

For PolyFEA's current "real-time FEA visualisation" positioning, option (1) is the best ratio of effort to user value.

---

## 6. Recommended Next Action (single sentence)

Add `-O7` to the TetGen switch string (§3.1), implement the Knupp shape report in `mesh_diag.cpp` (§3.3), and add a post-TetGen ODT smoothing pass (§4.2) — a one-day change that lifts every PolyFEA mesh's worst-case dihedral by $\sim 15°$ and surfaces quality regressions immediately.

---

## 7. Files Inventory (Mesh-Related)

| File | Role |
|---|---|
| [src/FEAModel.cpp](../src/FEAModel.cpp) | `generateVolumetricMesh()`, `generateMidEdgeNodes()`, TetGen driver |
| [src/tetgen.cxx](../src/tetgen.cxx) | TetGen 1.6 (vendored) |
| [src/predicates.cxx](../src/predicates.cxx) | Shewchuk's robust geometric predicates ([[04_Delaunay_CDT_and_TetGen]] §5) |
| [src/mesh_diag.cpp](../src/mesh_diag.cpp) | quality reporting; **extend here** for Knupp / dihedral / scaled Jacobian |
| [src/STLLoader.cpp](../src/STLLoader.cpp), [src/ThreeMFLoader.cpp](../src/ThreeMFLoader.cpp) | input parsers |
| [src/Tet10Element.cpp](../src/Tet10Element.cpp) | Tet10 stiffness / internal force |
| [include/IElement.h](../include/IElement.h) | element abstraction — preserve when adding hex / poly |
| [include/Tet10Element.h](../include/Tet10Element.h), [include/TetrahedralElement.h](../include/TetrahedralElement.h) | concrete element classes |
| [include/FEAData.h](../include/FEAData.h) | `FEAParams` — extend here for sizing/adapt knobs |

---

## 8. References

- This vault: [[00_Overview_and_Taxonomy]] for the algorithm landscape, then jump to the specific note relevant to the change being considered.
- Project [theory.md](../theory.md) §1–3 for the FEM weak form and assembly machinery.
- TetGen 1.6 user manual (Si 2020) for the full switch list.
