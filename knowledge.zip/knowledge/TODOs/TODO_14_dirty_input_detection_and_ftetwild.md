# TODO_14 — Dirty input detection + fTetWild fallback

## Goal
Detect dirty STL inputs (self-intersections, non-manifold edges, gaps, flipped normals); visualise dirty regions; auto-route to fTetWild when detected. Where baseline TetGen previously threw, the user now gets a successful mesh.

## Files added / modified
- **Add** `include/DirtyInputDetector.h`, `src/DirtyInputDetector.cpp`.
- **Add** `include/FTetWildAdapter.h`, `src/FTetWildAdapter.cpp`.
- **Add** `ext/fTetWild/` as `FetchContent` from https://github.com/wildmeshing/fTetWild (pin SHA).
- **Modify** `CMakeLists.txt` — fTetWild dep, link to `FEAPreProcessor`.
- **Modify** `src/FEAModel.cpp::generateVolumetricMesh()` — branch on dirty-detect result; call fTetWild if dirty.
- **Modify** `src/ShaderSources.h` — overlay shader for highlighting dirty triangles (semi-transparent red).
- **Add** `assets/test_fixtures/dirty_self_intersect.stl` — known-dirty fixture (12 self-intersecting triangles).

## Algorithm summary
From [knowledge/09_Robust_TetWild_for_Dirty_Geometry.md](knowledge/09_Robust_TetWild_for_Dirty_Geometry.md) and plan Appendix Phase C.4, C.5, C.6:

**STEP source — early-out** (when `model.hasBRep()`, from TODO_04):
A retained B-rep from STEP is clean by construction (post-`ShapeFix_Shape` healing in TODO_04). Skip the dirty-input check entirely and route directly to TetGen. Log: `[DirtyDetect] source: STEP B-rep — skipping check (clean by construction); routing to TetGen`. The dirty-detection BVH cost is non-trivial; this saves it.

**Dirty detection** (STL / 3MF only):
```text
DirtyMetrics analyseInput(surfaceVertices, surfaceIndices):
    selfIntersections = 0
    #pragma omp parallel for schedule(dynamic, 256) reduction(+:selfIntersections)
    for each face f_i:
        for each f_j in spatial BVH neighbours of f_i:
            if triangleTriangleIntersect(f_i, f_j) && !shareVertex(f_i, f_j):
                selfIntersections++

    nonManifoldEdges = countEdgesWithValence != 2
    flippedNormals = detectViaWindingNumberAtBboxCenter()
    gapFraction = boundaryEdgesLength / totalEdgesLength

    isDirty = (selfIntersections > 0 || nonManifoldEdges > 0
               || flippedNormals || gapFraction > 0.001)
    return {isDirty, selfIntersections, nonManifoldEdges, flippedNormals, gapFraction}
```

BVH: use meshoptimizer's spatial-sort helper (already a dep).

Triangle-triangle intersection: Möller 1997 (~30 lines, robust enough with double precision since bbox-normalised inputs).

**fTetWild adapter** ([knowledge/09_Robust_TetWild_for_Dirty_Geometry.md §3-4](knowledge/09_Robust_TetWild_for_Dirty_Geometry.md)):
```text
FTetWildAdapter::run(surfaceVertices, surfaceIndices, params, featureGraph):
    floatTetWild::Mesh mesh;
    floatTetWild::Parameters fParams;
    fParams.eps_input_rel = params.fTetWildEnvelopeRatio
    fParams.edge_length_rel = derived from sizingPerVertex (if any) or default
    fParams.coarsen = true
    fParams.smooth_open_boundary = true
    if (featureGraph non-empty):
        fParams.preserve_global_cut_mesh = true
        fParams.input_surface.edges_to_preserve = featureGraph.ridges
        fParams.eps_input_rel *= 0.5  // tighter near features
    if (params.enableMultiMaterial): fParams.input_tags = perTriangleMaterialId

    floatTetWild::tetrahedralization(surfaceVertices, surfaceIndices, fParams, mesh)
    extract tetVertices, tetIndices from mesh
    return (tetVertices, tetIndices)
```

**Routing in `generateVolumetricMesh()`:**
```cpp
// STEP early-out: B-rep is clean by construction (post-healing in TODO_04)
if (model.hasBRep()) {
    std::cout << "[Mesh] STEP source — skipping dirty check; TetGen direct\n";
    // ... TetGen path
} else {
    auto dirty = DirtyInputDetector::analyse(surfaceVertices, surfaceIndices);

    if (params.autoDetectDirtyInput && dirty.isDirty && params.enableFTetWildFallback) {
        std::cout << "[Mesh] dirty input detected (" << dirty.selfIntersections
                  << " self-ints, " << dirty.nonManifoldEdges << " non-manifold edges); "
                  << "routing to fTetWild" << std::endl;
        return FTetWildAdapter::run(*this, params, featureGraph);
    }
    // ... existing TetGen path
}
```

## Multithreading
- Self-intersection check: per-pair parallel-for with `reduction(+:counter)`.
- fTetWild is OMP-internal — set `omp_set_num_threads(params.numThreads)` before the call.
- Runs inside the AsyncTask from TODO_13 → progress bar visible during fTetWild stages.

## Numerical care points
- Triangle-triangle intersection robustness: snap inputs to a small epsilon grid before testing (avoids near-coplanar pathologies). fTetWild internally handles its own robustness.
- fTetWild envelope `eps_input_rel` default `1e-3 of L_diag` (note [[09]] §6); too small blows up cost, too large loses sharp features.
- Multi-material flag is opt-in (default false) — most users don't have tagged input.

## Screen-visible acceptance check

**Setup** Load `assets/test_fixtures/dirty_self_intersect.stl` (known-dirty test fixture with 12 self-intersecting triangles).

**Action** Click `Generate 3D Mesh`.

**Expected**
- Before meshing: viewer overlays the 12 self-intersecting triangles in semi-transparent red.
- Console:
  ```text
  [DirtyDetect] self-ints: 12   non-manifold edges: 4   gap fraction: 0.001
  [DirtyDetect] dirty input — routing to fTetWild (envelope 1.0e-3 of L_diag)
  ```
- Progress bar shows fTetWild stages (multiple sub-stages).
- After completion: valid mesh visible; quality report PASS.
- Re-running with `autoDetectDirtyInput = false`: TetGen path used, throws/fails (the baseline regression).

**Failure modes**
- Red overlay missing → BVH lookup result not stored / not drawn.
- `dirty: false` despite obvious badness → triangle-triangle intersection test broken.
- fTetWild crashes → params not in expected ranges; envelope too small for input scale.

**Pass criterion** Red overlay visible AND fTetWild succeeds AND quality PASS — where baseline TetGen fails.

## Regression sentinel
`regression/ftetwild_dirty.txt` — dirty-detect counts + fTetWild output node/tet count + quality report verdict.

## Depends on
TODO_12 (sizing field passing through), TODO_13 (progress UI for fTetWild stages).

## Estimated effort
3 days (fTetWild build integration is the bulk; CMake compatibility on MSVC may need patching).
