# TODO_07 — Stellar topology operators (2-3 / 3-2 / 4-4 flips)

## Goal
A `Remove Slivers (Stellar)` button runs Klingner–Shewchuk-style topology operators on the tet mesh, eliminating slivers that pure node-relocation (TODO_06) cannot fix.

## Files added / modified
- **Modify** `include/MeshSmoother.h`, `src/MeshSmoother.cpp` — add `class TopologyOptimizer`.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — `Remove Slivers` button.

## Algorithm summary
From [knowledge/12_Mesh_Smoothing_CVT_and_ODT.md §5](knowledge/12_Mesh_Smoothing_CVT_and_ODT.md) and plan Appendix Phase B.2:

```text
build globalFaceMap: face -> {incident tets}
build globalEdgeMap: edge -> {incident tets}
build priority queue PQ ordered by worst-element Knupp q (max-heap)

opCount = 0
while !PQ.empty() and opCount < stellarMaxOps:
    T = PQ.top(); PQ.pop()
    if q(T) > acceptable_threshold: break
    try in order: 2-3, 3-2, 4-4 around T's edges
    if any flip improved min(q) of affected tets (all incident, all validity-checked):
        commit flip; update face/edge maps; re-enqueue affected tets
        opCount++
    else: skip
```

Three operator definitions (Lawson 1972, Joe 1989):
- **2-3 flip**: 2 tets sharing face $\{a,b,c\}$ → 3 tets sharing edge between the two apexes $d, e$.
- **3-2 flip**: inverse.
- **4-4 flip**: 4 tets around an interior edge → 4 tets around a different edge in the same cluster.

## Multithreading
- Initial face/edge map build: per-tet OMP parallel-for; map merges with thread-local maps then serial reduce.
- The operator loop itself is **sequential** for the initial implementation (operations are non-commutative and the priority queue is a critical section). Future optimisation: conflict-graph red-black colouring of disjoint flips — flagged in plan Appendix Phase B.2 as deferred to MMG-class throughput need.
- Quality re-evaluation after each flip is OMP-parallel over affected (typically $\le 6$) tets — negligible.

## Numerical care points
- **Exact predicates for flip validity** (care-point #1). Using double comparisons here silently flips into inverted configurations.
- 3-2 flip validity: the 5 vertices' convex hull must contain the edge being removed. Cheap to check via 5 `orient3d` calls.
- Update face/edge maps **before** re-enqueuing affected tets, or you'll see stale references and a hard crash.

## Screen-visible acceptance check

**Setup** Run TODO_06; some slivers may remain.

**Action** Click `Remove Slivers (Stellar)`.

**Expected console**
```text
[Stellar] flips applied: 2-3:127  3-2:84  4-4:32   q_min: 0.35 → 0.61
```
HUD shows the previously red elements gone (replaced by adjacent better-quality tets).

**Failure modes**
- `0 flips applied` → quality-improvement check too strict, or face/edge map not built correctly.
- Mesh becomes inverted → flip validity uses double comparison instead of exact `orient3d`.
- Crash inside flip → face/edge map not updated between flips (stale references).

**Pass criterion** Console shows non-zero flip counts AND $q_{\min}$ improved AND no inversions.

## Regression sentinel
`regression/stellar_bracket.txt` — flip counts + final q_min on `bracket_dirty.stl`.

## Depends on
TODO_06.

## Estimated effort
3 days.
