# Q&A — OpenCASCADE, STEP Visualisation, and FEA Meshing

**Date:** 2026-05-19
**Task:** TODO_04 (STEP loader + analytic B-rep retention)
**Topic:** How OCCT works; why STEP files still show triangulation lines; whether FEA meshing uses ideal geometry

## Related Theory

| Theory file | What it contributes to this Q&A |
|---|---|
| [00 Overview and Taxonomy](theoritical/00_Overview_and_Taxonomy.md) | §1 "CAD B-rep with sharp features" geometry class — the decision that routes STEP input to CDT+AFM meshing rather than any other family |
| [03 Surface Meshing on Curved Manifolds](theoritical/03_Surface_Meshing_Curved_Manifolds.md) | NURBS B-rep conforming meshing; chord-error controlled tessellation (what `BRepMesh_IncrementalMesh` implements); restricted CVT on surfaces as the theoretical ideal behind adaptive triangle generation |
| [04 Delaunay CDT and TetGen](theoritical/04_Delaunay_CDT_and_TetGen.md) | The CDT(3) algorithm TetGen runs on the OCCT tessellation — why constrained facets force TetGen to respect the STEP boundary and why denser OCCT triangles cause longer meshing times |
| [02 Mesh Quality Metrics](theoritical/02_Mesh_Quality_Metrics.md) | Hausdorff distance and radius-edge ratio — the fidelity metrics computed by `computeFidelity()` and discussed in Q3/Q4 |
| [08 Anisotropic Metric Adaptation](theoritical/08_Anisotropic_Metric_Adaptation.md) | The `sizingChordError` parameter is a chord-length sizing field — anisotropic metric theory explains why it produces fewer triangles on flat faces and more on high-curvature ones |
| [11 Adaptive Refinement hp and DWR](theoritical/11_Adaptive_Refinement_hp_and_DWR.md) | §5 linear mid-edge promotion (Tet4→Tet10) and the note on snapping mid-edge boundary nodes to the analytic surface — directly corresponds to Q3's "what would make FEA truly geometry-exact?" |
| [16 PolyFEA Implementation Guide](theoritical/16_PolyFEA_Implementation_Guide.md) | Full pipeline code map — `StepLoader`, `BRepHandle`, `generateMidEdgeNodes`, fidelity check — bridges all of the above theory to the actual implementation |

---

## Q1: How does OpenCASCADE work?

OpenCASCADE (OCCT) is a C++ geometry kernel that stores shapes as **exact mathematics**, not triangles. The representation is called **B-rep (Boundary Representation)**:

| Entity | What it is |
|--------|-----------|
| **Face** | A bounded surface patch described by an exact equation: plane, cylinder, sphere, torus, NURBS surface, etc. |
| **Edge** | A curve where two faces meet: line, circle, ellipse, NURBS curve, etc. |
| **Vertex** | An endpoint of an edge — a single 3D point with an associated tolerance |
| **Topology** | The connectivity: which edges bound which face, which vertices terminate which edge, face orientation relative to the solid |

When a STEP file is loaded (`StepLoader::loadWithBRep`):
1. `STEPControl_Reader` parses the STEP text and reconstructs each face/edge/vertex as analytic math
2. `ShapeFix_Shape` heals the result — closes gaps, fixes inconsistent vertex tolerances, corrects face orientations
3. `BRepMesh_IncrementalMesh` tessellates the exact surfaces into triangles, controlled by chord-error and angular-deflection parameters
4. The tessellation is used for display and as the FEA surface boundary input (given to TetGen)
5. The original analytic B-rep is retained in `FEAModel::brep` for exact geometry queries

---

## Q2: Why do STEP files still show lines like an STL file?

**OpenGL can only draw triangles.** Even though the geometry is stored as exact math internally, it must be converted to a triangle mesh to be rendered on screen. The lines you see are wireframe edges of those triangles.

The critical difference from STL is **tessellation quality and provenance**:

| | STL | STEP via OCCT |
|---|---|---|
| Triangle source | Baked by the CAD exporter; fixed at export time | Re-generated from exact math by OCCT at load time |
| Quality control | Exporter's settings; often coarse | Our `sizingChordError` parameter (default: 0.1% of bbox diagonal) |
| Flat faces | Could have many redundant triangles | Always 2 triangles (minimum) |
| Curved faces | Fixed by exporter | Adaptive: as many triangles as needed to stay within chord error |

So the lines are still visible because tessellation is unavoidable for OpenGL rendering — but the triangles are much finer on curved surfaces and represent the true geometry far more accurately than a typical STL export.

To reduce the visual appearance of lines: lower `sizingChordError` (finer tessellation) or disable wireframe overlay (`showWireframe = false`).

---

## Q3: Is the FEA mesh based on the ideal/exact geometry?

**Partially yes, partially no.** Here is the exact breakdown by stage:

| Stage | Geometry used | Based on exact B-rep? |
|-------|--------------|----------------------|
| **Display** | OCCT tessellation triangles | Derived from exact B-rep, but is an approximation |
| **FEA surface mesh boundary** | Same OCCT tessellation triangles | Derived from exact B-rep; much better than STL |
| **FEA volume mesh** | Tet elements filling the volume bounded by the surface triangles | Inherits quality of the surface mesh |
| **Fidelity check — forward pass** | `BRepExtrema_DistShapeShape` queries the true analytic surface | **Yes — exact** |
| **Fidelity check — reverse pass** | `TriBVH` against the tessellation | No — discrete approximation |

### What this means in practice

- The FEA *domain boundary* is the tessellation, not the exact surface. The tet mesh conforms to the tessellation triangles, not to the analytic faces.
- However, because OCCT generates the tessellation at 0.1% chord error (vs. typical STL exporters at 0.5–2%), the boundary is already 5–20× closer to the true surface than a typical STL import.
- The *fidelity measurement* (Hausdorff distance reported after meshing) is computed against the **true analytic geometry** using `BRepExtrema_DistShapeShape`. This is 2–3 orders of magnitude more accurate than measuring against the tessellation BVH. That is the primary motivation for retaining the B-rep in `FEAModel::brep`.

### What would make the FEA truly geometry-exact?

**Curved finite elements** — specifically, snapping the mid-side nodes of tet10 elements to the analytic surface using `BRepExtrema_DistShapeShape`. This is standard in isogeometric analysis (IGA). The current implementation uses linear boundary representation even for curved geometry. This is a potential future TODO.

---

## Key code references

| Concept | Location |
|---------|----------|
| OCCT tessellation parameters | `src/StepLoader.cpp` — `BRepMesh_IncrementalMesh(shape, linDef, false, 0.3, true)` |
| Chord error setting | `include/FEAData.h` — `FEAParams::sizingChordError = 1e-3f` |
| Exact nearest-point query | `src/BRepHandle.cpp` — `BRepHandle::nearestPointOnShape()` |
| Fidelity using exact B-rep | `src/MeshQuality.cpp` — `computeFidelity(ref, brep, out, p)` |
| B-rep retained on model | `include/FEAModel.h` — `std::unique_ptr<BRepHandle> brep` |

---

---

## Q4: What is tessellation?

Tessellation is the process of approximating a smooth mathematical surface with a mesh of flat triangles.

The word comes from Latin *tessella* — a small square tile used in Roman mosaics. A mosaic represents a continuous image using discrete tiles; tessellation represents a continuous curved surface using discrete flat triangles.

**Why is it necessary?**
GPU hardware (and therefore OpenGL) natively processes only one primitive: the triangle. A triangle is defined by 3 vertices and is always flat. There is no "curved surface" primitive in OpenGL. So before anything can be drawn on screen — whether it came from STL, STEP, OBJ, or any other format — it must first be converted into triangles.

**What does OCCT's tessellation do specifically?**
`BRepMesh_IncrementalMesh` walks over every analytic face in the B-rep and samples the surface at parameter values (u, v) chosen so that:
- The chord error (distance from the triangle edge to the true curve) stays below `linDef` (= `sizingChordError × bboxDiagonal`)
- The angular deflection between adjacent triangle normals stays below `angDef` (0.3 rad)

Flat faces (planes) need only 2 triangles. A sphere needs hundreds to meet the chord error budget. The result is an adaptive triangle mesh that represents the true surface within a known tolerance.

---

## Q5: If STEP is also converted to triangles, how is it still more accurate than STL?

The difference is **when** the conversion happens and **who controls it**.

### STL — tessellation baked at export time

When you export STL from Fusion 360 or SolidWorks:
1. The CAD software tessellates the geometry at that moment
2. The triangle quality depends on whatever export settings were chosen (often optimised for file size, not accuracy)
3. The STEP triangles are written to disk — the original analytic geometry is **discarded**
4. Your app reads those triangles. They are all you have. You cannot improve them.

It is like printing a photo at low resolution and then trying to zoom in later — the detail is gone.

### STEP via OCCT — tessellation at load time from exact math

1. The STEP file stores the exact analytic description of every face (NURBS control points, plane equations, cylinder radii, etc.)
2. Your app reads those analytic descriptions and rebuilds the true geometry in memory
3. OCCT tessellates fresh from that exact math using **your** chord-error setting
4. The triangles are as accurate as your `sizingChordError` parameter says — and you can change it
5. The original analytic B-rep is kept alive in `FEAModel::brep` for exact queries at any time

### The accuracy advantage is twofold

**A — better surface triangles:**
OCCT's adaptive tessellation guarantees every triangle is within 0.1% of the true surface (at default settings). A typical STL export may be 0.5–2% or coarser. On a sphere of radius 1m, that is the difference between ≈1mm error and ≈10mm error on the FEA boundary.

**B — exact fidelity reference:**
STL has no reference geometry. When you measure how well the FEA mesh matches the input, you can only compare tet faces against STL triangles — which are already approximate. With STEP, `BRepExtrema_DistShapeShape` queries the **true analytic surface** — a sphere query returns the exact distance to the mathematical sphere, not to a triangle approximating it. This is 2–3 orders of magnitude more accurate on curved faces.

---

## Q6: Why does STEP meshing take much longer than STL?

Several compounding reasons:

### 1. OCCT tessellation is expensive
`BRepMesh_IncrementalMesh` must evaluate NURBS surface equations at many (u, v) parameter values to stay within the chord error. A complex STEP with many curved faces can take seconds for tessellation alone. STL skips this step entirely — triangles are already on disk.

### 2. Shape healing runs first
`ShapeFix_Shape` examines and repairs tolerance inconsistencies, open edges, and bad face orientations before tessellation. This is a non-trivial graph operation on the B-rep topology.

### 3. More surface triangles → larger TetGen problem
OCCT's adaptive tessellation typically produces a denser surface mesh on curved geometry than a typical STL export. TetGen receives more boundary triangles → more constrained facets → more Delaunay refinement iterations. TetGen's complexity is roughly O(n log n) to O(n²) in practice, so surface mesh density has a super-linear effect on volume mesh generation time.

### 4. Better mesh quality = more refinement passes
A denser, more accurate boundary lets TetGen insert more Steiner points to improve element quality — which is the right trade-off for FEA accuracy, but costs more time.

### 5. Fidelity check with exact B-rep queries
`BRepExtrema_DistShapeShape` costs ~0.1–1ms per query depending on shape complexity. For 40k sample points that is 4–40 seconds even with OpenMP parallelisation. This is a one-time quality check, not per-frame — but it is included in the total "load + mesh" time you observe.

### Summary table

| Step | STL | STEP |
|------|-----|------|
| Parse file | Fast (binary triangles) | Fast (text, but more structure) |
| Shape healing | — | Seconds on complex geometry |
| Tessellation | — (already done) | Seconds (NURBS evaluation) |
| Surface mesh to TetGen | Small (STL triangles) | Larger (adaptive, denser on curves) |
| TetGen meshing | Faster (fewer constraints) | Slower (more constraints, more refinement) |
| Fidelity check | BVH query — fast | BRepExtrema exact query — 4–40s |

---

## Q7: How does OpenGL render the black tessellation lines?

The wireframe lines are drawn by a second render pass using the same triangle index buffer. Here is exactly what happens in this codebase:

### Setup (once at startup — `main.cpp` line 171–172)
```cpp
glEnable(GL_POLYGON_OFFSET_LINE);
glPolygonOffset(-1.0f, -1.0f);
```
`GL_POLYGON_OFFSET_LINE` tells OpenGL to shift the depth value of line-mode geometry slightly toward the camera. Without this, the line pixels and the fill pixels land on exactly the same depth value — a condition called **z-fighting** — and the result is a flickering, noisy mess where pixels randomly choose which draw wins. The offset of `(-1, -1)` moves lines slightly in front of the filled surface so they always win the depth test cleanly.

### Render loop (per frame — `FEAModel.cpp` lines 456–468)
```cpp
// Pass 1: filled surface
glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
shader.setVec3("objectColor", 0.75f, 0.75f, 0.75f);   // light grey
glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

// Pass 2: wireframe lines
if (showWireframe) {
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    shader.setVec3("objectColor", 0.1f, 0.1f, 0.1f);  // near-black
    glLineWidth(1.5f);
    glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
}

glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);  // restore state
```

`glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)` is the key call. It instructs OpenGL's rasterizer to interpret each triangle primitive as 3 line segments (its 3 edges) instead of a filled area. The same index buffer and vertex buffer are reused — nothing changes except the rasterization mode. OpenGL draws the outline of every triangle in the near-black color with 1.5px width.

### Why you see lines on every triangle edge, not just silhouettes
Because `glPolygonMode(GL_LINE)` draws **all** triangle edges — interior shared edges between adjacent triangles are drawn the same as boundary edges. This is why you see the full internal triangulation, not just the mesh outline. To draw only silhouette edges, you would need a geometry shader or a pre-computed edge list that filters out non-silhouette edges — a significantly more complex technique.

### Toggle
Press **M** in the app to toggle `showWireframe` on/off (line 795 in `main.cpp`).

---

## Implementation — Code Location and Data Flow

### Classes and methods involved

| Class / method | File | Role |
|---|---|---|
| `FEAModel::loadFile(filepath)` | [src/FEAModel.cpp:226](../src/FEAModel.cpp) | Entry point — dispatches by file extension |
| `FEAModel::loadSTEP(filepath)` | [src/FEAModel.cpp:212](../src/FEAModel.cpp) | STEP-specific loader; wires StepLoader + BRepHandle together |
| `StepLoader::loadWithBRep(path, out, brep_out, params)` | [src/StepLoader.cpp:278](../src/StepLoader.cpp) | Tessellates STEP; returns welded triangles + analytic B-rep |
| `loadSTEP_impl(path, out, impl, params)` | [src/StepLoader.cpp:159](../src/StepLoader.cpp) | Core OCCT calls: read → heal → tessellate → harvest |
| `harvestTriangles(shape, faceMap, out, triangleFaceId)` | [src/StepLoader.cpp:98](../src/StepLoader.cpp) | Walks every `TopoDS_Face`, converts `Poly_Triangulation` to `LoadedGeometry` |
| `BRepHandle::create(impl)` | [include/BRepHandle.h:55](../include/BRepHandle.h) | Factory: wraps `Impl` (the live OCCT shape) into a heap-allocated `BRepHandle` |
| `BRepHandle::nearestPointOnShape(query)` | [include/BRepHandle.h:45](../include/BRepHandle.h) | Exact OCCT `BRepExtrema_DistShapeShape` nearest-point query |
| `MeshQuality::emitFidelityReport(ref, brep, out, p)` | [include/MeshQuality.h:190](../include/MeshQuality.h) | BRep-exact Hausdorff: forward pass via `nearestPointOnShape`, reverse via `TriBVH` |

### Stupid-clerk data flow

Think of it as passing envelopes between desks:

**Desk 1 — `FEAModel::loadFile`** receives `filepath` (a `std::string`). Sees extension `.step` → slides the string to Desk 2.

**Desk 2 — `FEAModel::loadSTEP`** [src/FEAModel.cpp:212] prepares two empty boxes:
- `LoadedGeometry geo` — will hold the welded triangle mesh
- `std::unique_ptr<BRepHandle> newBrep` — will hold the analytic NURBS shape

Hands both to Desk 3 along with `this->params` (a `FEAParams` carrying `sizingChordError = 1e-3f`).

**Desk 3 — `StepLoader::loadWithBRep`** [src/StepLoader.cpp:278] creates a third internal box `BRepHandle::Impl impl` and passes the whole stack down to Desk 3a.

**Desk 3a — `loadSTEP_impl`** [src/StepLoader.cpp:159]:
1. `STEPControl_Reader::ReadFile(path)` → internal OCCT `TopoDS_Shape shape` (the full analytic geometry)
2. `healShape(shape)` — fixes open edges, bad face orientations in-place on `shape`
3. `linDef = params.sizingChordError × Ldiag` [line 211] — chord-error budget in absolute units (e.g. 0.1% × bounding-box diagonal)
4. `BRepMesh_IncrementalMesh mesher(shape, meshParams)` [line 229] — tessellates all analytic faces of `shape`; triangles are stored **inside** each face's `Poly_Triangulation` handle
5. `harvestTriangles(shape, impl.faceMap, out, triangleFaceId)` [line 234]:
   - Loops over every `TopoDS_Face` in `shape`
   - `BRep_Tool::Triangulation(face, loc)` → `Handle(Poly_Triangulation) tri`
   - `Welder::add(x,y,z)` welds coincident vertices → fills `out.positions` (`std::vector<glm::vec3>`)
   - Pushes three indices per triangle into `out.indices` (`std::vector<unsigned int>`)
6. `impl.shape = shape` [line 243] — the full analytic B-rep is stored inside `impl`

**Desk 3 resumes**: `brep_out = BRepHandle::create(std::move(impl))` [src/StepLoader.cpp:286] — `impl` (containing `shape`, `faceMap`, `edgeMap`, `vertexMap`) moves into a heap-allocated `BRepHandle`. `brep_out` (= `newBrep` at Desk 2) now points to it.

**Desk 2 resumes**: [src/FEAModel.cpp:217–218]
- `processRawGeometry(geo, "STEP")` consumes `geo`: positions and indices go through decimation, OpenMP normals, AABB scale → written into `this->surfaceVertices` (`std::vector<Vertex>`) and `this->surfaceIndices` (`std::vector<unsigned int>`), uploaded to GPU
- `this->brep = std::move(newBrep)` — the `BRepHandle` is now stored permanently on `FEAModel`

**Later — Desk 4 — `FEAModel::generateVolumetricMesh`** [src/FEAModel.cpp:537]:
- Snapshots `this->surfaceVertices[i].position` → `this->refSurfaceForFidelity.positions` [line 547–551]
- `tetrahedralize(&b, &in, &out)` → TetGen populates `tetgenio out` (`out.pointlist`, `out.tetrahedronlist`, `out.trifacelist`)
- `this->hasBRep()` checks `brep != nullptr` [line 648]:
  - **BRep path** → `MeshQuality::emitFidelityReport(refSurfaceForFidelity, *brep, out, params)` [line 649]
    - Forward pass: samples tet-boundary faces → calls `brep->nearestPointOnShape(query)` (exact NURBS) → distance per sample
    - Reverse pass: BVH (`TriBVH`) on `refSurfaceForFidelity.positions/indices`
    - Fills `FidelityReport` struct: `hausdorffMax`, `hausdorffP95`, `normalDev_p50/p95/p99/max`, `usedExactBRep = true`
    - Prints the block to `std::cout`
  - **No BRep path** → `MeshQuality::emitFidelityReport(refSurfaceForFidelity, out, params)` [line 651] — both passes use `TriBVH` on the tessellation triangles; `usedExactBRep = false`

---

*Author: Claude Sonnet 4.6 — 2026-05-19*
