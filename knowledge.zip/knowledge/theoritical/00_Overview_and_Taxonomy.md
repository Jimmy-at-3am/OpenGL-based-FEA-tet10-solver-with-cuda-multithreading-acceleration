---
title: Overview and Taxonomy of FEA Meshing
type: overview
tags: [moc, taxonomy, decision-tree]
created: 2026-05-16
---

# 00 — Overview and Taxonomy

The "best" mesher is fundamentally a function of (i) the **input geometry class**, (ii) the **target element type**, and (iii) the **PDE residual** that the mesh must support. This note formalises that mapping so the rest of the vault can be navigated by problem characteristics.

---

## 1. Geometry Classes

| Class | Defining property | Typical source | Canonical algorithm family |
|---|---|---|---|
| **Planar / 2-D PSLG** | Polygonal domain in $\mathbb{R}^2$ | DXF, sketcher | Constrained Delaunay + Ruppert/Shewchuk → [[04_Delaunay_CDT_and_TetGen]] |
| **Smooth curved 2-manifold** ($C^k$, $k\ge1$) | Surface $\mathcal{S}\subset\mathbb{R}^3$ with finite reach | Parametric surf., subdivision, smooth STL | Parametrization-based + restricted CVT → [[03_Surface_Meshing_Curved_Manifolds]] |
| **CAD B-rep with sharp features** | Piecewise-smooth with explicit edge/vertex graph | STEP, IGES, Parasolid | Feature-preserving CDT + AFM → [[04_Delaunay_CDT_and_TetGen]], [[05_Frontal_Delaunay_and_Advancing_Front]] |
| **Implicit / level set / CSG** | Defined by $\phi(\mathbf{x})=0$ | SDF, marching cubes input | Isosurface stuffing on BCC → [[06_Octree_BCC_and_Isosurface_Stuffing]] |
| **Dirty / non-manifold STL** | Self-intersections, gaps, flipped normals, T-junctions | Reverse engineering, ill-conditioned exports | Winding-number/envelope methods → [[09_Robust_TetWild_for_Dirty_Geometry]] |
| **Thin shell / boundary-layer dominated** | High curvature × high gradient zones | CFD walls, sheet metal | Anisotropic metric-based → [[08_Anisotropic_Metric_Adaptation]] |
| **Volumetric scalar field** | Image, voxel grid, segmentation | Medical CT, geophysics | Marching cubes + tet-stuffing → [[06_Octree_BCC_and_Isosurface_Stuffing]] |

> [!warning] Geometry classification is the dominant decision
> Choosing an algorithm without first classifying the input geometry is the most common cause of meshing failure in practice. A frontal-Delaunay scheme that excels on a clean B-rep will routinely fail on a corrupted STL where TetWild succeeds in one shot.

---

## 2. Decision Tree (Algorithm Selector)

```text
                            ┌──────────────────────────────────────┐
                            │ Input geometry                       │
                            └──────────────────────────────────────┘
                                          │
                ┌─────────────────────────┴────────────────────────┐
                │                                                  │
        Watertight & manifold?                                Implicit / SDF?
                │                                                  │
       ┌────────┴────────┐                                ┌────────┴────────┐
       │ yes             │ no                             │ yes             │ no
       │                 ▼                                ▼                 │
       │      [[09_Robust_TetWild...]]    [[06_Octree_BCC_and_Isosurface]]   │
       ▼                                                                    ▼
Has sharp features?                                                Voxel / image?
       │                                                                    │
   ┌───┴────┐                                                          ┌────┴────┐
   │ yes    │ no                                                       │ yes     │ no
   ▼        ▼                                                          ▼         ▼
[CDT+AFM]   ▼                                                  [marching        [back to top:
            └── Smooth manifold? ─────────────────┐             cubes +          re-classify]
                                                  │             stuffing]
                                  ┌───────────────┴───────────────┐
                                  │ yes (surface meshing)         │ no (solid)
                                  ▼                               ▼
                  [[03_Surface_Meshing_Curved_Manifolds]]    Anisotropic field needed?
                                                                  │
                                                              ┌───┴────┐
                                                              │ yes    │ no
                                                              ▼        ▼
                                                  [[08_Anisotropic...]]  [[04_Delaunay_CDT_and_TetGen]] or
                                                                         [[05_Frontal_Delaunay_and_Advancing_Front]]
```

A more nuanced selector lives in each algorithm note under the "When to use" heading.

---

## 3. Element Types — A Comparative Cheat-Sheet

| Element                  | DOFs               | Reference shape    | Strain field             | Order of accuracy in $H^1$            | Locking risk                                         | Best meshable by                                  |
| ------------------------ | ------------------ | ------------------ | ------------------------ | ------------------------------------- | ---------------------------------------------------- | ------------------------------------------------- |
| **Tri3**                 | 3 nodes × 2        | $T_{\text{ref}}$   | constant                 | $\mathcal{O}(h)$                      | none (2-D)                                           | Delaunay                                          |
| **Tri6**                 | 6 nodes × 2        | $T_{\text{ref}}$   | linear                   | $\mathcal{O}(h^2)$                    | none                                                 | Delaunay                                          |
| **Quad4 / Quad9**        | 4 / 9 nodes × 2    | $[-1,1]^2$         | bilinear / biquadratic   | $\mathcal{O}(h)$ / $\mathcal{O}(h^2)$ | shear locking (Q4 thin), volumetric (incompressible) | quad-meshing — [[10_Hex_QuadMeshing_FrameFields]] |
| **Tet4**                 | 4 nodes × 3        | $T_{\text{ref}}^3$ | constant                 | $\mathcal{O}(h)$                      | shear, volumetric (Poisson $\nu\to0.5$)              | any tet mesher                                    |
| **Tet10**                | 10 nodes × 3       | $T_{\text{ref}}^3$ | linear                   | $\mathcal{O}(h^2)$                    | mild volumetric only                                 | any tet mesher + mid-node placement               |
| **Hex8 / Hex20**         | 8 / 20 × 3         | $[-1,1]^3$         | trilinear / triquadratic | $\mathcal{O}(h)$ / $\mathcal{O}(h^2)$ | hourglass (H8 under-integrated); incompressible      | hex-meshing — [[10_Hex_QuadMeshing_FrameFields]]  |
| **Wedge6 / Pyr5**        | 6 / 5 × 3          | mixed prism / pyr  | mixed                    | $\mathcal{O}(h)$                      | transitional                                         | extrusion / hex-tet transition                    |
| **Polyhedral (Voronoi)** | $n$ × 3, $n=10$–25 | irregular          | barycentric (Wachspress) | $\mathcal{O}(h)$                      | none — superior incompressible behavior              | [[07_Polyhedral_Mosaic_and_Voronoi]]              |

> [!note] PolyFEA element scope
> The host project ([theory.md](../theory.md)) implements **Tet4** and **Tet10**. The decision rationale: tetrahedral meshes are the only ones reliably automatable for arbitrary B-rep solids; Tet10 lifts Tet4 from $\mathcal{O}(h)$ to $\mathcal{O}(h^2)$ accuracy and largely eliminates the constant-strain shear-locking pathology. The vault still covers hex and polyhedral methods because their algorithmic ideas (frame fields, Voronoi smoothing) feed back into tet-mesh optimisation.

---

## 4. Quality, Accuracy, and Efficiency — the Tri-objective

A practical mesher juggles three competing goals:

1. **Geometric fidelity** — Hausdorff distance to the true surface; resolution of sharp features.
2. **Element quality** — bounded shape measures (see [[02_Mesh_Quality_Metrics]]); condition number of element stiffness.
3. **Computational cost** — wall-clock generation time, memory footprint, and the downstream solver cost $\propto n^{1.5}$ for direct sparse or $\propto n\log n$ per CG iteration.

These goals trade off:

$$
\underbrace{E_{\text{disc}}}_{\text{discretisation error}} = C(\rho, p) \cdot h^{p+1} \cdot \|u\|_{H^{p+1}}
$$

where $\rho$ is a function of the worst element shape measure and $p$ the polynomial order. Making $h\to0$ uniformly is exponentially expensive in 3-D ($n=\mathcal{O}(h^{-3})$); the modern approach is **anisotropic metric-based adaptation** — distributing $h$ so that the per-element error contribution is equidistributed (see [[08_Anisotropic_Metric_Adaptation]]).

The Ciarlet–Babuška lemma bounds the FEM error in terms of the **interpolation error** of the chosen finite-element space; that interpolation error is in turn bounded by

$$
\|u - I_h u\|_{H^1} \le C \cdot \frac{h^p}{\rho^p} \cdot \|u\|_{H^{p+1}},
$$

making the **shape regularity** $\rho$ (essentially the inverse of the aspect-ratio measure in [[02_Mesh_Quality_Metrics]]) a multiplier on the dominant error term. A well-shaped mesh with the same node count can therefore be orders of magnitude more accurate.

---

## 5. State-of-the-Art Landscape (2020–2025 Snapshot)

| Pillar | Pre-2018 standard | Current best practice | Reference |
|---|---|---|---|
| Robust tet meshing of dirty CAD | TetGen + manual repair | **fTetWild** | Hu et al. 2020 — [[09_Robust_TetWild_for_Dirty_Geometry]] |
| Quad/Hex meshing of general 3-D | block decomposition (manual) | **frame-field** + integer-grid maps | Bommes 2013, Solomon 2017, [[10_Hex_QuadMeshing_FrameFields]] |
| CFD volume meshing | tet + prism BL | **Mosaic poly-hex core + poly BL** | ANSYS Fluent 19R1, [[07_Polyhedral_Mosaic_and_Voronoi]] |
| Surface meshing on curved manifolds | UV-param + Delaunay | **Restricted CVT on surface** (no UV cut needed) | Yan & Lévy 2009, 2010, [[03_Surface_Meshing_Curved_Manifolds]] |
| Anisotropic adaptation | gradient-based heuristics | **MMG3D** with log-Euclidean metric averaging | Dapogny 2014, Loseille 2010, [[08_Anisotropic_Metric_Adaptation]] |
| Element shape repair | Laplacian smoothing | **ODT** / L-BFGS CVT | Chen & Holst 2011, Liu 2009, [[12_Mesh_Smoothing_CVT_and_ODT]] |
| Adaptive control | uniform refine | **Goal-oriented DWR** | Becker & Rannacher 2001, [[11_Adaptive_Refinement_hp_and_DWR]] |
| Learned mesh sizing | none | **MeshGraphNets / GNN sizing fields** | Pfaff 2020, Bohn 2024, [[13_ML_and_Neural_Mesh_Generation]] |
| Commercial: ANSYS | TGrid | **Fluent Meshing + Mosaic**, Workbench Mesh adaptive | ANSYS 2024R2 release notes |
| Commercial: COMSOL | "free triangular" | **Physics-controlled meshing** + adaptive | COMSOL 6.3 release |
| Commercial: MATLAB | `delaunayTriangulation` | **`generateMesh` (Hmax/Hgrad/Hedge)**, `adaptmesh` (anisotropic) | R2024b PDE Toolbox |

---

## 6. Cross-References

- For each algorithm's complexity and numerical guarantees see its dedicated note.
- For commercial-tool feature matrices see [[14_Software_Comparison_Matrix]].
- For the underlying maths (CVT energy, metric tensors, Delaunay duality) see [[01_Mathematical_Foundations]].
