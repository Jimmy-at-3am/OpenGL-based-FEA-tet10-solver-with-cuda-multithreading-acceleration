# Session Experience Summary — TODO_01 Debugging Journey

## Date
2026-05-17

---

## 1. The Whole Arc, in One Paragraph

I started by reading the gitignored `knowledge/` vault to understand the project,
read `TODO_01` to learn what was expected, examined whether the originally-written
"PASS" criterion was sound, modified it to be more rigorous, then was asked why
the user's actual runs always printed `FAIL`. I traced the data flow from UI
slider → `FEAParams` → TetGen switches → `tetgenio` → `MeshQuality::computeReport`,
built a standalone C++ probe to isolate the math from the rest of the program,
found three distinct bugs (one math, one wiring, one UI gap), fixed all three,
documented the work, then read `TODO_02` and produced an implementation plan
for it.

---

## 2. Process Flow Walk-Through

### Phase A — Orientation (passive reading)
1. Listed `knowledge/` contents. **Surprise**: it's `.gitignored`, so the
   default `grep_search` / `code_search` tools could not see inside it.
   **Workaround**: switched to raw PowerShell (`Get-ChildItem`, `Get-Content`,
   `Select-String`) to read the markdown files directly.
2. Read `knowledge/02_Mesh_Quality_Metrics.md`, the algorithm map, and the
   full `TODOs/` folder to understand the roadmap (TODO_01 → TODO_20).
3. Read `TODO_01_tetgen_switches_and_console_report.md` carefully — including
   the originally written "Pass criterion".

### Phase B — Validating the Pass Criterion
The original criterion was a single-bullet check ("verdict line printed").
I re-read the spec body and the algorithm map, decided the original criterion
was **too weak**, and rewrote it as a 9-point list covering switch-string
content, generated-tet count, histogram-sum invariant, worst-N row count,
inverted/sliver verdict semantics, and regression-snapshot diffing.

### Phase C — Investigating "Always FAIL"
The user reported that every run of the cube fixture printed `FAIL`.
My diagnostic flow was:

```
Read MeshQuality::computeReport → identify rpt.pass = (inv == 0 && sliv == 0)
  ↓
Read FEAModel::generateVolumetricMesh → confirm TetGen switches well-formed
  ↓
Trace UI slider → FEAParams::tetMinDihedralDeg (= 10.0 default)
  ↓
Hypothesis: either inv or sliv is non-zero unexpectedly
  ↓
Wrote a standalone .cpp probe that:
    - links tetgen.lib
    - calls tetrahedralize on the same fixture STL
    - computes BOTH the project formula AND a signed-volume reference
    - prints raw counts and the worst minSJ / minDihedral values
```

Compiling the probe forced me to bootstrap the MSVC environment by hand:
- `cl` was not on PATH in PowerShell.
- Located VS via `vswhere.exe` under `${env:ProgramFiles(x86)}` (parentheses
  required the `${env:...}` escape form in PowerShell).
- Sourced `vcvars64.bat` via `cmd /c` then exported back.

The probe's first run revealed: **51 621 positively-oriented tets, but the
project formula reported `minSJ = -1.413`**. That impossibility (a valid tet
cannot have negative sJ) pointed to a bug in the corner ordering.

### Phase D — Three Bugs Found
1. **`MeshQuality::scaledJacobianMin` corner 3** had wrong cyclic edge order
   `(p2-p3, p0-p3, p1-p3)` — the triple product's sign was opposite to the
   tet's signed volume, so every valid tet was flagged as inverted at corner 3.
   Fixed by changing to `(p0-p3, p2-p3, p1-p3)`.
2. **`FEAModel::generateCube` never updated `bboxVolume`** — it stayed at the
   class-member default `1000.0f`, so the `MAX VOLUME (%)` slider produced
   `absoluteMaxVol = 1000 * 0.001 = 1.0`, allowing TetGen to emit one giant
   tet covering the whole domain. Fixed by adding
   `bboxVolume = sizeX * sizeY * sizeZ` after surface generation.
3. **Cube-mode UI was missing the meshing controls** — `MESH QUALITY (p)`,
   `MAX VOLUME (%)`, and `GENERATE 3D MESH` only existed inside the
   `MODE_IMPORT` branch of `main.cpp`. Fixed by adding them to `MODE_CUBE`.

### Phase E — Residual Slivers Are Real, Not a Bug
After all fixes, the verdict became `FAIL — 0 inverted, N slivers`.
This is correct behaviour: TetGen's `-q.../min-dihedral` is a target hint,
not a hard guarantee. Residual sliver removal is the explicit job of
`TODO_05` (ODT smoothing), `TODO_06` (stellar topology flips), and
`TODO_08` (combined polish loop).

### Phase F — Documentation & Next Plan
- Wrote `TODO_01_DONE_documentation.md` recording bugs, fixes, lessons.
- Read `TODO_02` spec and wrote `TODO_02_plan.md` with a 9-step
  implementation outline.

---

## 3. Distilled Lessons (the part worth keeping)

### 3.1 About this codebase
1. The `knowledge/` vault is **gitignored**; default search tools cannot see
   into it. Use raw shell file reads.
2. There are **two UI modes** (`MODE_CUBE`, `MODE_IMPORT`) and the same
   meshing controls must exist in both branches; new params must be wired
   into every branch.
3. **`bboxVolume` is a stale class default** unless every geometry-producing
   path explicitly recomputes it. Treat any "absolute-from-percentage"
   conversion as suspect until verified.
4. **`tetgenio::numberofcorners`** carries Tet4/Tet10 distinction in TetGen
   output, but in this project Tet10 is built **after** TetGen via
   `generateMidEdgeNodes()`. Tet10 metrics need their own entry point.
5. There are **multiple quality-analysis paths** in the tree — `MeshQuality`,
   `mesh_diag.cpp` (aspect-ratio-based), and a D4 block inside
   `FEASolver.cpp`. They are not interchangeable.
6. The build uses MSVC + CMake + Ninja via `build.bat`; CLI work needs
   `vcvars64.bat` sourced first.
7. The TetGen switch string is dynamically built from `FEAParams`:
   `pq%g/%ga%gAO%dT%g` — order matters and `/` separates ratio from
   min-dihedral.

### 3.2 About meshing math
1. **Cyclic ordering at every corner of a scaled-Jacobian formula** must be
   derived from, and verified against, the tet's signed volume. A single
   wrong permutation silently flips the sign at one corner.
2. **`acos` always needs `clamp(x, -1, 1)`** before evaluation. Skipping
   it produces NaN for nearly-flat dihedrals.
3. **Denominator guards** (`det < 1e-30`) belong in every shape formula
   that divides by a volume or a Frobenius norm.
4. **TetGen quality switches are hints, not guarantees.** Zero slivers is
   not achievable from TetGen alone in general.
5. **Equiangular skew is normalised to `[0, 1]`**, not degrees. ANSYS-style
   volume formula, not angle-deviation.

### 3.3 About the workflow
1. **Don't trust the original pass criterion blindly** — validate it
   against the algorithm spec first; tighten or relax as needed.
2. **Standalone diagnostic probes** isolate math from program plumbing.
   Compile against the same libraries the project uses, on the same data.
3. **Trace the full data path** when a verdict surprises you:
   UI → params struct → switches → library → metric → verdict bool.
4. **Distinguish "bug" from "expected residual"** — don't bury later-TODO
   work inside the current TODO's pass criterion. The fix and the
   pass criterion must agree on what the current TODO is responsible for.
5. **Write a DONE doc immediately**, while the bug context is fresh.
6. **Plan before coding the next TODO** — produce an explicit step list
   and a risk section before touching new files.

---

## 4. What Would Have Helped Me Earlier

- Knowing the `knowledge/` folder was gitignored before trying `code_search`.
- Knowing `build.bat` already wraps `vcvars64.bat` — I could have used it
  to compile the probe instead of bootstrapping MSVC by hand.
- A single-file map of which TODOs depend on which (the spec has it inside
  each file's `Depends on:` line, but a top-level graph would help).
- A note that cube-mode and import-mode have separate UI branches.

---

*Author: Cascade — 2026-05-17*
