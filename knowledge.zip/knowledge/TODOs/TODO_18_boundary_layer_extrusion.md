# TODO_18 — Boundary layer extrusion (Wedge6 stacks above surface)

## Goal
A `Generate BL` button creates a configurable number of prismatic boundary-layer stacks above the input surface. Renders in contrasting colour. Critical for thin-shell / sheet-metal / through-thickness-gradient structural problems.

## Files added / modified
- **Add** `include/BoundaryLayerExtruder.h`, `src/BoundaryLayerExtruder.cpp`.
- **Modify** `src/FEAModel.cpp` — chain `BoundaryLayerExtruder::extrude` between surface mesh and bulk tet meshing.
- **Modify** `src/SimpleUI.cpp` — `Generate BL` button + BL params panel.
- **Modify** `src/ShaderSources.h` — wedge/pyramid element-type tinting.
- **Modify** `src/main.cpp` — `X` key for clipping plane on cross-section.
- **Add** `assets/test_fixtures/thin_plate.stl` — 10 mm × 100 mm × 100 mm test plate.

## Algorithm summary
From [knowledge/05_Frontal_Delaunay_and_Advancing_Front.md §2](knowledge/05_Frontal_Delaunay_and_Advancing_Front.md) and plan Appendix Phase I:

**Surface normals + smoothing:**
```text
For each surface vertex v (parallel):
    n_v = area-weighted average of incident face normals
Cot-Laplacian smoothing 2-3 sweeps with Taubin lambda-mu (no shrinkage)
Detect re-entrant regions via local concavity:
    mark stack-start cell if angle(n_v, n_neighbour) > blReentrantAngle
```

**Stack generation:**
```text
For layer k = 1..blNumLayers:
    h_k = blFirstLayer * blGrowthRate^(k-1)
    For each surface vertex v_i (parallel):
        if v_i.stackAlive[k-1]:
            propose v_i^(k) = v_i^(k-1) + h_k * n_i
            VALIDITY 1: ray-cast h_k along n_i, reject if intersects existing geometry
                        within blMinClearanceRatio * h_k
            VALIDITY 2: triangle-quality check on the new prism wedge faces
            If pass: commit; else: terminate this stack (stackAlive[k:] = false)
    Smooth normals at layer k (Pointwise T-Rex style): each layer-k node's
    effective normal is blended with its neighbours' normals
```

**Element assembly (uses TODO_17's Wedge6 + Pyramid5):**
```text
For each surface triangle (a, b, c) at layer k:
    Both k and k+1 alive: Wedge6(a^k, b^k, c^k, a^k+1, b^k+1, c^k+1)
    Mixed alive/terminated: Pyramid5 transition element (uses Bedrosian quadrature)
    All terminated: stop — upper surface becomes the "BL cap"
The BL-cap surface is the new boundary front for the existing tet mesher (TetGen/fTetWild) above.
```

## Multithreading
- Per-vertex parallel-for for stack generation; per-face parallel for element instantiation.
- Serial bottleneck: alive-mask propagation between layers (small, linear in surface vertex count).
- Runs inside AsyncTask (TODO_13) — progress bar shows `BL layer 5/10`.

## Numerical care points
- **Collision in concave regions** (care-point #16): without ray-cast clearance, prisms self-intersect at layer ~$\log_r(W/h_1)$. The clearance check terminates early — must be implemented in the first cut.
- **Pyramid5 Bedrosian quadrature** (care-point #13): pyramids appear at stack-termination boundaries; bogus quadrature here corrupts solver convergence near the BL cap.
- **Anisotropic quality**: BL elements have aspect ratio $10^2$–$10^3$. Isotropic Knupp flags them as "bad". Use metric-aware $q_M$ (TODO_16 reused) for BL elements; metric is automatic along the layer normal.

## Screen-visible acceptance check

**Setup** Load `assets/test_fixtures/thin_plate.stl` (10 mm × 100 mm × 100 mm).

**Action** Open params panel, enable `enableBoundaryLayer`; set `blNumLayers=10`, `blFirstLayer=1e-4`. Click `Generate BL` (new button).

**Expected**
- Viewer shows 10 layers of prismatic cells in a contrasting colour (e.g. orange) above each face of the plate.
- Pressing `X` enables a clipping plane; the prism stack becomes clearly visible in cross-section.
- Console:
  ```text
  [BL] surface nodes: 5022   layers planned: 10
  [BL] stack terminations: 0 (re-entrant), 0 (collision)
  [BL] elements: Wedge6:50220   Pyramid5:0   (no transitions needed for flat plate)
  ```
- Quality report PASS (wedges have low Knupp by isotropic measure but $q_M$ near 1).

**Failure modes**
- Prisms invade neighbour faces → no clearance check or `blMinClearanceRatio` too small.
- Many `(collision)` terminations on a flat plate → normal smoothing not run between layers.
- All elements drawn same colour → element-type tinting missing in shader.

**Pass criterion** 10 visible layers above plate AND cross-section view confirms structure AND no inversions.

## Regression sentinel
`regression/bl_thin_plate.txt` — wedge count + termination counts + max-aspect-ratio of BL elements.

## Depends on
TODO_13 (progress UI), TODO_17 (Wedge6 + Pyramid5 elements).

## Estimated effort
4 days.
