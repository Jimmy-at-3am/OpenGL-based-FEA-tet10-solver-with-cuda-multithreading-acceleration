# TODO_02 — Quality Library: Full Metrics Set — Implementation Plan (v2)

## Plan Date
2026-05-17  (v2: refined using lessons from `SESSION_LESSONS_TODO_01.md`)

> **What changed from v1**
> - Added §0 *Pre-flight Checks* (validate criterion, read DONE docs, baseline build).
> - Added §0.3 *Pass-Criterion Tightening Proposal* — v1 inherited the spec's weak presence-only check.
> - Added §2.0 *Standalone Probe Recipe* with canonical regular-tet reference values.
> - Strengthened §2.4 (Tet10 scaled Jacobian) with explicit corner-ordering verification — the direct TODO_01 bug.
> - Added §3.6 *Cross-File Impact Audit* — confirms `mesh_diag.cpp` and `FEASolver.cpp` D4 are independent and must NOT be "fixed" in this TODO.
> - Added §8 *Hard Forbiddens*.
> - Re-ordered §7 *Order of Operations* so baseline build comes first.

---

## 0. Pre-flight Checks  (do these BEFORE editing any source)

### 0.1 Read the spec correctly
The `knowledge/` folder is **gitignored**, so default `grep_search` /
`code_search` cannot see it. Use raw PowerShell:
```powershell
Get-Content .\knowledge\TODOs\TODO_02_quality_library_and_metrics_extension.md
Get-Content .\knowledge\02_Mesh_Quality_Metrics.md   # algorithm reference
Get-Content .\knowledge\TODOs\TODO_01_DONE_documentation.md  # upstream context
```

### 0.2 Confirm baseline builds clean
**Before touching anything**, verify the tree compiles and the existing
TODO_01 report still appears on a default cube run:
```powershell
.\build.bat build
.\build\bin\Release\FEAPreProcessor.exe  # cube mode → Generate 3D Mesh
```
If baseline is broken, fix that first and document; do not pile TODO_02
changes on top of an already-red tree.

### 0.3 Pass-criterion tightening proposal
TODO_02's written criterion is **presence-only**:
> Report contains `equiangular skew` AND a `p05/p50/p95/p99` line for every metric.

This passes even if every printed value is wrong. Applying the lesson from
TODO_01 (where the original single-bullet criterion was too weak), propose
tightening to:

1. Header echoes element type (`Tet4` or `Tet10`).
2. `Knupp shape` histogram bins sum to `N` (numElements).
3. `equiangular skew` histogram bins sum to `N`.
4. Each metric's percentile row obeys `p05 ≤ p50 ≤ p95 ≤ p99`.
5. For a regular reference tet (single element, vertices equidistant):
   `Knupp p50 ≈ 1.00`, `min-dihedral p50 ≈ 70.5°`, `scaled Jacobian p50 ≈ 1.00`,
   `skew p50 ≈ 0.00` — tolerance 1e-6.
6. Tet10 path: when `numberofcorners == 10` or the Tet10 entry point is
   used, `scaled Jacobian` for the regular reference tet is still `≈ 1.00`
   (catches the Hammer-point / shape-gradient bug).
7. Cube fixture: `Worst-N` table still prints `min(N, worstNCount)` rows.
8. Skew values are normalised to `[0, 1]` for every element (failure-mode
   bullet of the TODO).
9. Generated cube report either matches `regression/cube_default.txt` or
   the snapshot is intentionally updated with a note.

Document this tightened criterion in `TODO_02_DONE_documentation.md` at
completion; do not silently override the spec's criterion.

---

## 1. Inventory: What Already Exists vs. What Is Missing

### Already implemented (from TODO_01)
| Symbol | Location |
|--------|----------|
| `knuppShape(p0..p3)` | `src/MeshQuality.cpp` ~line 59 |
| `minDihedralDeg(p0..p3)` | `src/MeshQuality.cpp` ~line 100 |
| `scaledJacobianMin(p0..p3)` (Tet4 corner-based, **post-bugfix**) | `src/MeshQuality.cpp` ~line 155 |
| `KnuppHistogram` struct | `include/MeshQuality.h` ~line 69 |
| `ElemQuality` struct (knupp, dihedralMin, sJac, centroid) | `include/MeshQuality.h` ~line 58 |
| `QualityReport` struct (knupp + min-dihedral + sJac stats, worstN) | `include/MeshQuality.h` ~line 79 |
| `computeReport()` (Tet4 only) | `src/MeshQuality.cpp` ~line 280 |
| `emitReport()` | `src/MeshQuality.cpp` ~line 423 |

### To add (TODO_02)
| New symbol | Purpose |
|-----------|---------|
| `radiusRatio(p0..p3)` | ρ = 3r/R (in-radius / circum-radius) |
| `dihedralRangeDeg(p0..p3) -> (min, max)` | refactor of `minDihedralDeg` |
| `equiangularSkew(p0..p3)` | `S = (V_equi(R) − V_T) / V_equi(R)` |
| `tet10ScaledJacobianMin(p0..p9)` | min over the 4 Hammer points |
| `tet10IsoparametricKnupp(p0..p9)` | Knupp averaged over the 4 Hammer points |
| `SkewHistogram` struct | 4 bins: [0,0.25), [0.25,0.5), [0.5,0.8), [0.8,1] |
| Percentile fields per metric in `QualityReport` | `p05/p50/p95/p99` × 4 metrics |
| Tet4-vs-Tet10 dispatch in `computeReport` | branch on element type |
| Skew + percentile section in `emitReport` | per spec |

---

## 2. Step-by-Step Implementation Plan

### Step 2.0 — Standalone Probe BEFORE library wiring

**Lesson from TODO_01**: a 100-line standalone `.cpp` that links the same
libraries and exercises the math on a canonical input catches algebraic
bugs in minutes — the library wiring takes hours and obscures the symptom.

**Recipe**:
1. Create `tmp/probe_metrics.cpp` (delete after acceptance).
2. Include only `<glm/glm.hpp>` and the new metric headers; no
   `MeshQuality.h`, no `tetgen.h`, no Eigen.
3. Hard-code the canonical regular tetrahedron:
   ```cpp
   const glm::dvec3 R0(0.0,        0.0,             0.0);
   const glm::dvec3 R1(1.0,        0.0,             0.0);
   const glm::dvec3 R2(0.5,        std::sqrt(3.0)/2.0, 0.0);
   const glm::dvec3 R3(0.5,        std::sqrt(3.0)/6.0, std::sqrt(2.0/3.0));
   ```
4. Call each new metric and assert against the reference values in §2.0.1.
5. Compile via `build.bat` style MSVC bootstrap; run; expect all asserts pass.
6. If any assert fires, fix the math BEFORE wiring into `MeshQuality::computeReport`.

#### §2.0.1 Canonical regular-tet reference values (tolerance 1e-6)
| Metric | Value |
|--------|-------|
| `knuppShape` | `1.000000` |
| `minDihedralDeg` | `arccos(1/3) ≈ 70.528779°` |
| `maxDihedralDeg` | `arccos(1/3) ≈ 70.528779°` (regular tet: all dihedrals equal) |
| `scaledJacobianMin` (Tet4) | `1.000000` |
| `radiusRatio` | `1.000000` |
| `equiangularSkew` | `0.000000` |
| `tet10ScaledJacobianMin` (mid-edge nodes at edge midpoints) | `1.000000` |
| `tet10IsoparametricKnupp` (mid-edge nodes at edge midpoints) | `1.000000` |

Any deviation > 1e-6 indicates a bug. The Tet10 row in particular catches
the most common new-bug class: wrong Hammer point coordinates or wrong
shape-gradient signs.

#### §2.0.2 Pathological inputs (also test in probe)
- Inverted tet (swap two vertices): `scaledJacobianMin < 0`, `knuppShape = 0`.
- Sliver (one vertex on the opposite face plane): `minDihedralDeg ≈ 0`,
  `equiangularSkew ≈ 1`.
- Degenerate (all coplanar): all denominators guarded, no NaN, return 0.

### Step 1 — Header Extensions (`include/MeshQuality.h`)

1. **Extend `ElemQuality`** with:
   ```cpp
   double radiusRatio       = 0.0;   // ρ = 3r/R, 0..1 (1 == regular)
   double dihedralMaxDeg    = 0.0;   // largest of the 6 dihedrals, deg
   double equiangularSkew   = 0.0;   // S in [0, 1]
   ```
2. **Add `SkewHistogram`**:
   ```cpp
   struct SkewHistogram {
       std::size_t bin_0_25   = 0;   // [0.00, 0.25)
       std::size_t bin_25_50  = 0;   // [0.25, 0.50)
       std::size_t bin_50_80  = 0;   // [0.50, 0.80)
       std::size_t bin_80_100 = 0;   // [0.80, 1.00]
   };
   ```
3. **Add `MetricPercentiles`**:
   ```cpp
   struct MetricPercentiles { double p05 = 0, p50 = 0, p95 = 0, p99 = 0; };
   ```
4. **Extend `QualityReport`**:
   ```cpp
   SkewHistogram     skewHist;
   MetricPercentiles knuppPct, dihedralMinPct, scaledJacPct, skewPct;
   bool              isTet10 = false;
   ```
5. Document that `scaledJacobian` / `knupp` in `ElemQuality` carry the
   **isoparametric** values when input is Tet10.

### Step 2 — New Free Functions (`src/MeshQuality.cpp`, anonymous namespace)

#### 2.1 `radiusRatio(p0..p3)`
- `r = 3 V / A_total`, `V = (1/6)|det|`, `A_total = Σ face area`.
- `R = (|e_01||e_02||e_12| · |...|) / (24 V)` standard formula.
- Return `3r/R`, clamped `[0, 1]`.
- Guards: `V < 1e-30 → 0`; `A_total < 1e-30 → 0`.

#### 2.2 `dihedralRangeDeg(p0..p3) -> (thetaMin, thetaMax)`
- Refactor existing `minDihedralDeg` into one loop returning both extremes.
- Keep an inline wrapper `minDihedralDeg(...)` for source compatibility.
- Care-point #16: `clamp(cosTh, -1, 1)` before `acos`.

#### 2.3 `equiangularSkew(p0..p3)`
```
R_circum = circumradius
V_equi   = (8 √3 / 27) R_circum^3        // regular tet sharing R
V_T      = |det|/6
S        = (V_equi − V_T) / V_equi       in [0, 1]
```
- Clamp `S` to `[0, 1]` (float noise can push slightly over 1).
- `R_circum < 1e-30 → return 1.0` (fully degenerate).
- **Do NOT** use degrees-based formula `(max(60-θmin, θmax-60))/60`; the
  ANSYS convention for tets is volume-based.

#### 2.4 `tet10ScaledJacobianMin(const std::array<glm::dvec3, 10>& p)` — **HIGH-RISK**

**Lesson from TODO_01**: the Tet4 `scaledJacobianMin` had a wrong cyclic
ordering at corner 3 that flipped the determinant's sign, falsely marking
every valid tet as inverted. The Tet10 version multiplies the surface area
of the same trap by 4 (4 Hammer points) and adds shape-gradient sign
sensitivity.

Mitigation:
- **Hammer points**: copy verbatim from `Tet10Element.cpp` lines 12-19:
  ```cpp
  constexpr double GP_A = 0.5854101966249685;
  constexpr double GP_B = 0.1381966011250105;
  constexpr double gp[4][3] = {
      {GP_A, GP_B, GP_B},
      {GP_B, GP_A, GP_B},
      {GP_B, GP_B, GP_A},
      {GP_B, GP_B, GP_B},
  };
  ```
- **Shape gradients**: 10-node serendipity tet, derived from
  `N_i(ξ,η,ζ)` with corner/edge mapping the same as the solver. Duplicate
  the 30-line `EvalShapeGradients` body locally (do NOT pull
  `Tet10Element.h` — that drags in Eigen and IMaterial).
- **At each Gauss point**:
  ```
  J = [ Σ x_i ∂N_i/∂ξ   Σ x_i ∂N_i/∂η   Σ x_i ∂N_i/∂ζ ]   (3×3)
  detJ = det(J)
  J_scaled = detJ / (||col_0|| · ||col_1|| · ||col_2||)
  ```
- **Verification (mandatory, blocking)**: at the regular reference tet with
  mid-edge nodes at exact edge midpoints, all 4 Gauss points must return
  `J_scaled ≈ 1.0` to within 1e-6. If not, the shape-gradient signs or
  Hammer point coords are wrong — STOP and re-derive before wiring.
- **Inversion test**: at an inverted reference tet (swap p2 and p3), at
  least one Gauss point must return `J_scaled < 0`.

#### 2.5 `tet10IsoparametricKnupp(const std::array<glm::dvec3, 10>& p)`
- Same 4 Hammer points, same `J` as §2.4.
- `q_g = K · 3 · detJ_g^{2/3} / ||J_g||_F^2`, `K = 2^{1/3}`.
- Return **average** over 4 points (per spec "averaged"), clamped `[0, 1]`.
- Care-point #2: `detJ < 1e-30 → 0` for that point.

### Step 3 — Refactor `computeReport()`

1. **Element-type detection**: `const bool isTet10 = (out.numberofcorners == 10);`
   In the current pipeline TetGen is invoked without `-o2`, so this is
   always `false` here. The Tet10 path is reached via the new entry point
   in Step 5, not by `tetgenio` inspection.
2. **Per-element loop** extends to populate:
   `knuppArr, dihedralMinArr, dihedralMaxArr, sJacArr, radiusRatioArr, skewArr`
   plus thread-local `KnuppHistogram` AND `SkewHistogram` bins.
3. **Bin merge**: extend serial merge to also reduce `skewHist`.
4. **Percentile helper**:
   ```cpp
   MetricPercentiles percentiles(std::vector<double> v) {
       auto pick = [&](double pct) {
           if (v.empty()) return 0.0;
           const std::size_t k = std::min<std::size_t>(
               v.size() - 1,
               static_cast<std::size_t>(std::floor(pct * (v.size() - 1) + 0.5)));
           std::nth_element(v.begin(), v.begin() + k, v.end());
           return v[k];
       };
       return { pick(0.05), pick(0.50), pick(0.95), pick(0.99) };
   }
   ```
   4 metrics × 4 percentiles = 16 `nth_element` passes, O(N) total.
5. **Edge case**: `nTets < 100` → `p99` collapses to `max`; document inline.

### Step 4 — Update `emitReport()`

Insert between `scaled Jacobian` summary and `Worst-N`:
```text
  equiangular skew: [0.00, 0.25): A   [0.25, 0.50): B   [0.50, 0.80): C   [0.80, 1.00]: D
  percentiles
    Knupp           p05=0.32 p50=0.78 p95=0.94 p99=0.97
    min dihedral    p05=24.1 p50=58.4 p95=68.9 p99=70.5
    scaled Jacobian p05=0.42 p50=0.91 p95=0.99 p99=1.00
    skew            p05=0.03 p50=0.13 p95=0.41 p99=0.62
```

Header gains element-type tag:
```text
[Mesh] Quality Report (Tet4, radius-edge ratio bound: 1.20, min-dihedral: 10.0 deg)
```

### Step 5 — Tet10 Entry Point  (deferred-acceptance)

**Lesson**: "make the smallest possible edit that satisfies the pass
criterion." TODO_02's criterion targets Tet4 only (the cube path goes
through TetGen). Tet10 metrics are forward-looking for TODO_05/08.

**Action**: ship the API but do NOT gate TODO_02 acceptance on Tet10:
```cpp
QualityReport computeReportTet10(
    const std::vector<glm::vec3>& positions,
    const std::vector<unsigned>&  tet10Connectivity,  // 10 * nElems
    const FEAParams&              p);

void emitReportTet10(
    const std::vector<glm::vec3>& positions,
    const std::vector<unsigned>&  tet10Connectivity,
    const FEAParams&              p,
    std::ostream&                 os = std::cout);
```
Both factor through a private templated `computeReportImpl<Extractor>` so
the Tet4 / Tet10 paths share parallel loop, percentile pipeline, emission.
Verify with the probe (§2.0) on the regular Tet10 reference; no
production call site yet.

### Step 6 — Wire `FEAModel.cpp`
- `generateVolumetricMesh()` keeps its existing `MeshQuality::emitReport(out, params)` call (now richer output, no code change here).
- **Do not** add a Tet10 emission call yet; `generateMidEdgeNodes()` is
  triggered by the solver path, not the meshing button. Adding it now
  would produce a confusing duplicate report on the same Tet4 mesh.

### Step 7 — Multithreading
Mirror TODO_01 pattern (already validated):
- `#pragma omp parallel for schedule(static)` over elements when
  `p.useMultithreading == true`.
- Thread-local `KnuppHistogram` / `SkewHistogram` accumulators.
- Serial reduction after the parallel region.
- Percentile computation serial; document.

### Step 8 — Numerical Care Points

| # | Care point | Where |
|---|-----------|-------|
| 2 | Knupp denominator guard `det < 1e-30` → 0 | `knuppShape`, `tet10IsoparametricKnupp` |
| 16 | `acos` clamp `[-1, 1]` | `dihedralRangeDeg` |
| — | Skew normalised to `[0, 1]`, **not** in degrees | `equiangularSkew` |
| — | Tet10 sJ uses **exactly** the 4 Hammer points | `tet10ScaledJacobianMin` |
| — | Skew formula uses circumradius-based `V_equi` | `equiangularSkew` |
| — | Corner/Hammer-point orderings derived from signed volume; verified on regular tet | §2.0 probe |

### Step 9 — Regression Sentinel
Append to `regression/cube_default.txt`:
```
knupp_p05         = ...
knupp_p50         = ...
dihedralMin_p05   = ...
dihedralMin_p50   = ...
scaledJac_p05     = ...
scaledJac_p50     = ...
skew_p05          = ...
skew_p50          = ...
skewHist_0_25     = ...
skewHist_25_50    = ...
skewHist_50_80    = ...
skewHist_80_100   = ...
```
Future runs diff against this file.

---

## 3. Cross-File Impact Audit  (NEW — apply "multiple parallel paths" lesson)

Files that **DO** consume `MeshQuality::QualityReport` or `emitReport`:
| File | Usage |
|------|-------|
| `src/MeshQuality.cpp` | `emitReport` → `computeReport` |
| `src/FEAModel.cpp` | calls `MeshQuality::emitReport(out, params)` after `tetrahedralize` |
| `include/MeshQuality.h` | API definition |

Files that **DO NOT** use `MeshQuality` and **must NOT be touched** under
this TODO:
| File | Why hands-off |
|------|---------------|
| `src/mesh_diag.cpp` | Independent standalone tool with its own `analyzeTetQuality` (aspect-ratio based); unrelated diagnostic surface. |
| `src/FEASolver.cpp` D4 block | Solver-internal sliver counter; runs against the assembled mesh, not the TetGen output. |
| `src/Tet10Element.cpp` | Solver element class; we COPY constants from it but do NOT modify it. |

If your edit changes one of those "DO NOT" files, you have probably
introduced unrelated work. Stop and reconsider.

---

## 4. Verification & Acceptance Plan

### Build
```powershell
.\build.bat build
```
Must compile clean.

### Probe-level checks (do FIRST, before §4 manual smoke)
- All 8 regular-tet asserts in §2.0.1 pass.
- All 3 pathological-input asserts in §2.0.2 pass.

### Manual smoke test
1. Launch `FEAPreProcessor.exe`.
2. Cube mode (default geometry).
3. Click `GENERATE 3D MESH`.
4. Confirm console output contains:
   - Element-type label in header (`Tet4`).
   - `Knupp shape` histogram (existing, unchanged format).
   - `equiangular skew` histogram (new, 4 bins).
   - `percentiles` block with all four metric rows.
5. Visually confirm percentile values obey `p05 ≤ p50 ≤ p95 ≤ p99`.
6. Visually confirm skew values are all in `[0, 1]`.
7. Visually confirm Knupp histogram bins sum to printed `N`.

### Failure-mode triage
| Symptom | Likely cause |
|---------|--------------|
| Skew values > 1 | formula used degrees or missing normalisation |
| `p99 == max` exactly | mesh has < 100 elements (acceptable, document) |
| Tet10 sJ < 0 on regular reference | wrong Hammer point coords or shape gradients |
| `p05 > p50` | percentile picker bug (sort direction or index calc) |
| Knupp histogram bins do NOT sum to N | parallel bin reduction missed a thread |
| All skew = 0 | early-return / uninitialised array |
| Header still says nothing about element type | `isTet10` not threaded through `emitReport` |

### Pass criterion (tightened per §0.3)
The 9-point criterion in §0.3.

---

## 5. Risk & Open Questions

1. **Tet10 entry point not exercised by acceptance check** (intentional —
   §5 above).
2. **Skew bin boundary disambiguation** — spec example shows `[0.25, 0.50)`
   then `[0.50, 0.80)`; we honour the latter. Confirm `0.50` ≠ `0.5` is
   purely stylistic.
3. **`Tet10Element::EvalShapeGradients` reuse vs. duplication** — decision:
   **duplicate** locally. Keeps `mesh_diag.exe` link clean (no Eigen).
4. **Worst-N sort key** — keep ascending Knupp (TODO_01 compatibility).
   Composite ranking is a future knob, not this TODO.

---

## 6. Effort Breakdown
| Task | Time |
|------|-----|
| §0 pre-flight + criterion validation | 0.25 h |
| §2.0 probe (write + verify regular tet) | 1.0 h |
| Step 1 header extensions | 0.5 h |
| Step 2.1–2.3 (Tet4 metrics) | 1.5 h |
| Step 2.4–2.5 (Tet10 metrics) | 2.0 h |
| Step 3 refactor `computeReport` + percentile helper | 2.0 h |
| Step 4 extend `emitReport` | 1.0 h |
| Step 5 Tet10 entry point + shared impl factor | 1.0 h |
| Step 6 `FEAModel.cpp` wiring | 0.25 h |
| Step 7–8 mt + numerical guards | 0.5 h |
| Step 9 regression sentinel | 0.25 h |
| Manual verification + cube smoke test | 0.5 h |
| `TODO_02_DONE_documentation.md` | 0.5 h |
| **Total** | **≈ 11 h (≈ 1 working day)** |

---

## 7. Order of Operations (Recommended)

0. **Baseline build is green** (§0.2). If not, STOP.
1. Spec read + criterion validation written down (§0.1, §0.3).
2. Standalone probe (§2.0) — get reference values matching before touching
   the library.
3. Header extensions (Step 1) — compiles with stub init values.
4. `radiusRatio` + `equiangularSkew` + `dihedralRangeDeg` (Step 2.1–2.3).
5. Wire into `computeReport` + `emitReport` (Step 3 + 4) — Tet4 path now
   meets TODO_02's acceptance criterion.
6. Percentile helper unit-tested (Step 3.4–3.5).
7. Build + manual cube smoke test → confirm acceptance.
8. Tet10 paths (Step 2.4–2.5 + Step 5) — landed and probe-verified, NOT
   gating TODO_02 PASS.
9. Regression sentinel update (Step 9).
10. `TODO_02_DONE_documentation.md` (mirror `TODO_01_DONE` format).

---

## 8. Hard Forbiddens

- **Do not** weaken the pass criterion to make a failing build pass.
  Tighten / relax with explicit written justification BEFORE shipping.
- **Do not** modify `mesh_diag.cpp` or `FEASolver.cpp` D4 — they are
  independent diagnostic paths (see §3 audit).
- **Do not** pull `Tet10Element.h` into `MeshQuality.cpp` — duplicate the
  ~30 lines of shape-gradient code; preserves `mesh_diag` light deps.
- **Do not** silently change the Tet4 `scaledJacobianMin` corner orderings.
  Those were fixed in TODO_01; the orderings now match signed-volume sign.
  Any change must be justified by a §2.0 probe assert failure.
- **Do not** ship the Tet10 entry point without the §2.0 regular-tet
  probe asserting `sJ ≈ 1.0`. A wrong Hammer point or shape-gradient sign
  reproduces the TODO_01 false-inverted bug at 4× scale.
- **Do not** add a Tet10 emission call inside `FEAModel::generateVolumetricMesh`
  — `tetrahedraQuadratic` is empty at that point; the call would
  silently produce an empty report.
- **Do not** create new top-level UI controls in `main.cpp` for this TODO
  — TODO_02 is library-only. If you find yourself editing `main.cpp`,
  re-read the spec.

---

*Plan author: Cascade — 2026-05-17 (v2)*

### Post-implementation verdict policy

Manual variable sweeps showed that practical fine meshes may contain a tiny residual sliver tail even when the metrics, histograms, percentiles, and inversion checks are correct. This is consistent with TetGen: `pq<radius>/<min-dihedral>` is a target, not a guarantee.

Final MeshQuality verdict semantics for TODO_02:

- `FAIL`: any inverted element (`scaledJacobian <= 0`).
- `WARN`: no inverted elements, but severe-sliver (`< 5 deg`) or below-target (`< tetMinDihedralDeg`, default `10 deg`) tail exceeds `1.0%` of elements.
- `PASS`: no inverted elements and both sliver tails are `<= 1.0%`.

Example accepted fine mesh: `p=1.231`, `maxVolPercent=6.3e-3`, `30445` tets, `8` severe slivers (`0.026%`) and `57` below target (`0.187%`) => `PASS`.
