---
title: Mesh Quality Metrics
type: foundation
tags: [quality, shape-measure, condition-number, sliver, jacobian]
created: 2026-05-16
---

# 02 — Mesh Quality Metrics

Quality metrics are the **objective functions** of every mesh generator and smoother. They quantify how close an element is to its ideal (equilateral) shape, and — more importantly for FEA — bound the constants in the discretisation-error estimate

$$
\|u-u_h\|_{H^1} \le C(\rho)\, h^p\, |u|_{H^{p+1}}, \qquad C(\rho) = \mathcal{O}(\rho^{-p}),
$$

where $\rho$ is a chosen *shape regularity* measure (Ciarlet 1978). A few badly-shaped elements can dominate $C(\rho)$ and destroy convergence even when the *average* mesh is excellent — quality must be controlled in the **worst case**, not the mean.

Cross-refs: smoother targets in [[12_Mesh_Smoothing_CVT_and_ODT]]; the "sliver" pathology specific to 3-D Delaunay is treated in [[04_Delaunay_CDT_and_TetGen]] §6.

---

## 1. Geometric Shape Measures

### 1.1 Aspect ratio (triangle / tet)

For a triangle with sides $a,b,c$ and area $A$:

$$
\mathrm{AR}_{\triangle} = \frac{a\,b\,c}{8(s-a)(s-b)(s-c)} = \frac{R}{2r},
\qquad s=(a+b+c)/2,
$$

with $R,r$ the circum- and in-radii. The equilateral triangle has $\mathrm{AR}=1$.

For a tetrahedron the analogous (and recommended) measure is the **radius ratio**:

$$
\rho_T = 3 \cdot \frac{r}{R}, \qquad \rho_T \in (0,1], \quad \rho_T=1 \text{ iff equilateral.}
$$

### 1.2 Skewness (commercial convention)

ANSYS / Fluent uses the **equilateral-volume skewness** $S\in[0,1]$:

$$
S_T = \frac{V_{\text{equi}}(R_T) - V_T}{V_{\text{equi}}(R_T)},
$$

where $V_{\text{equi}}(R_T)$ is the volume of the equilateral simplex with the same circumradius. $S=0$ is perfect; ANSYS recommends $S<0.94$ for Tet4 and $S<0.97$ for Tet10.

| $S$ range | Verdict (ANSYS Fluent UG) |
|---|---|
| $0\le S<0.25$ | Excellent |
| $0.25\le S<0.5$ | Good |
| $0.5\le S<0.8$ | Acceptable |
| $0.8\le S<0.95$ | Poor |
| $S\ge 0.95$ | Sliver — reject |

COMSOL exposes the same quantity as `qualskewness` in the *Mesh > Statistics* panel. MATLAB PDE Toolbox uses `meshQuality(mesh, "aspect-ratio")` returning $\rho_T$.

### 1.3 Scaled Jacobian (curved & higher-order elements)

For an isoparametric element, the Jacobian $J(\xi)$ varies inside the element. The **scaled Jacobian** is

$$
J^* = \min_{\xi\in T_{\text{ref}}} \frac{\det J(\xi)}{\prod_{i=1}^{d} \|J_i(\xi)\|_2},
$$

with $J_i$ the $i$-th column of $J$. $J^*=1$ is perfect, $J^*\le 0$ indicates an inverted element. For Tet10, $J^*$ also detects **bad mid-side node placement** (a node off the straight edge by more than 25 % typically drops $J^*$ below 0).

> [!warning] Negative Jacobian
> A negative Jacobian anywhere inside the element makes the local stiffness $K_e$ indefinite. The global $K$ is no longer SPD, conjugate-gradient (CG) silently diverges, and direct solvers may produce nonsense. **Always reject the mesh** if $\min_T J^*_T \le 0$. PolyFEA's `mesh_diag` reports this — see [src/mesh_diag.cpp](../src/mesh_diag.cpp).

### 1.4 Dihedral angle bounds (3-D)

The dihedral angle along edge $e$ of a tet is the angle between the two faces sharing $e$. For an equilateral tet all six dihedrals equal $\arccos(1/3)\approx70.53°$. A useful pair of bounds:

$$
\theta_{\min}(T) > 0 \quad \text{(non-degenerate)}, \qquad \theta_{\max}(T) < \pi \quad \text{(non-flat)}.
$$

Numerical evidence (Shewchuk 2002) shows the **condition number** of the elementary stiffness scales as

$$
\kappa(K_e) = \mathcal{O}\!\left(\frac{1}{\sin^2\theta_{\min}}\right),
$$

so a single sliver with $\theta_{\min}=0.1°$ inflates $\kappa(K)$ by $\sim10^7$, crippling iterative solvers.

### 1.5 Knupp's algebraic shape measures (2003)

Knupp recasts shape measures as norms on the Jacobian, giving a unified framework that extends to all element types:

$$
q_{\text{shape}} = \frac{d \cdot \det(J)^{2/d}}{\mathrm{trace}(J^T J)} \in (0,1].
$$

For Tet4 in $d=3$, this evaluates to $3\sqrt[3]{\det(J)^2} / \|J\|_F^2$. The expression is differentiable in nodal positions $x_i$ and so directly usable as the objective in **Knupp's optimisation-based smoother** ([[12_Mesh_Smoothing_CVT_and_ODT]] §2.2).

### 1.6 Per-element classification thresholds

Practical defaults for engineering FEA (drawing from COMSOL/ANSYS UG, NAFEMS guidelines):

| Metric | Reject | Warn | Accept |
|---|---|---|---|
| Aspect ratio $\rho_T$ | $<0.05$ | $<0.2$ | $\ge0.2$ |
| Equiangular skew | $>0.95$ | $>0.85$ | $\le0.85$ |
| Min dihedral | $<5°$ | $<15°$ | $\ge15°$ |
| Max dihedral | $>175°$ | $>165°$ | $\le165°$ |
| Scaled Jacobian $J^*$ | $\le0$ | $<0.2$ | $\ge0.2$ |

---

## 2. Conditioning Measures

### 2.1 Element stiffness condition number

For an isotropic linear-elastic Tet4 with the $D$-matrix in [theory.md §1.2](../theory.md):

$$
\kappa(K_e) = \frac{\lambda_{\max}(K_e)}{\lambda_{\min,\ne 0}(K_e)}.
$$

Six rigid-body modes give six zero eigenvalues — exclude them. Shewchuk (2002) shows:

$$
\kappa(K_e) \le \frac{C_1\,\|J^T J\|}{\det(J)^{2/d}} = C_2 \cdot \frac{1}{q_{\text{shape}}^d}.
$$

This is the strongest known link between geometric shape and numerical conditioning: **maximising Knupp's $q_{\text{shape}}$ minimises an upper bound on $\kappa(K_e)$.**

### 2.2 Global condition number

$\kappa(K) = \lambda_{\max}/\lambda_{\min}$ on the constrained system. For a regular tet mesh of an elastic body of size $L$ with smallest element $h$:

$$
\kappa(K) \sim \frac{L^2}{h^2 \cdot \min_T q_{\text{shape},T}^d}.
$$

CG iterations to reach tolerance $\varepsilon$ scale as $\mathcal{O}(\sqrt{\kappa}\,\log(1/\varepsilon))$. Halving the worst element shape measure typically *doubles* the iteration count — a strong economic argument for sliver removal.

---

## 3. Interpolation-Error Constants

Babuška & Aziz (1976) prove the famous **maximum angle condition**: for a 2-D triangular mesh,

$$
\|u-I_h u\|_{H^1} \le C\,h\,|u|_{H^2}, \qquad C = C(\theta_{\max}),
$$

and $C\to\infty$ only as $\theta_{\max}\to\pi$. The minimum-angle bound (Zlámal 1968) is **sufficient but not necessary**. In 3-D the picture is more delicate: anisotropic elements with bounded *maximum* angle but unbounded aspect ratio can still give optimal-order interpolation if aligned with the solution anisotropy — this is the foundation of metric-based adaptation ([[08_Anisotropic_Metric_Adaptation]]).

---

## 4. Anisotropic Quality

Under a Riemannian metric $M$, an edge has length $\ell_M$ (cf. [[01_Mathematical_Foundations]] §4). A simplex is **unit** in $M$ iff all its edges have $\ell_M=1$. Define the metric-aware quality

$$
q_M(T) = \alpha_d \cdot \frac{|T|_M}{\bigl(\sum_{e\in T} \ell_M(e)^2 / |E_T|\bigr)^{d/2}},
$$

where $|T|_M = \int_T \sqrt{\det M}\,dx$ and $\alpha_d$ normalises so the unit equilateral $M$-simplex scores 1. MMG3D and feflo.a both refine until $q_M\ge0.8$ on $\ge99$ % of elements — see [[08_Anisotropic_Metric_Adaptation]] §4.

---

## 5. Slivers: the 3-D Pathology

A **sliver** is a tetrahedron whose four vertices lie close to a great circle of its (potentially large) circumscribed sphere. Equivalently: $\rho_T \ll 1$ while $h_T$ is moderate. Slivers are invisible to the **radius-edge ratio**

$$
\beta_T = \frac{R_T}{\ell_{\min,T}},
$$

which is bounded by every Delaunay-refinement algorithm but does **not** bound $\rho_T$. This is why Ruppert refinement in 2-D guarantees quality but in 3-D requires an additional **sliver-exudation** step (Edelsbrunner–Guoy 2002, Cheng et al. 2000). See [[04_Delaunay_CDT_and_TetGen]] §6.

Modern remedies:

| Method | Mechanism | Citation |
|---|---|---|
| **Weight pumping (sliver exudation)** | weighted Delaunay, perturb $w_i$ to kill slivers | Cheng–Dey 2000 |
| **CVT/ODT smoothing** | continuous gradient flow on quality energy | Du 1999, Chen 2011 |
| **Vertex perturbation (`mesh improvement` in TetGen)** | random restart + edge flips | Si 2015 |
| **Topology operators** | 2-3, 3-2, 4-4 flips, edge splits, vertex insertion | Klingner–Shewchuk 2007 |

The state-of-the-art **Stellar** improver (Klingner & Shewchuk 2007) routinely raises the minimum dihedral of TetGen output from $<5°$ to $\ge30°$ on the Thingi10K corpus — discussed in [[12_Mesh_Smoothing_CVT_and_ODT]] §5.

---

## 6. Geometric Fidelity Metrics

Quality alone says nothing about how well the mesh approximates the input geometry. Two complementary measures:

### 6.1 (Symmetric) Hausdorff distance

$$
d_H(|\mathcal{T}_h|, \Omega) = \max\!\left\{\sup_{x\in|\mathcal{T}_h|}\inf_{y\in\Omega}\|x-y\|,\;\sup_{y\in\Omega}\inf_{x\in|\mathcal{T}_h|}\|x-y\|\right\}.
$$

Most surface meshers (MMG, Gmsh) take a user parameter `hausd` and refine until $d_H<$ hausd everywhere — typically $10^{-3}\cdot L_{\text{diag}}$.

### 6.2 Normal deviation

For a triangle $f\subset|\mathcal{T}_h|$ centred at $x_f$ with normal $n_f$ and footpoint $y_f\in\mathcal{S}$ with normal $n_{\mathcal{S}}(y_f)$:

$$
\delta_n(f) = \arccos\bigl(\langle n_f, n_{\mathcal{S}}(y_f)\rangle\bigr).
$$

Used by ANSYS Fluent's *curvature size function* and COMSOL's *resolution of curvature* (default $0.3$ rad $\approx17°$).

---

## 7. Diagnostic Pipeline (Recommended)

For every generated mesh, compute and report:

1. **Validity**: $\det J > 0$ on all integration points; no duplicate / degenerate / inverted elements.
2. **Shape histograms**: $\rho_T$, dihedrals, scaled Jacobian, Knupp $q_{\text{shape}}$.
3. **Worst-case offenders**: ranked list of $N=20$ worst elements with coordinates — feeds back into smoothing.
4. **Connectivity**: Euler characteristic match, manifoldness, boundary closure (every face is on $\ge1$ tet, every edge on $\ge2$ faces).
5. **Geometric fidelity**: $d_H$ to the original B-rep; normal deviation histogram on the boundary.
6. **Metric conformance** (if $M$ is given): $\ell_M$ histogram, $q_M$ histogram.

This pipeline is largely implemented in [src/mesh_diag.cpp](../src/mesh_diag.cpp).

---

## 8. References (curated; full list in [[15_References_Bibliography]])

- P. M. Knupp, "Algebraic mesh quality metrics," *SIAM J. Sci. Comput.* 23, 2001.
- J. R. Shewchuk, "What is a Good Linear Finite Element? …," manuscript, 2002.
- I. Babuška & A. K. Aziz, "On the angle condition in the finite element method," *SIAM J. Numer. Anal.* 13, 1976.
- M. Zlámal, "On the finite element method," *Numer. Math.* 12, 1968.
- D. Field, "Qualitative measures for initial meshes," *IJNME* 47, 2000.
- B. M. Klingner & J. R. Shewchuk, "Aggressive Tetrahedral Mesh Improvement," *IMR* 2007 (the Stellar paper).
- ANSYS Fluent 2024 R2 *Meshing User's Guide* §10 (Quality Metrics).
- COMSOL 6.3 *Reference Manual* §"Mesh Quality".
