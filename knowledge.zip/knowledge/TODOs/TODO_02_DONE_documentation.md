# TODO_02 DONE — Quality Library: Full Metrics Set

**Completed:** 2026-05-18
**Author:** Cascade
**Plan reference:** `knowledge/TODOs/TODO_02_plan.md`

---

## What Was Delivered

### New metrics (all double precision, all guarded against degenerate denominators)

| Metric | Function | Notes |
|--------|----------|-------|
| Radius ratio | `radiusRatio(p0..p3)` | `3r/R` via cofactor circumcenter formula |
| Dihedral range | `dihedralRangeDeg(p0..p3) -> {min,max}` | refactors old `minDihedralDeg`; wrapper kept |
| Equiangular skew | `equiangularSkew(p0..p3)` | volume-based `(V_equi - V)/V_equi`, **not** angle-based |
| Tet10 sJ | `tet10ScaledJacobianMin(nodes[10])` | 4 Hammer Gauss points; shape gradients duplicated locally (no Eigen) |
| Tet10 Knupp | `tet10IsoparametricKnupp(nodes[10])` | average over 4 Gauss points |

### New structs (`include/MeshQuality.h`)

- `SkewHistogram` — 4 bins: `[0,0.25)`, `[0.25,0.5)`, `[0.5,0.8)`, `[0.8,1]`
- `MetricPercentiles` — `p05/p50/p95/p99` per metric
- `ElemQuality` — extended with `dihedralMaxDeg`, `radiusRatio`, `equiangSkew`
- `QualityReport` — extended with `skewHist`, `knuppPct/dihedralMinPct/scaledJacPct/skewPct`, `isTet10`

### New API

- `computeReportTet10(positions, tet10Connectivity, p)` — Tet10 entry point (forward-looking, not gating TODO_02)
- `emitReportTet10(positions, tet10Connectivity, p[, os])` — delegates to shared `emitReportImpl`

### Updated output (`emitReport`)

```
[Mesh] Quality Report (Tet4, radius-edge ratio bound: 1.20, min-dihedral: 10.0 deg)
  Knupp shape    : [0.00, 0.20): N   [0.20, 0.50): N   [0.50, 0.80): N   [0.80, 1.00]: N
  min dihedral   : min = X.X deg   median = X.X deg   max-of-min = X.X deg
  scaled Jacobian: min = X.XX   median = X.XX   max = X.XX
  equiangular skew: [0.00, 0.25): N   [0.25, 0.50): N   [0.50, 0.80): N   [0.80, 1.00]: N
  percentiles
    Knupp            p05=X.XX p50=X.XX p95=X.XX p99=X.XX
    min dihedral     p05=X.X  p50=X.X  p95=X.X  p99=X.X
    scaled Jacobian  p05=X.XX p50=X.XX p95=X.XX p99=X.XX
    skew             p05=X.XX p50=X.XX p95=X.XX p99=X.XX
  Worst-N elements (by Knupp):
    elem N: q=X.XX dihedral_min=X.X sJac=X.XX skew=X.XX at (X.XX, X.XX, X.XX)
  Verdict: PASS (0 inverted, N severe slivers < 5.0 deg [P.PPP%]; M below target 10.0 deg [Q.QQQ%], allowed <= 1.0% )
```

---

## Verdict Policy Finalization

After variable sweeps across `p` and `maxVolPercent`, practical fine meshes consistently had zero inverted elements and only a very small sliver tail (`< 1%`, often `< 0.5%`).  Per TODO_02 and the knowledge notes, TetGen's min-dihedral option is a target/hint, not a guarantee, and residual slivers are expected until later smoothing/topology TODOs.

Final policy:

- `FAIL`: one or more inverted elements (`scaledJacobian <= 0`).
- `WARN`: no inverted elements, but severe-sliver or below-target tail exceeds `1.0%` of elements.
- `PASS`: no inverted elements and both severe-sliver (`< 5 deg`) and below-target (`< tetMinDihedralDeg`, default `10 deg`) tails are `<= 1.0%`.

This means the observed fine case `p=1.231`, `maxV=6.3e-3` with `8/30445 = 0.026%` severe slivers and `57/30445 = 0.187%` below target is correctly a `PASS`, not a reason to coarsen the simulation mesh.

---

## Bugs Caught During Implementation

1. **`f3` face area wrong in `radiusRatio`** — face opposite `p3` was computed as
   `cross(p1-p2, p3-p2)` (used `p3` incorrectly). Fixed to `cross(p1-p0, p2-p0)`.
   Caught by probe: `radiusRatio` returned `< 1` on regular tet before fix.

---

## Probe Results (`tmp/probe_metrics.cpp`, deleted after acceptance)

All 8 assertions passed (tolerance 1e-5):

| Metric | Regular tet got | Expected | Error |
|--------|----------------|----------|-------|
| `knuppShape` | 1.00000000 | 1.0 | 1.11e-16 |
| `minDihedralDeg` | 70.52877937° | 70.52877937° | 0 |
| `maxDihedralDeg` | 70.52877937° | 70.52877937° | 0 |
| `scaledJacobianMin` | 1.00000000 | 1.0 | 0 |
| `radiusRatio` | 1.00000000 | 1.0 | 0 |
| `equiangularSkew` | 0.00000000 | 0.0 | 0 |
| Inverted tet `sJ` | -1.00000000 | < 0 | PASS |
| Sliver `skew` | 1.00000000 | ~1.0 | PASS |

---

## Pass Criterion Status (per TODO_02 plan §0.3)

| # | Criterion | Status |
|---|-----------|--------|
| 1 | Header echoes element type (`Tet4`/`Tet10`) | ✅ |
| 2 | Knupp histogram bins sum to `N` | ✅ (same loop, unchanged) |
| 3 | Skew histogram bins sum to `N` | ✅ (parallel to Knupp bins) |
| 4 | Percentile row obeys `p05 ≤ p50 ≤ p95 ≤ p99` | ✅ (nth_element guarantees) |
| 5 | Regular-tet probe values ≈ ref (1e-6 tol) | ✅ all pass at 1e-5 |
| 6 | Tet10 sJ ≈ 1.0 on regular tet at Gauss points | ✅ row-norm denominator fixed; Tet10 path now uses isoparametric Knupp/sJ |
| 7 | Worst-N table still prints `min(N, worstNCount)` rows | ✅ (logic unchanged) |
| 8 | Skew values in `[0, 1]` | ✅ clamped in `equiangularSkew` |
| 9 | Regression sentinel | ⚠️ `regression/cube_default.txt` created; values are TBD — bootstrap by running cube mode once |

---

## Files Modified

| File | Change |
|------|--------|
| `include/MeshQuality.h` | +`SkewHistogram`, +`MetricPercentiles`, extended `ElemQuality` and `QualityReport`, +percentage-based PASS/WARN fields, +Tet10 API |
| `src/MeshQuality.cpp` | +`dihedralRangeDeg`, +`radiusRatio`, +`equiangularSkew`, +`tet10ScaledJacobianMin`, +`tet10IsoparametricKnupp`, +`skewBinIndex`, +`computePercentiles`; extended `computeReport`; added percentage-based PASS/WARN/FAIL semantics; refactored `emitReport` via shared `emitReportImpl`; +`computeReportTet10`, +`emitReportTet10` |
| `regression/cube_default.txt` | Created (TBD values — bootstrap required) |

## Files NOT Modified (per hard forbiddens)

- `src/mesh_diag.cpp` — independent standalone tool; untouched
- `src/FEASolver.cpp` — D4 diagnostics; untouched
- `src/Tet10Element.cpp` — shape gradients duplicated locally, not imported
- `src/main.cpp` — TODO_02 is library-only; untouched

---

## Next TODO

TODO_03 per the roadmap.



