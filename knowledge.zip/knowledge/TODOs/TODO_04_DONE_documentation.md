# TODO_04 DONE — STEP Loader as Primary Input + Analytic B-rep Retention

**Completed:** 2026-05-19
**Author:** Cascade
**Plan reference:** `knowledge/TODOs/TODO_04_step_loader_primary_and_brep_retention.md`

---

## What Was Delivered

### New files (created)

| File | Purpose |
|------|---------|
| `include/BRepHandle.h` | OCC-free pImpl class; the only B-rep type visible to most TUs |
| `src/BRepHandle_impl.h` | Internal OCC-aware `BRepHandle::Impl` with `TopoDS_Shape`; included ONLY from `BRepHandle.cpp` and `StepLoader.cpp` |
| `src/BRepHandle.cpp` | Implements `nearestPointOnShape`, `normalAtNearest`, `principalCurvatures`, `create()` |
| `include/StepLoader.h` | `IGeometryLoader` subclass + `loadWithBRep()` extended API |
| `src/StepLoader.cpp` | Full OCC pipeline: read → heal → tessellate → harvest |
| `tools/gen_step_fixtures.cpp` | Generates `unit_cube.step` and `sphere_r1.step` |
| `regression/step_cube_load.txt` | Placeholder sentinel for cube load assertions |
| `regression/step_sphere_hausdorff.txt` | Placeholder sentinel for sphere Hausdorff improvement |

### Modified files

| File | Change |
|------|--------|
| `include/FEAData.h` | `+sizingChordError = 1e-3f` in `FEAParams` |
| `include/FEAModel.h` | `+brep`, `+hasBRep()`, `+loadSTEP()`, `+~FEAModel()` (destructor forward-declared; defined in `.cpp`) |
| `src/FEAModel.cpp` | `loadSTEP()`, `loadFile()` dispatch, `brep.reset()` in `processRawGeometry()`, BRep fidelity dispatch |
| `include/GeometryLoaderDispatch.h` | `.step` / `.stp` → `StepLoader` in `makeLoader()` |
| `src/main.cpp` | `scanForModels()` + STEP badge (gold/amber) + `"Source: STEP (B-rep retained)"` status |
| `include/MeshQuality.h` | `+usedExactBRep` in `FidelityReport`; BRep overload declarations |
| `src/MeshQuality.cpp` | `computeFidelity(ref, brep, out, p)` — OCC forward pass; `emitFidelityReport` BRep overloads |
| `CMakeLists.txt` | `USE_OCCT` option, `find_package(OpenCASCADE)`, new sources, `gen_step_fixtures` target, STEP asset copy, OCCT DLL post-build |

---

## Architecture: pImpl for OCC Isolation

The critical design decision was keeping OCC out of every TU except `BRepHandle.cpp` and `StepLoader.cpp`:

```
include/BRepHandle.h        ← #include "BRepHandle.h" is safe everywhere
  struct BRepHandle { struct Impl; unique_ptr<Impl> impl_; }  (OCC-free)

src/BRepHandle_impl.h       ← INTERNAL ONLY — included by BRepHandle.cpp + StepLoader.cpp
  #include <TopoDS_Shape.hxx> ...
  struct BRepHandle::Impl { TopoDS_Shape shape; TopTools_IndexedMapOfShape faceMap; ... }

src/BRepHandle.cpp          ← OCC-aware; implements all BRepHandle methods
src/StepLoader.cpp          ← OCC-aware; creates BRepHandle::Impl, calls BRepMesh_IncrementalMesh
```

`FEAModel.cpp` and `MeshQuality.cpp` use only `#include "BRepHandle.h"` — they see zero OCC symbols.

---

## Key Implementation Details

### Tessellation parameters
```cpp
// lin_def = 0.1% chord error on the bbox diagonal
double Ldiag = bboxDiag(shape);
double linDef = params.sizingChordError * Ldiag;  // default: 1e-3 × Ldiag

BRepMesh_IncrementalMesh mesher(shape, linDef, /*relative*/false,
                                /*ang_def*/0.3, /*parallel*/true);
```
`ang_def = 0.3 rad` matches COMSOL's default angular deflection.

### Face orientation winding fix (critical)
```cpp
// REVERSED faces have opposite winding — must swap i1 and i2
Standard_Integer n1, n2, n3;
tri.Get(n1, n2, n3);
if (face.Orientation() == TopAbs_REVERSED) std::swap(n2, n3);
```
Without this swap, half the surface normals point inward, causing normal deviation ≈ 180° on all REVERSED faces — the same class of bug as TODO_03 Bug 1 (TetGen inward-face convention).

### Exact nearest-point (forward fidelity pass)
```cpp
// BRepExtrema_DistShapeShape dispatches to analytic NURBS; not a discrete BVH
TopoDS_Vertex vq = BRepBuilderAPI_MakeVertex(gp_Pnt(q.x, q.y, q.z));
BRepExtrema_DistShapeShape dss(vq, impl_->shape);
dss.Perform();
// → distance to analytic surface, ~3 orders better than triangulation BVH on sphere
```

### Surface normal at nearest point
```cpp
// Get UV parameters from nearest face result
Standard_Real u, v;
TopoDS_Face nearFace = TopoDS::Face(dss.SupportOnShape2(1));
dss.ParOnFaceS2(1, u, v);
// Evaluate analytic normal via surface evaluator
BRepAdaptor_Surface adapt(nearFace);
BRepLProp_SLProps props(adapt, u, v, 1, 1e-6);
gp_Dir nrm = props.Normal();
// Flip sign for REVERSED faces
if (nearFace.Orientation() == TopAbs_REVERSED) nrm.Reverse();
```

### FEAModel destructor (pImpl uniqueness requirement)
```cpp
// FEAModel.h — declared but NOT defaulted here:
~FEAModel();

// FEAModel.cpp — defined here where BRepHandle.h is included (complete type):
FEAModel::~FEAModel() = default;
```
Without this, the compiler emits the destructor in the header TU where `BRepHandle` is incomplete, generating `unique_ptr::~unique_ptr()` on an incomplete type → linker error or silent UB.

### loadSTEP ordering constraint
`processRawGeometry()` calls `brep.reset()` to clear stale B-rep on geometry reload. Therefore `loadSTEP()` must set `brep` **after** `processRawGeometry()` returns:
```cpp
bool FEAModel::loadSTEP(const std::string& filepath) {
    LoadedGeometry geo;
    std::unique_ptr<BRepHandle> newBrep;
    StepLoader loader;
    if (!loader.loadWithBRep(filepath, geo, newBrep, params)) return false;
    if (!processRawGeometry(geo, "STEP")) return false;
    brep = std::move(newBrep);  // AFTER processRawGeometry — it would reset() brep first
    return true;
}
```

### OCCT not installed → graceful degradation
All OCC calls are inside `#ifdef HAS_OCCT`. When `USE_OCCT=OFF`:
- `StepLoader::load()` returns `false` with a clear message
- `BRepHandle` methods return safe zero-defaults (inline stubs in header)
- `MeshQuality` BRep overloads fall through to the triangulation path
- `hasBRep()` always returns `false`; status panel shows `"Source: STEP"` (without `"(B-rep retained)"`)

### BRepHandle.h dual-class pattern (HAS_OCCT / !HAS_OCCT)
`BRepHandle.h` provides two class definitions gated on `HAS_OCCT`:
```cpp
#ifdef HAS_OCCT
class BRepHandle {           // full pImpl; defined in BRepHandle.cpp
    struct Impl;
    std::unique_ptr<Impl> impl_;
    ...
};
#else
class BRepHandle {           // inline stubs; no .cpp linkage needed
    int numFaces() const { return 0; }
    glm::dvec3 nearestPointOnShape(glm::dvec3 q) const { return q; }
    glm::dvec3 normalAtNearest(glm::dvec3) const { return {0,1,0}; }
    ...
};
#endif
```
This means `mesh_diag` (which doesn't define `HAS_OCCT=1`) gets the inline stubs at zero
link cost. Without this pattern, `mesh_diag` fails to link because `MeshQuality.cpp`'s
BRep overloads call BRepHandle methods regardless of `HAS_OCCT`.

`BRepHandle.cpp` is correspondingly wrapped entirely in `#ifdef HAS_OCCT` — the `.cpp`
is only needed for the full pImpl build.

### OCCT 7.9 API change: Interface_Static::CVal capitalisation
In OCCT 7.9, `Interface_Static::Cval()` was renamed to `Interface_Static::CVal()`.
The call in `StepLoader.cpp` was updated accordingly.

---

## CMake Integration (as-shipped and post-build-session final state)

**Strategy: `find_package`, NOT `FetchContent`** — building OCCT from source takes hours and requires its own dependency chain.

**Install method:** vcpkg at `D:\program_files_delta\vcpkg`
```
vcpkg.exe install opencascade:x64-windows
```
Puts cmake config at `<vcpkg>/installed/x64-windows/share/opencascade/OpenCASCADEConfig.cmake`.

**Critical: `find_package(OpenCASCADE)` must come AFTER `project()`.**
Before `project()`, the platform (shared-library support) is uninitialised. OCCT's
imported SHARED targets fail silently and the package appears not found.

**`OpenCASCADE_DIR` bypass instead of PATHS:**
Rather than relying on `find_package PATHS` (which is unreliable with the vcpkg
toolchain intercepting `find_package`), the CMakeLists.txt loops over known hint paths
and sets `OpenCASCADE_DIR` directly before calling `find_package(OpenCASCADE CONFIG QUIET)`.
`OpenCASCADE_DIR` makes CMake skip the search entirely and go straight to the config.

**Freetype transitive dep:** `OpenCASCADEConfig.cmake` calls `find_dependency(Freetype MODULE)`.
CMakeLists.txt explicitly prepends the vcpkg install prefix to `CMAKE_PREFIX_PATH` so
Freetype is visible before the OCCT config runs.

**OCCT 7.9 module renames** — the STEP I/O toolkit was reorganised in 7.9:

| 7.7 / 7.8 name | 7.9.x replacement |
|---|---|
| `TKSTEP` | `TKDESTEP` |
| `TKSTEPBase` | (merged into `TKDESTEP`) |
| `TKSTEPAttr` | (merged into `TKDESTEP`) |
| `TKSTEP209` | (merged into `TKDESTEP`) |
| — | `TKDE` (new data exchange framework) |
| `TKXSBase` | `TKXSBase` (unchanged) |

Final linked modules (7.9.3 / vcpkg):
```
TKernel TKMath TKDESTEP TKDE TKXSBase
TKBRep TKTopAlgo TKShHealing
TKG3d TKG2d TKGeomBase TKGeomAlgo TKMesh
```

**`build.bat` vcpkg toolchain wiring:**
```bat
set "VCPKG_TOOLCHAIN=D:\program_files_delta\vcpkg\scripts\buildsystems\vcpkg.cmake"
if exist "!VCPKG_TOOLCHAIN!" (
    cmake ... -DCMAKE_TOOLCHAIN_FILE="!VCPKG_TOOLCHAIN!" -DVCPKG_TARGET_TRIPLET=x64-windows
)
```

---

## Console Output (expected)

On load:
```
[STEP] cascade unit: MM
[STEP] read OK, 1 solid(s), 6 faces, 12 edges, 8 vertices
[STEP] tessellated -> 12 triangles (lin_def=0.001732, ang_def=0.3 rad, parallel=true)
Loaded: 24 verts, 12 tris  [STEP]
```

On fidelity (sphere, with BRep):
```
[Fidelity vs input surface] [NURBS B-rep exact]
Hausdorff (symmetric) : 8.xx e-07 m  (target: < 1e-05 m, ratio 0.00)
normal deviation      : p50=0.x deg   p95=1.x deg   p99=2.x deg   max=3.x deg
Verdict: PASS
```

---

## Build & Installation (completed 2026-05-19)

- **OCCT source**: vcpkg port `opencascade:x64-windows` (7.9.3), installed at `D:\program_files_delta\vcpkg`
- **Test fixtures generated**: `unit_cube.step` and `sphere_r1.step` via `gen_step_fixtures.exe`
- **Build result**: both `FEAPreProcessor.exe` and `mesh_diag.exe` link with zero errors
- **DLL copy verified**: 13 OCCT DLLs copied to build output by CMake post-build steps

### Build bugs found and fixed during installation session

| Bug | Root cause | Fix |
|-----|-----------|-----|
| `find_package(OpenCASCADE)` before `project()` → SHARED target warning, package "not found" | Platform (shared-lib support) uninitialised before `project()` | Moved entire `find_package` block to after `project()` |
| `find_package PATHS` not found despite correct path | vcpkg toolchain intercepts `find_package`; PATHS heuristics unreliable | Set `OpenCASCADE_DIR` directly via existence-check loop |
| `find_dependency(Freetype MODULE)` inside OCCT config fails | vcpkg prefix not in `CMAKE_PREFIX_PATH` at OCCT config time | Explicitly `list(PREPEND CMAKE_PREFIX_PATH "<vcpkg>/x64-windows")` before `find_package` |
| `TKSTEP TKSTEPBase TKSTEPAttr TKSTEP209` link error | Module names changed in OCCT 7.9 | Replaced with `TKDESTEP TKDE` |
| `Interface_Static::Cval`: identifier not found | Capitalisation change in OCCT 7.9 (`Cval` → `CVal`) | Updated call site in `StepLoader.cpp` |
| `mesh_diag` linker: unresolved `BRepHandle::numFaces` etc. | `MeshQuality.cpp`'s BRep overloads call BRepHandle methods even when HAS_OCCT=0; BRepHandle.cpp not linked to mesh_diag | Gave `BRepHandle.h` inline stubs for !HAS_OCCT; wrapped BRepHandle.cpp in `#ifdef HAS_OCCT` |
| Compile error adding BRepHandle.cpp to mesh_diag: `use of undefined type BRepHandle::Impl` | `create(Impl impl)` by-value signature requires complete Impl, which only exists when HAS_OCCT=1 | Inline stubs in header made linking BRepHandle.cpp to mesh_diag unnecessary; approach abandoned in favour of header-stub pattern |

---

## Pass Criterion Status

| # | Criterion | Status |
|---|-----------|--------|
| 1 | `.step` / `.stp` files load (dispatch, tessellate, render) | ✅ builds; load UI validation pending |
| 2 | `hasBRep() == true` for STEP loads | ✅ code complete |
| 3 | Status panel: `"Source: STEP (B-rep retained)"` | ✅ code complete |
| 4 | Hausdorff on sphere < 1e-5 m (≥1 order better than STL) | ✅ builds; runtime validation pending |
| 5 | Normal deviation p95 < 15° | ✅ builds; runtime validation pending |
| 6 | Graceful degradation when USE_OCCT=OFF | ✅ inline stubs + #ifdef guards |
| 7 | Cube: Hausdorff ≈ machine epsilon (flat faces → exact) | ✅ builds; runtime validation pending |
| 8 | Regression sentinels updated | ⚠️ placeholders in `regression/step_*.txt` — fill after first app run |

---

## Next TODO

TODO_05 per the roadmap.

---

## Post-Completion Debug Log (2026-05-19)

Two bugs were discovered and fixed after the initial completion of TODO_04 during
quality testing on a STEP sphere (`sphere_r1.step`).

---

### Bug Fix 1 — `normalAtNearest` wrong fallback for edge/vertex support

**Symptom (observed via `MeshQuality::computeFidelity`):**
```
[Fidelity vs input surface]
normal deviation : p50=73.4° p95=~178° max=180°
```
73° median is the expected value when a significant fraction of surface samples
receive a fixed fallback of `(0, 1, 0)` regardless of actual surface orientation.
On a sphere, the expected mean angle between a random unit vector and `(0,1,0)` is ~57°;
the p50 being 73° indicated ~40% of samples hit the fallback.

**Root cause:**
`BRepExtrema_DistShapeShape` returns one or more solution records, each with a support
type: `BRepExtrema_IsInFace`, `BRepExtrema_IsOnEdge`, or `BRepExtrema_IsVertex`.

Only `IsInFace` solutions carry UV parameters (`ParOnFaceS2`) that can be fed directly
to `BRepLProp_SLProps` to recover the analytic surface normal.

At sphere poles and seam edges, OCCT's extremal-distance algorithm classifies the nearest
point as lying *on an edge* (the degenerate pole edge where all meridians collapse to one
curve) or *on a vertex*, producing an `IsOnEdge`/`IsVertex` result. The old code had:

```cpp
// old — returned wrong constant if no IsInFace solution found
for (int i = 1; i <= dss.NbSolution(); ++i) {
    if (dss.SupportTypeShape2(i) == BRepExtrema_IsInFace) {
        ...
        return normal;
    }
}
return glm::dvec3(0.0, 1.0, 0.0);  // BUG: always Y-up for pole/seam samples
```

This hit for every fidelity sample whose nearest point projected to a pole, which on a
radius-1 sphere covered all samples near both caps — explaining the 73° median.

**Fix applied (`src/BRepHandle.cpp`, `normalAtNearest`):**
After the `IsInFace` loop, a fallback path projects the 3-D nearest point onto each
face's analytic surface using `GeomAPI_ProjectPointOnSurf` and returns the normal of the
closest face:

```cpp
const gp_Pnt nearPt = dss.PointOnShape2(1);
double     bestD2 = 1e300;
glm::dvec3 bestN(0.0, 1.0, 0.0);
for (int fi = 1; fi <= impl_->faceMap.Extent(); ++fi) {
    const TopoDS_Face       face  = TopoDS::Face(impl_->faceMap(fi));
    const BRepAdaptor_Surface adapt(face);
    GeomAPI_ProjectPointOnSurf proj(nearPt,
        adapt.Surface().Surface(),
        adapt.FirstUParameter(),  adapt.LastUParameter(),
        adapt.FirstVParameter(),  adapt.LastVParameter(), 1e-7);
    if (!proj.IsDone() || proj.NbPoints() == 0) continue;
    const double d2 = proj.LowerDistance() * proj.LowerDistance();
    if (d2 < bestD2) {
        Standard_Real u, v;
        proj.LowerDistanceParameters(u, v);
        BRepLProp_SLProps props(adapt, u, v, 1, 1e-6);
        if (props.IsNormalDefined()) {
            const gp_Dir& n = props.Normal();
            const double sign = (face.Orientation() == TopAbs_REVERSED) ? -1.0 : 1.0;
            bestD2 = d2;
            bestN  = glm::dvec3(sign * n.X(), sign * n.Y(), sign * n.Z());
        }
    }
}
return bestN;
```

`GeomAPI_ProjectPointOnSurf` is a NURBS-level solver that works in UV space; it does
not require an extremal-distance classification and is immune to the pole/seam issue.
The per-face loop is O(F) where F is the face count (typically 2 for a sphere), so the
cost penalty is negligible for diagnostic use.

New header include added to `src/BRepHandle_impl.h`:
```cpp
#include <GeomAPI_ProjectPointOnSurf.hxx>
```

---

### Bug Fix 2 — Polar sliver triangles via `IMeshTools_Parameters::MinSize`

**Symptom (observed visually):**
Dense fan of very narrow triangles at both sphere poles — identical to the classic
UV-sphere singularity artefact seen in graphics engines using spherical UV maps.
Terminal quality report showed 41 "severe" slivers (aspect ratio > 20:1).

**Root cause:**
`BRepMesh_IncrementalMesh`'s default parametric mesher uses the UV parameterisation of
each B-rep face. For OCCT's analytic sphere face, the UV domain is the full 2-D rectangle
`[0, 2π] × [-π/2, π/2]`. All meridians (constant-U isolines) converge to the same 3-D
point at each pole (V = ±π/2). The mesher generates one mesh vertex at each UV grid
intersection — when those UV rows are dense near the pole, many near-degenerate
triangles are emitted at essentially the same 3-D location.

**Fix applied (`src/StepLoader.cpp`, `loadSTEP_impl`):**
Replaced the two-argument `BRepMesh_IncrementalMesh` constructor with
`IMeshTools_Parameters`, adding `MinSize = linDef`:

```cpp
// BEFORE
BRepMesh_IncrementalMesh mesher(shape, linDef, /*relative*/false,
                                /*ang_def*/0.3, /*parallel*/true);

// AFTER
IMeshTools_Parameters meshParams;
meshParams.Deflection  = linDef;
meshParams.Angle       = angDef;       // 0.3 rad ≈ 17° (COMSOL default)
meshParams.InParallel  = Standard_True;
meshParams.MinSize     = linDef;       // polar sliver suppression
meshParams.Relative    = Standard_False;
BRepMesh_IncrementalMesh mesher(shape, meshParams);
```

`MinSize` prevents the mesher from generating triangle edges shorter than `linDef`.
Since all the sliver triangles at the pole have edges shorter than the chord-error
budget, they are collapsed. The polar fan is replaced by a small cap of regular
triangles.

**Remaining limitation:**
`MinSize` is a suppression heuristic, not a structural fix. It reduces sliver count
from 41 to a small number but does not eliminate the UV singularity. Visual inspection
after this fix still shows triangles concentrating at both poles (though less extreme).

The structural fix — cutting the sphere along coordinate planes before meshing to
eliminate the degenerate pole edges — is planned in **TODO_041**.
