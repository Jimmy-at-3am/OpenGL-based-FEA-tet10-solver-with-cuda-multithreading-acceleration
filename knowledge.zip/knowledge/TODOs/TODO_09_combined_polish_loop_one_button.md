# TODO_09 — `Polish Mesh` combined loop (SPLIT/COLLAPSE → FLIP → SMOOTH)

## Goal
One-button MMG-style iterative polish: combines TODO_06 (ODT), TODO_07 (Stellar flips), TODO_08 (boundary projection), plus SPLIT/COLLAPSE on edge lengths, into a single loop with live progress and live HUD refresh.

## Files added / modified
- **Modify** `include/MeshSmoother.h`, `src/MeshSmoother.cpp` — add `class CombinedPolisher` orchestrating the existing operators.
- **Modify** `src/SimpleUI.cpp` — `Polish Mesh` button.
- **Modify** `src/FEAModel.cpp::updateScalarFieldData()` — invoke per-iteration so HUD refreshes live.

## Algorithm summary
From plan Appendix Phase B.4 and [knowledge/12_Mesh_Smoothing_CVT_and_ODT.md §6.5](knowledge/12_Mesh_Smoothing_CVT_and_ODT.md):

```text
repeat improveIterations times (default 5):
    // SPLIT / COLLAPSE phase (isotropic; metric-aware when TODO_16 lands):
    for each interior edge e (parallel red-black colouring on conflict graph):
        if length(e) > sqrt(2) * h_target: SPLIT at midpoint
        else if length(e) < 1/sqrt(2) * h_target: COLLAPSE
    // FLIP phase:
    for each interior edge e: try 2-3 / 3-2 / 4-4 if improves min Knupp
    // SMOOTH phase:
    one ODT pass over interior nodes (TODO_06)
    one tangent-space-ODT pass over boundary nodes (NEW — see Plan Appendix Phase B.1b)
    publishProgress(iter / improveIterations)
    swap GL buffers (HUD refresh)
```

**Order is essential.** SMOOTH before SPLIT/COLLAPSE wastes the smoothing budget on elements about to disappear (care-point #18).

`h_target` for the isotropic case = current mesh's median edge length (TODO_16 replaces this with the metric-driven value).

## Multithreading
- SPLIT/COLLAPSE: conflict-graph red-black colouring required for correctness — two ops conflict if they share a tet. Greedy colour assignment built once at iteration start (parallel). Each colour's ops processed fully parallel.
- FLIP: serial (uses the TopologyOptimizer from TODO_07).
- SMOOTH: parallel from TODO_06.

Implement the colour assignment as a separate `ConflictGraphColouring` helper — reused by TODO_16 (MMG-style local-op loop).

## Numerical care points
- **Loop order** (care-point #18): SPLIT/COLLAPSE → FLIP → SMOOTH.
- **Hausdorff drift gate** (care-point in plan §4): pre-check Hausdorff (TODO_03). If post-iter drift exceeds `1.5 × initial`, log a warning and stop boundary smoothing for subsequent iterations.
- **Boundary smoothing** must be tangent-space-constrained — see plan Appendix Phase B.1b. Implement here as the "boundary subpass" of SMOOTH.

## Screen-visible acceptance check

**Setup** Same as TODO_06 (rough mesh).

**Action** Click `Polish Mesh` (combined SPLIT/COLLAPSE → FLIP → SMOOTH, 5 iterations).

**Expected**
- Animated console block, one line per iteration:
  ```text
  [Polish] iter 1/5: split:42 collapse:18 flip:97 smooth: q_min 0.10→0.31
  [Polish] iter 2/5: split:11 collapse:6  flip:42 smooth: q_min 0.31→0.48
  ...
  [Polish] DONE: q_min 0.62  (was 0.10)  Hausdorff drift 1.4e-4 m (was 0.0)
  ```
- HUD updates live between iterations (best done by buffer-swap after each).

**Failure modes**
- All counts 0 → loop ordering wrong (SMOOTH before SPLIT/COLLAPSE swallows the budget).
- Hausdorff drift > 5×initial → boundary smoothing not tangent-constrained.
- HUD only updates at end → missing buffer-swap call per iteration.

**Pass criterion** Five iterations of monotonic $q_{\min}$ improvement; final drift $<5\times$ initial.

## Regression sentinel
`regression/polish_bracket.txt` — per-iteration counts + final q_min + Hausdorff drift.

## Depends on
TODO_06, TODO_07, TODO_08.

## Estimated effort
2.5 days (the colour-assignment helper is most of the work).
