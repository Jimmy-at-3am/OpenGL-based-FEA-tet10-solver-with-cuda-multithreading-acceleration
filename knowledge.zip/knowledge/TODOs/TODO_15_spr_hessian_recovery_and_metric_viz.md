# TODO_15 — SPR Hessian recovery + metric tensor visualisation

## Goal
After a linear solve, recover a per-node Hessian of displacement (or von Mises stress) via Superconvergent Patch Recovery (SPR / Zhang-Naga double projection), build the optimal anisotropic metric tensor, and visualise it as ellipsoid glyphs in the viewer. Foundation for TODO_16 (MMG anisotropic remesh) and TODO_19 (ZZ error indicator).

## Files added / modified
- **Add** `include/HessianRecovery.h`, `src/HessianRecovery.cpp` — patch-based double-projection.
- **Add** `include/MetricField.h`, `src/MetricField.cpp` — Hessian → metric, log-Euclidean operations, clamping.
- **Modify** `include/FEAModel.h` — store `std::vector<Eigen::Matrix3d> metricPerNode`.
- **Modify** `src/SimpleUI.cpp`, `src/main.cpp` — `M` key toggle for ellipsoid glyphs.
- **Modify** `src/ShaderSources.h` — instanced ellipsoid (unit sphere stretched by metric eigenvalues).

## Algorithm summary
From [knowledge/08_Anisotropic_Metric_Adaptation.md §1, §2](knowledge/08_Anisotropic_Metric_Adaptation.md) and plan Appendix Phase D:

**SPR Hessian recovery** (Zhang–Naga 2005):
```text
For each interior node n:
    Patch P_n = elements incident on n (1-ring)
    Fit polynomial p(x,y,z) of degree (element-order + 1) to u_h at integration points in P_n
        via least-squares (Eigen HouseholderQR; matrix ≤ 20x20)
    Evaluate H_n = grad(grad p)(x_n), take symmetric part
For each displacement component c (3 in 3D), recover H_n^(c) separately
Driving Hessian: H_drv(n) = spectral-max over components
For von-Mises-driven anisotropy (preferred for elasticity, note [[08]] §7):
    recover Hessian of sigma_vM directly
```

**Optimal metric** (Loseille–Alauzet 2010):
```text
For each node n:
    |H| = R * diag(|lambda_i|) * R^T    (absolute-value Hessian via eigendecomp)
    rho_n = det(|H|)^(1/(2p+d))         (p = element order, d = 3)
    M_raw = |H| / rho_n

Normalisation for target node count N_target:
    scale = (N_target / int(det(M_raw)^(1/2) dV))^(2/d)
    M_n = scale * M_raw

Clamp eigenvalues:
    h_i = lambda_i^(-1/2)  clamped to [h_min, h_max]
    if max(h_i)/min(h_i) > anisotropicMaxAspect: scale eigenvalues to cap
    Reassemble M_n via R * diag(1/h_i^2) * R^T
```

**Log-Euclidean averaging** (used for interpolation, multi-component intersection, gradation):
```cpp
Eigen::Matrix3d logEuclideanMean(spans<Mat3d> Ms, spans<double> ws) {
    Mat3d sumLog = Zero;
    for each (M_i, w_i):
        eig = SelfAdjointEigenSolver(M_i)
        sumLog += w_i * eig.vectors * diag(log(eig.values)) * eig.vectors^T
    eig = SelfAdjointEigenSolver(sumLog / sum(w))
    return eig.vectors * diag(exp(eig.values)) * eig.vectors^T
}
```

## Multithreading
- Build `vertex -> elements` map once via `#pragma omp parallel for`.
- Patch fit per node: `#pragma omp parallel for schedule(dynamic, 256)`. Each patch ≤ 20 dofs → fast.
- Metric construction per node: per-node parallel-for.

## Numerical care points
- **Patch fit degenerates at boundary** (care-point #3): fall back to a smaller polynomial degree, or use `boundary_node_flag` to take an average from interior-patch neighbours.
- **Metric clamping order** (#4): clamp eigenvalues, re-orthogonalise, re-assemble. Clamping the assembled matrix directly produces non-SPD output.
- **Log-Euclidean numerics** (#5): floor eigenvalues at `(h_max)^(-2)` before `log` to avoid `-inf`.

## Screen-visible acceptance check

**Setup** Load `assets/test_fixtures/cantilever_with_hole.stl`. Mesh; click `Solve Linear Static`.

**Action** After solve completes, toggle `M` (metric glyphs).

**Expected visible**
- Small wireframe ellipsoids drawn at every Nth interior vertex (default N=20).
- Around the stress-concentrator hole: ellipsoids visibly elongated, oriented around the hole.
- Far from the hole: ellipsoids roughly spherical.
- Console: `[SPR] Hessian recovered for 1247 nodes   metric complexity = 1.04 × N_nodes`.

**Failure modes**
- All glyphs spherical → Hessian eigenvalues clipped, or `R | Lambda | R^T` not built.
- Random orientations far from hole → patch fit fails for low-stress regions (small dynamic range).
- Glyphs missing → toggle wired wrong or glyph radius zero.

**Pass criterion** Visible anisotropy at the hole region; spherical-ish glyphs in the far field.

## Regression sentinel
`regression/spr_cantilever.txt` — max anisotropy ratio at hole vs far field.

## Depends on
TODO_05 (HUD/overlay infrastructure), TODO_06 (any solved + smoothed mesh as input).

## Estimated effort
3 days.
